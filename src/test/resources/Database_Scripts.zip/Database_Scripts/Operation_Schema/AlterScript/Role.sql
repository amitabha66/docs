 update role set DESCRIPTION = 'Admin User' where roleid = 3; 
