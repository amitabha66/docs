------------------------------Manage User-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,20,3,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,20,3,2,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,20,3,3,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,20,3,4,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,21,3,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,21,3,2,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,21,3,3,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,21,3,4,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,22,3,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,22,3,2,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,22,3,3,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,22,3,4,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,23,3,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,23,3,2,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,23,3,3,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,23,3,4,5017,4,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,24,3,1,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,24,3,2,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,24,3,3,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,24,3,4,5017,5,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,25,3,1,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,25,3,2,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,25,3,3,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,25,3,4,5017,6,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,26,3,1,5017,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,26,3,2,5017,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,26,3,3,5017,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,26,3,4,5017,7,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,27,3,1,5017,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,27,3,2,5017,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,27,3,3,5017,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,27,3,4,5017,8,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,28,3,1,5017,9,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,28,3,2,5017,9,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,28,3,3,5017,9,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1482,28,3,4,5017,9,'AC',sysdate);


------------------------------Manage Org-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,20,3,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,20,3,2,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,20,3,3,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,20,3,4,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,21,3,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,21,3,2,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,21,3,3,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,21,3,4,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,29,3,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,29,3,2,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,29,3,3,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,29,3,4,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,30,3,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,30,3,2,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,30,3,3,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,30,3,4,5017,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,31,3,1,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,31,3,2,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,31,3,3,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1483,31,3,4,5017,5,'AC',sysdate);



------------------------------Manage Parent-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,20,3,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,20,3,2,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,20,3,3,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,20,3,4,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,21,3,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,21,3,2,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,21,3,3,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,21,3,4,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,32,3,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,32,3,2,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,32,3,3,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,32,3,4,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,33,3,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,33,3,2,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,33,3,3,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,33,3,4,5017,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,34,3,1,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,34,3,2,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,34,3,3,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,34,3,4,5017,5,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,35,3,1,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,35,3,2,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,35,3,3,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1484,35,3,4,5017,6,'AC',sysdate);


------------------------------Manage Student-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,20,3,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,20,3,2,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,20,3,3,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,20,3,4,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,21,3,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,21,3,2,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,21,3,3,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,21,3,4,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,36,3,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,36,3,2,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,36,3,3,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,36,3,4,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,37,3,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,37,3,2,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,37,3,3,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,37,3,4,5017,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,38,3,1,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,38,3,2,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,38,3,3,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1485,38,3,4,5017,5,'AC',sysdate);


------------------------------Manage Report-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,39,2,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,39,7,1,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,40,2,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,40,7,1,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,41,2,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,41,7,1,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,42,2,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1486,42,7,1,5017,4,'AC',sysdate);


------------------------------Manage Content-----------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,43,2,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,43,7,1,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,44,2,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,44,7,1,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,45,2,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,45,7,1,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,46,2,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,46,7,1,5017,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,47,2,1,5017,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,47,7,1,5017,5,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,48,2,1,5017,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,48,7,1,5017,6,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,49,2,1,5017,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,49,7,1,5017,7,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,50,2,1,5017,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,50,7,1,5017,8,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,51,2,1,5017,9,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1487,51,7,1,5017,9,'AC',sysdate);


------------------------Reset Password------------------------------
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,52,2,1,5017,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,52,7,1,5017,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,53,2,1,5017,2,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,53,7,1,5017,2,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,54,2,1,5017,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,54,7,1,5017,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,55,2,1,5017,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1488,55,7,1,5017,4,'AC',sysdate);





------------------------------------------------------
----------------------TASC----------------------------


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,1,3,1,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,1,3,2,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,1,3,3,3001,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,2,3,1,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,2,3,2,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,2,3,3,3001,2,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,3,3,1,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,3,3,2,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,3,3,3,3001,3,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,4,3,1,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,4,3,2,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,4,3,3,3001,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,5,3,1,3001,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,5,3,2,3001,5,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,5,3,3,3001,5,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,6,3,1,3001,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,6,3,2,3001,6,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,6,3,3,3001,6,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,7,3,1,3001,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,7,3,2,3001,7,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,7,3,3,3001,7,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,8,3,1,3001,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,8,3,2,3001,8,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,8,3,3,3001,8,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,9,3,1,3001,9,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,9,3,2,3001,9,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1104,9,3,3,3001,9,'IN',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,1,3,1,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,1,3,2,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,1,3,3,3001,1,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,2,3,1,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,2,3,2,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,2,3,3,3001,2,'IN',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,10,3,1,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,10,3,2,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,10,3,3,3001,3,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,11,3,1,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,11,3,2,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1105,11,3,3,3001,4,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,1,3,1,3001,1,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,1,3,2,3001,1,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,1,3,3,3001,1,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,2,3,1,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,2,3,2,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,2,3,3,3001,2,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,13,3,1,3001,3,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,13,3,2,3001,3,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,13,3,3,3001,3,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,14,3,1,3001,4,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,14,3,2,3001,4,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,14,3,3,3001,4,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,15,3,1,3001,5,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,15,3,2,3001,5,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,15,3,3,3001,5,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,16,3,1,3001,6,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,16,3,2,3001,6,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1106,16,3,3,3001,6,'IN',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,1,3,1,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,1,3,2,3001,1,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,1,3,3,3001,1,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,2,3,1,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,2,3,2,3001,2,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,2,3,3,3001,2,'IN',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,17,3,1,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,17,3,2,3001,3,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,17,3,3,3001,3,'AC',sysdate);


insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,18,3,1,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,18,3,2,3001,4,'AC',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,18,3,3,3001,4,'AC',sysdate);

insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,19,3,1,3001,5,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,19,3,2,3001,5,'IN',sysdate);
insert into dash_action_access(db_act_accessid,db_menuid,db_reportid,db_actionid,roleid,org_level,cust_prod_id,action_seq,activation_status,created_date_time)
values(seq_dash_action_access.nextval,105,1107,19,3,3,3001,5,'IN',sysdate);


