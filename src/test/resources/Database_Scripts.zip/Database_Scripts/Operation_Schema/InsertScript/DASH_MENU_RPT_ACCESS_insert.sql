--Manage User  state,district,school - role admin
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1482,3,1,5001,8001,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1482,3,2,5001,8001,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1482,3,3,5001,8001,'AC',sysdate);
--Manage Org  state,district,school - role admin
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1483,3,1,5001,8002,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1483,3,2,5001,8002,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1483,3,3,5001,8002,'AC',sysdate);
--Manage Parent  state,district,school - role admin
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1484,3,1,5001,8003,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1484,3,2,5001,8003,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1484,3,3,5001,8003,'AC',sysdate);
--Manage Student  state,district,school - role admin
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1485,3,1,5001,8004,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1485,3,2,5001,8004,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1485,3,3,5001,8004,'AC',sysdate);
--Manage Report  state - role super
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1486,7,1,5001,8005,'AC',sysdate);
--Manage Content  state - role super
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1487,7,1,5001,8006,'AC',sysdate);
--Reset Password  state - role super, role ctb
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1488,7,1,5001,8007,'AC',sysdate);
insert into dash_menu_rpt_access(db_menuid,db_reportid,roleid,org_level,cust_prod_id,report_seq,activation_status,created_date_time)
values(105,1488,2,1,5001,8007,'AC',sysdate);