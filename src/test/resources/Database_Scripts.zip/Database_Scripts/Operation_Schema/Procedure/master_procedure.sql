--Need to compile in istep and tasc only
@\PRC_CONFIGURATION.prc;
--Need to compile in prismglobal only
@\PRC_MSG_TYPEID_CORRECTION.prc;
