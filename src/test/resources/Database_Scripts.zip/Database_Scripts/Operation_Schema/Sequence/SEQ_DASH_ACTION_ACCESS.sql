create sequence SEQ_DASH_ACTION_ACCESS
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;