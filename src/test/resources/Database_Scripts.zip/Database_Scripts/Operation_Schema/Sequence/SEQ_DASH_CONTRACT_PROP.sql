-- Create sequence 
create sequence SEQ_DASH_CONTRACT_PROP
minvalue 1
maxvalue 999999999999999999999999999
start with 121
increment by 1
cache 20;
