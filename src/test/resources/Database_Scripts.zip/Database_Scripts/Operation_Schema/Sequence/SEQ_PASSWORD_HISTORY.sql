-- Create sequence 
create sequence SEQ_PASSWORD_HISTORY
minvalue 1
maxvalue 999999999999999999999999999
start with 9341
increment by 1
cache 20;