-- Create sequence 
create sequence ACTIVITYID_SEQ
minvalue 1
maxvalue 999999999999
start with 10941
increment by 1
cache 20;