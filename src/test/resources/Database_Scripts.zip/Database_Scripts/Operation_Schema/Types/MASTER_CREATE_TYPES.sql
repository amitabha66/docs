prompt creating types...


@./DYN_ATTR_DTLS.tps
@./PRS_PGT_GLOBAL_TEMP_OBJ.typ
@./PRS_COLL_PGT_GLOBAL_TEMP_OBJ.tps


prompt types created...