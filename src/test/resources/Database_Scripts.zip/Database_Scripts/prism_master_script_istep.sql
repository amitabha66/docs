@\Operation_Schema\Packages\master_package.sql;
@\Operation_Schema\Procedure\PRC_REPORT_CONFIGURATION.prc;
@\Operation_Schema\Procedure\PRC_CONFIGURATION.prc;
-- Run PRC_REPORT_CONFIGURATION(2) manually
-- Run PRC_CONFIGURATION(2) manually
