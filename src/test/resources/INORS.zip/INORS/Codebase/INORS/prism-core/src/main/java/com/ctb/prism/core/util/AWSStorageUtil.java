package com.ctb.prism.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.springframework.util.FileCopyUtils;

/*

<dependency>
	<groupId>com.amazonaws</groupId>
	<artifactId>aws-java-sdk</artifactId>
	<version>1.9.15</version>
</dependency>

*/

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;


public class AWSStorageUtil {
	private BasicAWSCredentials credentials;
	private AmazonS3 s3;
	private String bucketName;
	private static volatile AWSStorageUtil awsstorageUtil = new AWSStorageUtil();

	private AWSStorageUtil() {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream("D:/Amitabha/AwsCredentials.properties"));
			this.credentials = new BasicAWSCredentials(properties.getProperty("aws.accessKey"), properties.getProperty("aws.secretKey"));
			this.bucketName = properties.getProperty("aws.s3bucket");
			this.s3 = new AmazonS3Client(this.credentials);

			//  You can use this in your web app where AwsCredentials.properties			  is stored in web-inf/classes
			// AmazonS3 s3 = new AmazonS3Client(new
			// ClasspathPropertiesFileCredentialsProvider());

		} catch (Exception e) {
			System.out.println("exception while creating awss3client : " + e);
		}
	}

	public static AWSStorageUtil getInstance() {
		return awsstorageUtil;
	}

	public static AmazonS3 getAWSClient() {
		return awsstorageUtil.s3;
	}

	public static AmazonS3 getBucketName() {
		return awsstorageUtil.s3;
	}

	public void upload(File file) {
		String key = "mnt/ACSIREPORTS/Static_Files/" + file.getName();
		s3.putObject(this.bucketName, key, file);
	}

	public List<Bucket> listBuckets() {
		for (Bucket bucket : s3.listBuckets()) {
			System.out.println(" bucket name - " + bucket.getName());
		}
		return s3.listBuckets();
	}

	public void getObjectList() {
		System.out.println("Listing objects");
		ObjectListing objectListing = s3.listObjects(new ListObjectsRequest().withBucketName(bucketName));
		//ObjectListing objectListing = s3.listObjects(bucketName, getS3Path("ads"));
		for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
			System.out.println(" - " + objectSummary.getKey() + " " + "(size = " + objectSummary.getSize() + ")");
		}
		System.out.println("Exit: getObjectList()");
	}

	public byte[] getBytesFromS3(String key) throws IOException {
		System.out.println("Downloading an object");
		S3Object object = s3.getObject(new GetObjectRequest(this.bucketName, key));
		S3ObjectInputStream inputStream = object.getObjectContent();
		byte[] bytes = FileCopyUtils.copyToByteArray(inputStream);
		inputStream.close(); // Must be closed as it is directly opened from Amazon
		return bytes;
	}

	public static void main(String args[]) throws Exception {
		System.out.println("Start");
		//File file = new File("D:/Amitabha/Workspaces/inors_workspace/INORS/Codebase/INORS/prism-web/src/main/webapp/scripts/COPPA.pdf");
		AWSStorageUtil aWSStorageUtil = AWSStorageUtil.getInstance();
		//aWSStorageUtil.upload(file);
		aWSStorageUtil.getObjectList();
		//aWSStorageUtil.listBuckets();
		//byte[] bytes = aWSStorageUtil.getBytesFromS3("ads/WebserviceClassDiagram.gif");
		//System.out.println(bytes.length);
		//createDirectoryStructure("D:/Amitabha/", "ads/WebserviceClassDiagram.gif");
		System.out.println("End");
	}

	private static void createDirectoryStructure(String parentDirLoc, String key) throws Exception {
		String dir = parentDirLoc + key.substring(0, key.lastIndexOf("/"));
		String fileName = key.substring(key.lastIndexOf("/")+1);
		System.out.println(dir+", "+fileName);
		File parentDir = new File(dir);
		System.out.println(parentDir.mkdirs());
		File file = new File(dir + "/" + fileName);
		if (!file.isFile()) {
			System.out.println(file.createNewFile());
		}
	}

}