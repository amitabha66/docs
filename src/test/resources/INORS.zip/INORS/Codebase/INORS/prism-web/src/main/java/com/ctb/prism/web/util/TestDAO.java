package com.ctb.prism.web.util;

public interface TestDAO {
	
	public String getMessage(int id);

}
