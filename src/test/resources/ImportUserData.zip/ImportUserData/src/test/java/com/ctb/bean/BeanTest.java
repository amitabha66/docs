package com.ctb.bean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Date;

import javax.sql.rowset.serial.SerialClob;
import javax.sql.rowset.serial.SerialException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.utils.Constants;

public class BeanTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConstants() {
		Constants constants = new Constants();
		assertEquals(File.separator, constants.FILE_SEPARATOR);
		assertEquals(new Integer(1), constants.EMAIL_TYPE_WELCOME);
	}

	@Test
	public void testCustomerConfig() {
		CustomerConfig customerConfig = getCustomerConfig();
		assertNotNull(customerConfig.getCustomerConfigurationId());
		assertNotNull(customerConfig.getCustomerConfigurationName());
		assertNotNull(customerConfig.getCustomerId());
		assertNotNull(customerConfig.getEditable());
		assertNotNull(customerConfig.getDefaultValue());
		assertNotNull(customerConfig.getCreatedBy());
		assertNotNull(customerConfig.getCreatedDateTime());
	}

	@Test
	public void testNode() {
		Node node = getNode();
		assertNotNull(node.getOrgNodeId());
		assertNotNull(node.getCustomerId());
		assertNotNull(node.getOrgNodeCategoryId());
		assertNotNull(node.getOrgNodeName());
		assertNotNull(node.getExtQedPin());
		assertNotNull(node.getExtElmId());
		assertNotNull(node.getExtOrgNodeType());
		assertNotNull(node.getOrgNodeDescription());
		assertNotNull(node.getCreatedBy());
		assertNotNull(node.getCreatedDateTime());
		assertNotNull(node.getUpdatedBy());
		assertNotNull(node.getUpdatedDateTime());
		assertNotNull(node.getActivationStatus());
		assertNotNull(node.getDataImportHistoryId());
		assertNotNull(node.getParentState());
		assertNotNull(node.getParentRegion());
		assertNotNull(node.getParentCounty());
		assertNotNull(node.getParentDistrict());
		assertNotNull(node.getOrgNodeCode());
		assertNotNull(node.getOrgNodeCategoryName());
		assertNotNull(node.getChildNodeCount());
		assertNotNull(node.getParentOrgNodeId());
		assertNotNull(node.getParentOrgNodeName());
		assertNotNull(node.getOrgNodeCategory());
		assertNotNull(node.getEditable());
		assertNotNull(node.getCategoryLevel());
		assertNotNull(node.getMdrNumber());
		assertNotNull(node.getLeafNodePath());

		node = new Node(0);
		assertNotNull(node);
	}

	@Test
	public void testOrgNodeCategory() {
		OrgNodeCategory orgNodeCategory = getOrgNodeCategory();
		assertNotNull(orgNodeCategory.getOrgNodeCategoryId());
		assertNotNull(orgNodeCategory.getCustomerId());
		assertNotNull(orgNodeCategory.getCategoryLevel());
		assertNotNull(orgNodeCategory.getCategoryName());
		assertNotNull(orgNodeCategory.getIsGroup());
		assertNotNull(orgNodeCategory.getCreatedBy());
		assertNotNull(orgNodeCategory.getCreatedDateTime());
		assertNotNull(orgNodeCategory.getUpdatedBy());
		assertNotNull(orgNodeCategory.getUpdatedDateTime());
		assertNotNull(orgNodeCategory.getActivationStatus());
	}

	@Test
	public void testUserFileRow() {
		UserFileRow userFileRow = getUserFileRow();
		assertNotNull(userFileRow.getUserId());
		assertNotNull(userFileRow.getEmail());
		assertNotNull(userFileRow.getFirstName());
		assertNotNull(userFileRow.getMiddleName());
		assertNotNull(userFileRow.getLastName());
		assertNotNull(userFileRow.getUserName());
		assertNotNull(userFileRow.getRoleId());
		assertNotNull(userFileRow.getPassword());
		assertNotNull(userFileRow.getTimeZone());
		assertNotNull(userFileRow.getExtSchoolId());
		assertNotNull(userFileRow.getAddressId());
		assertNotNull(userFileRow.getOrgNodeId());
		assertNotNull(userFileRow.getAddress1());
		assertNotNull(userFileRow.getAddress2());
		assertNotNull(userFileRow.getCity());
		assertNotNull(userFileRow.getState());
		assertNotNull(userFileRow.getZip());
		assertNotNull(userFileRow.getZipCodeExt());
		assertNotNull(userFileRow.getPrimaryPhone());
		assertNotNull(userFileRow.getPrimaryPhoneExt());
		assertNotNull(userFileRow.getSecondaryPhone());
		assertNotNull(userFileRow.getFaxNumber());
		assertNotNull(userFileRow.getRoleName());
		assertNull(userFileRow.getOrganizationNodes());
		assertNotNull(userFileRow.getKey());
		assertNotNull(userFileRow.getBasicUserName());
		assertEquals(false, userFileRow.isAddressPresent());
	}

	@Test
	public void testUserNode() {
		UserNode userNode = getUserNode();
		assertNotNull(userNode.getUserCount());
		assertNotNull(userNode.getProctorCount());
		assertNotNull(userNode.getNumberOfLevels());
		assertNotNull(userNode.getEditable());

		userNode = new UserNode(getNode());
		assertNotNull(userNode);
	}

	@Test
	public void testCustomerConfiguration() {
		CustomerConfiguration cfg = getCustomerConfiguration();
		assertNotNull(cfg.getId());
		assertNotNull(cfg.getCustomerId());
		assertNotNull(cfg.getCustomerConfigurationName());
		assertNotNull(cfg.getEditable());
		assertNotNull(cfg.getDefaultValue());
		assertNotNull(cfg.getCustomerConfigurationValues());
	}

	@Test
	public void testCustomerConfigurationValue() {
		CustomerConfigurationValue cv = getCustomerConfigurationValue();
		assertNotNull(cv.getCustomerConfigurationId());
		assertNotNull(cv.getCustomerConfigurationValue());
		assertNotNull(cv.getSortOrder());
	}

	@Test
	public void testCustomerDemographicValue() {
		CustomerDemographicValue cv = getCustomerDemographicValue();
		assertNotNull(cv.getCustomerDemographicId());
		assertNotNull(cv.getValueName());
		assertNotNull(cv.getValueCode());
		assertNotNull(cv.getSortOrder());
		assertNotNull(cv.getVisible());
		assertNotNull(cv.getCreatedBy());
		assertNotNull(cv.getCreatedDateTime());
	}

	@Test
	public void testCustomerEmail() throws SerialException, SQLException {
		CustomerEmail email = getCustomerEmail();
		assertNotNull(email.getCustomerId());
		assertNotNull(email.getEmailType());
		assertNotNull(email.getReplyTo());
		assertNotNull(email.getSubject());
		assertNull(email.getEmailBody());
		assertNotNull(email.getEmailBodyStr());
		assertNotNull(email.getCreatedBy());
		assertNotNull(email.getCreatedDateTime());
		assertNotNull(email.getContactPhone());

		CustomerEmail email1 = getCustomerEmail();
		email1.setEmailBodyStr(null);
		email1.setEmailBody(null);
		assertNull(email1.getEmailBodyStr());

		CustomerEmail email2 = getCustomerEmail();
		email2.setEmailBodyStr(null);
		Clob emailBody = new SerialClob("Hello World".toCharArray());
		email2.setEmailBody(emailBody);
		assertNotNull(email2.getEmailBodyStr());
	}

	@Test
	public void testDataFileAudit() {
		DataFileAudit audit = getDataFileAudit();
		assertNotNull(audit.getUploadFileRecordCount());
		assertNotNull(audit.getFailedRecordCount());
		assertNotNull(audit.getUserId());
		assertNotNull(audit.getDataFileAuditId());
		assertNotNull(audit.getUploadFileName());
		assertNotNull(audit.getStatus());
		assertNotNull(audit.getCreatedBy());
		assertNotNull(audit.getCreatedDateTime());
		assertNull(audit.getFailedRecord());
		assertNotNull(audit.getCustomerId());
		assertNotNull(audit.getFaildRec());
		assertNotNull(audit.getEditable());
		assertNotNull(audit.getUploadCount());
	}

	@Test
	public void testUserFile() {
		UserFile file = getUserFile();
		assertNull(file.getUserFileRows());
	}

	@Test
	public void testOrganizationNode() {
		OrganizationNode node = getOrganizationNode();
		assertNotNull(node.getStudentCount());
		assertNotNull(node.getBottomLevelNodeFlag());
		assertNotNull(node.getNumberOfLevels());
	}

	@Test
	public void testUploadMoveData() {
		UploadMoveData data = getUploadMoveData();
		assertNotNull(data.getUploadDataFileId());
		assertNotNull(data.getNoOfUserColumn());
		assertNotNull(data.getOrgNodeCategory());
		assertNotNull(data.getUserFileRowHeader());
	}

	@Test
	public void testUserHeader() {
		UserHeader userHeader = getUserHeader();
		assertNotNull(userHeader.getUserHeaderList());
	}

	public CustomerConfig getCustomerConfig() {
		CustomerConfig customerConfig = new CustomerConfig();
		customerConfig.setCustomerConfigurationId(0);
		customerConfig.setCustomerConfigurationName("");
		customerConfig.setCustomerId(0);
		customerConfig.setEditable("");
		customerConfig.setDefaultValue("");
		customerConfig.setCreatedBy(0);
		customerConfig.setCreatedDateTime(new Date());
		return customerConfig;
	}

	public static Node getNode() {
		Node node = new Node();
		node.setOrgNodeId(0);
		node.setCustomerId(0);
		node.setOrgNodeCategoryId(0);
		node.setOrgNodeName("Junit");
		node.setExtQedPin("");
		node.setExtElmId("");
		node.setExtOrgNodeType("");
		node.setOrgNodeDescription("");
		node.setCreatedBy(0);
		node.setCreatedDateTime(new Date());
		node.setUpdatedBy(0);
		node.setUpdatedDateTime(new Date());
		node.setActivationStatus("AC");
		node.setDataImportHistoryId(0);
		node.setParentState("");
		node.setParentRegion("");
		node.setParentCounty("");
		node.setParentDistrict("");
		node.setOrgNodeCode("");
		node.setOrgNodeCategoryName("");
		node.setChildNodeCount(0);
		node.setParentOrgNodeId(0);
		node.setParentOrgNodeName("");
		node.setOrgNodeCategory(getOrgNodeCategory());
		node.setEditable("");
		node.setCategoryLevel(0);
		node.setMdrNumber("");
		node.setLeafNodePath("");
		return node;
	}

	public static OrgNodeCategory getOrgNodeCategory() {
		OrgNodeCategory orgNodeCategory = new OrgNodeCategory();
		orgNodeCategory.setOrgNodeCategoryId(0);
		orgNodeCategory.setCustomerId(0);
		orgNodeCategory.setCategoryLevel(0);
		orgNodeCategory.setCategoryName("");
		orgNodeCategory.setIsGroup("");
		orgNodeCategory.setCreatedBy(0);
		orgNodeCategory.setCreatedDateTime(new Date());
		orgNodeCategory.setUpdatedBy(0);
		orgNodeCategory.setUpdatedDateTime(new Date());
		orgNodeCategory.setActivationStatus("");
		return orgNodeCategory;
	}

	public static UserFileRow getUserFileRow() {
		UserFileRow userFileRow = new UserFileRow();
		userFileRow.setUserId(0);
		userFileRow.setEmail("");
		userFileRow.setFirstName("");
		userFileRow.setMiddleName("");
		userFileRow.setLastName("");
		userFileRow.setUserName("");
		userFileRow.setRoleId(0);
		userFileRow.setPassword("");
		userFileRow.setTimeZone("");
		userFileRow.setExtSchoolId("");
		userFileRow.setAddressId(0);
		userFileRow.setOrgNodeId(0);
		userFileRow.setAddress1("");
		userFileRow.setAddress2("");
		userFileRow.setCity("");
		userFileRow.setState("");
		userFileRow.setZip("");
		userFileRow.setZipCodeExt("");
		userFileRow.setPrimaryPhone("");
		userFileRow.setPrimaryPhoneExt("");
		userFileRow.setSecondaryPhone("");
		userFileRow.setFaxNumber("");
		userFileRow.setRoleName("");
		userFileRow.setOrganizationNodes(null);
		userFileRow.setKey("");
		userFileRow.setBasicUserName("");
		userFileRow.setAddressPresent(false);
		return userFileRow;
	}

	public static UserNode getUserNode() {
		UserNode userNode = new UserNode();
		userNode.setUserCount(0);
		userNode.setProctorCount(0);
		userNode.setNumberOfLevels(0);
		userNode.setEditable("");
		return userNode;
	}

	public static CustomerConfiguration getCustomerConfiguration() {
		CustomerConfiguration cfg = new CustomerConfiguration();
		cfg.setId(0);
		cfg.setCustomerId(0);
		cfg.setCustomerConfigurationName("");
		cfg.setEditable("");
		cfg.setDefaultValue("");
		cfg.setCustomerConfigurationValues(new CustomerConfigurationValue[0]);
		return cfg;
	}

	public static CustomerConfigurationValue getCustomerConfigurationValue() {
		CustomerConfigurationValue cv = new CustomerConfigurationValue();
		cv.setCustomerConfigurationId(0);
		cv.setCustomerConfigurationValue("");
		cv.setSortOrder(0);
		return cv;
	}

	public static CustomerDemographicValue getCustomerDemographicValue() {
		CustomerDemographicValue cv = new CustomerDemographicValue();
		cv.setCustomerDemographicId(0);
		cv.setValueName("");
		cv.setValueCode("");
		cv.setSortOrder(0);
		cv.setVisible("");
		cv.setCreatedBy(0);
		cv.setCreatedDateTime(new Date());
		return cv;
	}

	public static CustomerEmail getCustomerEmail() {
		CustomerEmail email = new CustomerEmail();
		email.setCustomerId(0);
		email.setEmailType(0);
		email.setReplyTo("");
		email.setSubject("");
		email.setEmailBody(null);
		email.setEmailBodyStr("");
		email.setCreatedBy(0);
		email.setCreatedDateTime(new Date());
		email.setContactPhone("");
		return email;
	}

	public static DataFileAudit getDataFileAudit() {
		DataFileAudit audit = new DataFileAudit();
		audit.setUploadFileRecordCount(0);
		audit.setFailedRecordCount(0);
		audit.setUserId(0);
		audit.setDataFileAuditId(0);
		audit.setUploadFileName("");
		audit.setStatus("");
		audit.setCreatedBy(0);
		audit.setCreatedDateTime(new Date());
		audit.setFailedRecord(null);
		audit.setCustomerId(0);
		audit.setFaildRec("".getBytes());
		audit.setEditable("");
		audit.setUploadCount(0);
		return audit;
	}

	public static OrganizationNode getOrganizationNode() {
		OrganizationNode node = new OrganizationNode();
		node.setStudentCount(0);
		node.setBottomLevelNodeFlag("");
		node.setNumberOfLevels(0);
		return node;
	}

	public static UserFile getUserFile() {
		UserFile file = new UserFile();
		file.setUserFileRows(null);
		return file;
	}

	public static UploadMoveData getUploadMoveData() {
		UploadMoveData data = new UploadMoveData();
		data.setUploadDataFileId(0);
		data.setNoOfUserColumn(0);
		data.setOrgNodeCategory(new OrgNodeCategory[0]);
		data.setUserFileRowHeader(new UserFileRow[0]);
		return data;
	}

	public static UserHeader getUserHeader() {
		UserHeader userHeader = new UserHeader();
		return userHeader;
	}

	public static DataFileTemp getDataFileTemp() {
		DataFileTemp dft = new DataFileTemp();
		dft.setDataFileAuditId(0);
		dft.setDataFile("".getBytes());
		return dft;
	}

}
