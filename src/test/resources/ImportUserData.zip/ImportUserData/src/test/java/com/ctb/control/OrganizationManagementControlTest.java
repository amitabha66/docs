package com.ctb.control;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.Node;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.TestUtil;
import com.ctb.utils.cache.OrgMDRDBCacheImpl;

public class OrganizationManagementControlTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	private OrganizationManagementControl cacheControl;

	@Before
	public void setUp() throws Exception {
		cacheControl = new OrganizationManagementControl();
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.sql.SQLException.class) // TODO
	public void testCreateOrganization() throws Exception {
		String userName = "";
		Node inputNode = BeanTest.getNode();
		OrgMDRDBCacheImpl orgMDRImpl = new OrgMDRDBCacheImpl();
		Node outputNode = cacheControl.createOrganization(userName, inputNode, orgMDRImpl);
		assertNotNull(outputNode);

		inputNode.setMdrNumber("hello");
		orgMDRImpl = new OrgMDRDBCacheImpl();
		outputNode = cacheControl.createOrganization(userName, inputNode, orgMDRImpl);
		assertNotNull(outputNode);
		
		inputNode.setMdrNumber("hello");
		orgMDRImpl = new OrgMDRDBCacheImpl();
		orgMDRImpl.addOrgFileRow(inputNode.getMdrNumber(), "");
		outputNode = cacheControl.createOrganization(userName, inputNode, orgMDRImpl);
		assertNotNull(outputNode);
	}

}
