package com.ctb.control;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ctb.bean.BeanTest;
import com.ctb.dao.UserFileDao;
import com.ctb.dao.UserFileDaoImpl;
import com.ctb.mockito.MockFactory;
import com.ctb.utils.cache.OrgMDRDBCacheImpl;
import com.ctb.utils.cache.UserDBCacheImpl;
import com.ctb.utils.cache.UserNewRecordCacheImpl;
import com.ctb.utils.cache.UserUpdateRecordCacheImpl;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UserManagementControl.class })
public class UserManagementControlTest {

	private UserManagementControl control;

	private UserDBCacheImpl dbCacheImpl;
	private OrgMDRDBCacheImpl orgMDRImpl;
	private UserUpdateRecordCacheImpl userUpdateCacheImpl;
	private UserNewRecordCacheImpl userNewCacheImpl;
	private UserFileDaoImpl userFileDao;

	@Before
	public void setUp() throws Exception {
		control = new UserManagementControl();
		MockFactory.mockUserFileDaoImpl(userFileDao, orgMDRImpl, dbCacheImpl, userNewCacheImpl, userUpdateCacheImpl);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testExecuteUserCreation() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		Integer customerId = 0;
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		Map<String, Integer> keyAddressIdMap = new HashMap<String, Integer>();
		control.executeUserCreation(userNewCacheImpl, customerId, keyUserIdMap, keyAddressIdMap);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testExecuteUserUpdate() throws Exception {
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		Integer customerId = 0;
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		Map<String, Integer> keyAddressIdMap = new HashMap<String, Integer>();
		control.executeUserUpdate(userUpdateCacheImpl, customerId, keyUserIdMap, keyAddressIdMap);
	}

}
