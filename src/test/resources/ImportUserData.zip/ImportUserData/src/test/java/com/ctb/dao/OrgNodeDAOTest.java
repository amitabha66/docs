package com.ctb.dao;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.Node;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.TestUtil;

public class OrgNodeDAOTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	OrgNodeDAO dao;

	@Before
	public void setUp() throws Exception {
		dao = new OrgNodeDAO();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.sql.SQLException.class)
	public void testCreateOrganization() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Node orgNode = BeanTest.getNode();
		Node outputNode = dao.createOrganization(orgNode);
		assertNotNull(outputNode);
	}

	@Test(expected = java.lang.Exception.class)
	public void testCreateOrganizationException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Node orgNode = BeanTest.getNode();
		Node outputNode = dao.createOrganization(orgNode);
		assertNotNull(outputNode);
	}

	@Test(expected = java.sql.SQLException.class)
	public void testInsertOrgNodeForParent() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Node orgNode = BeanTest.getNode();
		dao.insertOrgNodeForParent(orgNode);
	}

	@Test(expected = java.lang.Exception.class)
	public void testInsertOrgNodeForParentException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Node orgNode = BeanTest.getNode();
		dao.insertOrgNodeForParent(orgNode);
	}

}
