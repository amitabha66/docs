package com.ctb.dao;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.CustomerConfiguration;
import com.ctb.bean.CustomerConfigurationValue;
import com.ctb.bean.DataFileAudit;
import com.ctb.bean.DataFileTemp;
import com.ctb.bean.OrgNodeCategory;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.TestUtil;

public class UploadFileDaoImplTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	UploadFileDaoImpl dao;

	@Before
	public void setUp() throws Exception {
		dao = new UploadFileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetNextPKForTempFile() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer i = dao.getNextPKForTempFile();
		assertNotNull(i);
	}

	@Test
	public void testCreateDataFileTemp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		DataFileTemp tempFile = BeanTest.getDataFileTemp();
		dao.createDataFileTemp(tempFile);
	}

	@Test
	public void testCheckCustomerConfiguration() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer customerId = 1;
		String configuration = "Highlighter";
		boolean status = dao.checkCustomerConfiguration(customerId, configuration);
		assertNotNull(status);
	}

	@Test
	public void testGetOrgNodeCategories() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer customerId = 1;
		OrgNodeCategory[] array = dao.getOrgNodeCategories(customerId);
		assertNotNull(array);
	}

	@Test
	public void testGetCustomerConfigurations() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer customerId = 1;
		CustomerConfiguration[] array = dao.getCustomerConfigurations(customerId);
		assertNotNull(array);
	}

	@Test
	public void testGetCustomerConfigurationsValue() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer configId = 1;
		CustomerConfigurationValue[] array = dao.getCustomerConfigurationsValue(configId);
		assertNotNull(array);
	}

	@Test
	public void testCreateDataFileAudit() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		DataFileAudit dataFileAudit = BeanTest.getDataFileAudit();
		dao.createDataFileAudit(dataFileAudit);
	}

	@Test
	public void testGetUploadFile() throws IOException {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Integer uploadDataFileId = 0;
		DataFileAudit dfa = dao.getUploadFile(uploadDataFileId);
		assertNotNull(dfa);

		uploadDataFileId = 3220;
		dfa = dao.getUploadFile(uploadDataFileId);
		assertNotNull(dfa);
	}

	@Test
	public void testUpDateAuditTable() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		DataFileAudit dataFileAudit = BeanTest.getDataFileAudit();
		dao.upDateAuditTable(dataFileAudit);
	}

	// //

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testGetNextPKForTempFileException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer i = dao.getNextPKForTempFile();
		assertNotNull(i);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testCreateDataFileTempException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		DataFileTemp tempFile = BeanTest.getDataFileTemp();
		dao.createDataFileTemp(tempFile);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testCheckCustomerConfigurationException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 1;
		String configuration = "Highlighter";
		boolean status = dao.checkCustomerConfiguration(customerId, configuration);
		assertNotNull(status);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testGetOrgNodeCategoriesException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 1;
		OrgNodeCategory[] array = dao.getOrgNodeCategories(customerId);
		assertNotNull(array);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testGetCustomerConfigurationsException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 1;
		CustomerConfiguration[] array = dao.getCustomerConfigurations(customerId);
		assertNotNull(array);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testGetCustomerConfigurationsValueException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer configId = 1;
		CustomerConfigurationValue[] array = dao.getCustomerConfigurationsValue(configId);
		assertNotNull(array);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testCreateDataFileAuditException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		DataFileAudit dataFileAudit = BeanTest.getDataFileAudit();
		dao.createDataFileAudit(dataFileAudit);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testGetUploadFileException() throws IOException {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer uploadDataFileId = 0;
		DataFileAudit dfa = dao.getUploadFile(uploadDataFileId);
		assertNull(dfa);
	}

	@Test
	// (expected = java.lang.Exception.class) // OK
	public void testUpDateAuditTableException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		DataFileAudit dataFileAudit = BeanTest.getDataFileAudit();
		dao.upDateAuditTable(dataFileAudit);
	}

}
