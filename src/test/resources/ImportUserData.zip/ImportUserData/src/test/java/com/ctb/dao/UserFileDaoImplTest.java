package com.ctb.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ctb.bean.BeanTest;
import com.ctb.bean.CustomerEmail;
import com.ctb.bean.DataFileAudit;
import com.ctb.bean.Node;
import com.ctb.bean.TimeZones;
import com.ctb.bean.USState;
import com.ctb.bean.UserFileRow;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.TestUtil;
import com.ctb.utils.cache.OrgMDRDBCacheImpl;
import com.ctb.utils.cache.UserDBCacheImpl;
import com.ctb.utils.cache.UserNewRecordCacheImpl;
import com.ctb.utils.cache.UserUpdateRecordCacheImpl;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UserFileDaoImpl.class })
public class UserFileDaoImplTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	UserFileDaoImpl dao;

	@Before
	public void setUp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		dao = new UserFileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetRoles() throws Exception {
		Map<String, Integer> map = dao.getRoles();
		assertNotNull(map);
	}

	@Test(expected = java.lang.Exception.class) // OK
	public void testGetRolesException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Map<String, Integer> map = dao.getRoles();
		assertNotNull(map);
	}

	@Test
	public void testGetTimeZones() throws Exception {
		TimeZones[] array = dao.getTimeZones();
		assertNotNull(array);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetTimeZonesException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		TimeZones[] array = dao.getTimeZones();
		assertNotNull(array);
	}

	@Test
	public void testGetStates() throws Exception {
		USState[] array = dao.getStates();
		assertNotNull(array);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetStatesException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		USState[] array = dao.getStates();
		assertNotNull(array);
	}

	@Test
	public void testGetUserDataTemplate() throws Exception {
		Integer customerId = 0;
		Node[] array = dao.getUserDataTemplate(customerId);
		assertNotNull(array);

		customerId = 17096;
		array = dao.getUserDataTemplate(customerId);
		assertNotNull(array);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetUserDataTemplateException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 0;
		Node[] array = dao.getUserDataTemplate(customerId);
		assertNotNull(array);
	}

	@Test
	public void testGetExistUserData() throws Exception {
		Integer customerId = 0;
		UserDBCacheImpl dbCache = new UserDBCacheImpl();
		dao.getExistUserData(customerId, dbCache);

		customerId = 1;
		dao.getExistUserData(customerId, dbCache);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetExistUserDataException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 0;
		UserDBCacheImpl dbCache = new UserDBCacheImpl();
		dao.getExistUserData(customerId, dbCache);
	}

	@Test
	public void testGetTopNodeDetails() throws Exception {
		Integer customerId = 0;
		Node[] array = dao.getTopNodeDetails(customerId);
		assertNotNull(array);

		customerId = 1;
		array = dao.getTopNodeDetails(customerId);
		assertNotNull(array);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetTopNodeDetailsException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer customerId = 0;
		Node[] array = dao.getTopNodeDetails(customerId);
		assertNotNull(array);
	}

	@Test
	public void testGetUploadFile() {
		Integer uploadDataFileId = 0;
		DataFileAudit dfa = dao.getUploadFile(uploadDataFileId);
		assertNotNull(dfa);

		uploadDataFileId = 3220;
		dfa = dao.getUploadFile(uploadDataFileId);
		assertNotNull(dfa);
	}
	
	@Test//(expected = java.sql.SQLException.class) // OK
	public void testGetUploadFileSQLException() {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Integer uploadDataFileId = 0;
		DataFileAudit dfa = dao.getUploadFile(uploadDataFileId);
		assertNull(dfa);
	}

	@Test
	public void testGetCustomerEmailByUserName() throws Exception {
		String userName = "";
		Integer emailType = 0;
		CustomerEmail email = dao.getCustomerEmailByUserName(userName, emailType);
		assertNull(email);

		userName = "root_user";
		emailType = 1;
		email = dao.getCustomerEmailByUserName(userName, emailType);
		assertNotNull(email);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testGetCustomerEmailByUserNameException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		String userName = "";
		Integer emailType = 0;
		CustomerEmail email = dao.getCustomerEmailByUserName(userName, emailType);
		assertNull(email);
	}

	@Test
	public void testFindExistingUserName() throws Exception {
		String userName = "";
		String userNameescape = "";
		String whereRegExp = "";
		String selectRegExp = "";
		String replaceStr = "";
		Integer i = dao.findExistingUserName(userName, userNameescape, whereRegExp, selectRegExp, replaceStr);
		assertNotNull(i);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testFindExistingUserNameException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		String userName = "";
		String userNameescape = "";
		String whereRegExp = "";
		String selectRegExp = "";
		String replaceStr = "";
		Integer i = dao.findExistingUserName(userName, userNameescape, whereRegExp, selectRegExp, replaceStr);
		assertNotNull(i);
	}

	@Test
	public void testPopulateActualUserName() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		String userNames = null;
		Integer userCount = 0;
		dao.populateActualUserName(userNewCacheImpl, userNames, userCount);

		userNames = "=''";
		userCount = 0;
		dao.populateActualUserName(userNewCacheImpl, userNames, userCount);

		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		userNames = "='root_user'#='test'";
		userCount = 1;
		dao.populateActualUserName(userNewCacheImpl, userNames, userCount);
	}

	/*@Test
	public void testPopulateActualUserAndAddressIds() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		Integer userCount = 0;
		Integer addressCount = 0;
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		Map<String, Integer> keyAddressIdMap = new HashMap<String, Integer>();
		dao.populateActualUserAndAddressIds(userNewCacheImpl, userCount, addressCount, keyUserIdMap, keyAddressIdMap);

		userCount = 1;
		addressCount = 1;
		keyUserIdMap = new HashMap<String, Integer>();
		keyAddressIdMap = new HashMap<String, Integer>();
		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		dao.populateActualUserAndAddressIds(userNewCacheImpl, userCount, addressCount, keyUserIdMap, keyAddressIdMap);
	}*/

	@Test(expected = java.lang.Exception.class) // OK
	public void testPopulateActualUserAndAddressIdsException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		Integer userCount = 0;
		Integer addressCount = 0;
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		Map<String, Integer> keyAddressIdMap = new HashMap<String, Integer>();
		dao.populateActualUserAndAddressIds(userNewCacheImpl, userCount, addressCount, keyUserIdMap, keyAddressIdMap);
	}

	@Test(expected = java.sql.BatchUpdateException.class)
	public void testInsertAddressForUser() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		dao.insertAddressForUser(userNewCacheImpl);

		UserFileRow user = BeanTest.getUserFileRow();
		user.setAddressPresent(true);
		userNewCacheImpl.addNewUser("test1", user);
		dao.insertAddressForUser(userNewCacheImpl);
	}

	@Test(expected = java.sql.BatchUpdateException.class)
	public void testInsertUserProfile() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		dao.insertUserProfile(userNewCacheImpl);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testInsertUserRole() throws Exception {
		UserNewRecordCacheImpl userNewCacheImpl = new UserNewRecordCacheImpl();
		userNewCacheImpl.addNewUser("test", BeanTest.getUserFileRow());
		dao.insertUserRole(userNewCacheImpl);

		UserFileRow user = BeanTest.getUserFileRow();
		Node[] organizationNodes = new Node[1];
		organizationNodes[0] = BeanTest.getOrganizationNode();
		user.setOrganizationNodes(organizationNodes);
		userNewCacheImpl.addNewUser("test1", user);
		dao.insertUserRole(userNewCacheImpl);
	}

	@Test
	public void testPopulateActualAddressIds() throws Exception {
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		Integer addressCount = 0;
		dao.populateActualAddressIds(userUpdateCacheImpl, addressCount);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testPopulateActualAddressIdsException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		Integer addressCount = 0;
		dao.populateActualAddressIds(userUpdateCacheImpl, addressCount);
	}

	@Test
	public void testUpdateAddressForUser() throws Exception {
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		dao.updateAddressForUser(userUpdateCacheImpl);

		UserFileRow user = BeanTest.getUserFileRow();
		user.setAddressPresent(true);
		userUpdateCacheImpl.addUpdatedUser("test1", user);
		dao.updateAddressForUser(userUpdateCacheImpl);
	}

	@Test
	public void testUpdateUserProfile() throws Exception {
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		dao.updateUserProfile(userUpdateCacheImpl, keyUserIdMap);
	}
	
	@Test(expected = java.lang.Exception.class) // OK
	public void testUpdateUserProfileException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		Map<String, Integer> keyUserIdMap = new HashMap<String, Integer>();
		dao.updateUserProfile(userUpdateCacheImpl, keyUserIdMap);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testUpdateUserRole() throws Exception {
		UserUpdateRecordCacheImpl userUpdateCacheImpl = new UserUpdateRecordCacheImpl();
		userUpdateCacheImpl.addUpdatedUser("test", BeanTest.getUserFileRow());
		dao.updateUserRole(userUpdateCacheImpl);

		UserFileRow user = BeanTest.getUserFileRow();
		Node[] organizationNodes = new Node[1];
		organizationNodes[0] = BeanTest.getOrganizationNode();
		user.setOrganizationNodes(organizationNodes);
		userUpdateCacheImpl.addUpdatedUser("test1", user);
		dao.updateUserRole(userUpdateCacheImpl);

	}

	@Test
	public void testGetExistOrgData() throws Exception {
		Integer customerId = 0;
		OrgMDRDBCacheImpl dbCacheOrgImpl = new OrgMDRDBCacheImpl();
		dao.getExistOrgData(customerId, dbCacheOrgImpl);
	}

	@Test
	public void testGenerateKey() throws Exception {
		Method method = UserFileDaoImpl.class.getDeclaredMethod("generateKey", UserFileRow.class);
		method.setAccessible(true);

		UserFileRow userInfo = BeanTest.getUserFileRow();
		String output = (String) method.invoke(dao, userInfo);
		assertEquals("_", output);
	}

}
