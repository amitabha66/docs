package com.ctb.exception;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class ExceptionsTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCTBBusinessException() {
		System.out.println("ExceptionsTest.testCTBBusinessException()");
		try {
			CTBBusinessException e = new CTBBusinessException("");
			e.setMessage("ExceptionsTest - CTBBusinessException");
			throw e;
		} catch (Exception e) {
			assertEquals("ExceptionsTest - CTBBusinessException", e.getMessage());
		}
	}

	@Test
	public void testFileHeaderException() {
		System.out.println("ExceptionsTest.testFileHeaderException()");
		try {
			FileHeaderException e = new FileHeaderException("");
			e.setMessage("ExceptionsTest - FileHeaderException");
			throw e;
		} catch (Exception e) {
			assertEquals("ExceptionsTest - FileHeaderException", e.getMessage());
		}
	}

	@Test
	public void testFileNotUploadedException() {
		System.out.println("ExceptionsTest.testFileNotUploadedException()");
		try {
			FileNotUploadedException e = new FileNotUploadedException("");
			e.setMessage("ExceptionsTest - FileNotUploadedException");
			throw e;
		} catch (Exception e) {
			assertEquals("ExceptionsTest - FileNotUploadedException", e.getMessage());
		}
	}

}
