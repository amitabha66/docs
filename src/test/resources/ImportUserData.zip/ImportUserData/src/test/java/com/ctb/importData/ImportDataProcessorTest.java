package com.ctb.importData;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.File;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ctb.mockito.MockFactory;
import com.ctb.utils.Configuration;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.FtpSftpUtil;
import com.ctb.utils.TestUtil;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ ImportDataProcessor.class })
public class ImportDataProcessorTest {

	ImportDataProcessor importDataProcessor;
	FtpSftpUtil ftpSftpUtil;
	ExtractUtil extractUtil;
	Configuration configuration;
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	@Before
	public void setUp() throws Exception {
		MockFactory.mockFtpSftpUtil(ftpSftpUtil);
		importDataProcessor = new ImportDataProcessor();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMain() {
		String[] args = new String[] { "QA", dirLoc };
		ImportDataProcessor.main(args);

		args = new String[] { "QA1", dirLoc };
		ImportDataProcessor.main(args);
	}

	/*@Test
	public void testProcessImportedFiles() throws Exception {
		Method method = ImportDataProcessor.class.getDeclaredMethod("processImportedFiles", Map.class);
		method.setAccessible(true);
		Map<String, Long> fileMap = new HashMap<String, Long>();
		method.invoke(importDataProcessor, fileMap);
	}*/

	@Test
	public void testSetFileLastModifiedTime() throws Exception {
		Method method = ImportDataProcessor.class.getDeclaredMethod("setFileLastModifiedTime", File[].class, Map.class);
		method.setAccessible(true);
		File inFile = new File(dirLoc + "engrade_custid_16091.csv");
		File[] listOfFiles = new File[] { inFile };
		Map<String, Long> fileTimeMap = new HashMap<String, Long>();
		method.invoke(importDataProcessor, listOfFiles, fileTimeMap);
	}

	@Test
	public void testReadFileContent() throws Exception {
		Method method = ImportDataProcessor.class.getDeclaredMethod("readFileContent", File.class);
		method.setAccessible(true);
		File inFile = new File(dirLoc + "engrade_custid_16091.csv");
		Integer i = (Integer) method.invoke(importDataProcessor, inFile);
		assertNotNull(i);
	}

	@Test
	public void testAddErrorDataFile() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Method method = ImportDataProcessor.class.getDeclaredMethod("addErrorDataFile", File.class, Integer.class);
		method.setAccessible(true);
		ImportDataProcessor.customerId = 16150;
		File inFile = new File(dirLoc + "engrade_custid_16150.csv");
		Integer uploadDataFileId = 0;
		Integer i = (Integer) method.invoke(importDataProcessor, inFile, uploadDataFileId);
		assertNotNull(i);
	}
	
	@Test(expected=com.ctb.exception.FileNotUploadedException.class)
	public void testAddErrorDataFile1() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Method method = ImportDataProcessor.class.getDeclaredMethod("addErrorDataFile", File.class, Integer.class);
		method.setAccessible(true);
		ImportDataProcessor.customerId = 16150;
		File inFile = new File("test.txt");
		Integer uploadDataFileId = 0;
		Integer i = (Integer) method.invoke(importDataProcessor, inFile, uploadDataFileId);
		assertNotNull(i);
	}

	@Test(expected = java.lang.Exception.class)
	public void testAddErrorDataFileException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Method method = ImportDataProcessor.class.getDeclaredMethod("addErrorDataFile", File.class, Integer.class);
		method.setAccessible(true);
		ImportDataProcessor.customerId = 16150;
		File inFile = new File(dirLoc + "engrade_custid_16091.txt");
		Integer uploadDataFileId = 0;
		Integer i = (Integer) method.invoke(importDataProcessor, inFile, uploadDataFileId);
		fail("Exception is not thrown");
	}

	/*@Test(expected = com.ctb.exception.FileNotUploadedException.class)
	public void testAddErrorDataFileFileHeaderException() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Method method = ImportDataProcessor.class.getDeclaredMethod("addErrorDataFile", File.class, Integer.class);
		method.setAccessible(true);
		File inFile = new File(dirLoc + "nofile.file");
		Integer uploadDataFileId = 0;
		Integer i = (Integer) method.invoke(importDataProcessor, inFile, uploadDataFileId);
		fail("FileHeaderException is not thrown");
	}*/

	@Test(expected = com.ctb.exception.FileHeaderException.class)
	public void testAddErrorDataFile_1() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("Test", dirLoc);
		Method method = ImportDataProcessor.class.getDeclaredMethod("addErrorDataFile", File.class, Integer.class);
		method.setAccessible(true);
		File inFile = new File(dirLoc + "engrade_custid_16091.txt");
		Integer uploadDataFileId = 0;
		Integer i = (Integer) method.invoke(importDataProcessor, inFile, uploadDataFileId);
		fail("FileHeaderException is not thrown");
	}

}
