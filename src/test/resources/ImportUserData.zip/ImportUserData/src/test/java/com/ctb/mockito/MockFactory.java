package com.ctb.mockito;

import java.util.HashMap;
import java.util.Map;

import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

import com.ctb.bean.BeanTest;
import com.ctb.bean.CustomerConfiguration;
import com.ctb.bean.CustomerConfigurationValue;
import com.ctb.bean.DataFileAudit;
import com.ctb.bean.DataFileTemp;
import com.ctb.bean.OrgNodeCategory;
import com.ctb.dao.UploadFileDaoImpl;
import com.ctb.dao.UserFileDaoImpl;
import com.ctb.utils.Configuration;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.FtpSftpUtil;
import com.ctb.utils.SQLUtil;
import com.ctb.utils.cache.OrgMDRDBCacheImpl;
import com.ctb.utils.cache.UserDBCacheImpl;
import com.ctb.utils.cache.UserNewRecordCacheImpl;
import com.ctb.utils.cache.UserUpdateRecordCacheImpl;
import com.jcraft.jsch.Session;

public class MockFactory {

	public static void mockUserFileDaoImpl(UserFileDaoImpl instance, OrgMDRDBCacheImpl orgMDRImpl, UserDBCacheImpl dbCacheImpl,
			UserNewRecordCacheImpl userNewCacheImpl, UserUpdateRecordCacheImpl userUpdateCacheImpl) throws Exception {
		instance = PowerMockito.mock(UserFileDaoImpl.class);
		PowerMockito.whenNew(UserFileDaoImpl.class).withNoArguments().thenReturn(instance);
		PowerMockito.doNothing().when(instance).getExistOrgData(0, orgMDRImpl);
		PowerMockito.doNothing().when(instance).getExistUserData(0, dbCacheImpl);
		PowerMockito.doNothing().when(instance).getExistOrgData(0, orgMDRImpl);
		PowerMockito.doNothing().when(instance).getExistUserData(0, dbCacheImpl);
		PowerMockito.doNothing().when(instance).populateActualUserName(userNewCacheImpl, "", 0);
		PowerMockito.doNothing().when(instance).populateActualUserAndAddressIds(userNewCacheImpl, 0, 0, new HashMap<String, Integer>(), new HashMap<String, Integer>());
		PowerMockito.doNothing().when(instance).insertAddressForUser(userNewCacheImpl);
		PowerMockito.doNothing().when(instance).insertUserProfile(userNewCacheImpl);
		PowerMockito.doNothing().when(instance).insertUserRole(userNewCacheImpl);
		PowerMockito.doNothing().when(instance).populateActualAddressIds(userUpdateCacheImpl, 0);
		PowerMockito.doNothing().when(instance).updateAddressForUser(userUpdateCacheImpl);
		PowerMockito.doNothing().when(instance).updateUserProfile(userUpdateCacheImpl, new HashMap<String, Integer>());
		PowerMockito.doNothing().when(instance).updateUserRole(userUpdateCacheImpl);
	}

	public static void mockUploadFileDao(UploadFileDaoImpl instance) throws Exception {
		instance = PowerMockito.mock(UploadFileDaoImpl.class);
		PowerMockito.whenNew(UploadFileDaoImpl.class).withNoArguments().thenReturn(instance);
		PowerMockito.when(instance.getNextPKForTempFile()).thenReturn(0);
		PowerMockito.when(instance.checkCustomerConfiguration(0, "")).thenReturn(true);

		PowerMockito.when(instance.getOrgNodeCategories(0)).thenReturn(new OrgNodeCategory[] { BeanTest.getOrgNodeCategory() });
		PowerMockito.when(instance.getCustomerConfigurations(0)).thenReturn(new CustomerConfiguration[] { BeanTest.getCustomerConfiguration() });
		PowerMockito.when(instance.getCustomerConfigurationsValue(0)).thenReturn(new CustomerConfigurationValue[] { BeanTest.getCustomerConfigurationValue() });
		PowerMockito.when(instance.getUploadFile(0)).thenReturn(new DataFileAudit());

		// Void methods
		PowerMockito.doNothing().when(instance).createDataFileTemp(new DataFileTemp());
		PowerMockito.doNothing().when(instance).createDataFileAudit(new DataFileAudit());
		PowerMockito.doNothing().when(instance).upDateAuditTable(new DataFileAudit());
	}

	public static void mockSQLUtil(SQLUtil instance) throws Exception {
		instance = PowerMockito.mock(SQLUtil.class);
		PowerMockito.whenNew(SQLUtil.class).withNoArguments().thenReturn(instance);
	}

	public static void mockFtpSftpUtil(FtpSftpUtil instance) throws Exception {
		instance = PowerMockito.mock(FtpSftpUtil.class);
		PowerMockito.whenNew(FtpSftpUtil.class).withNoArguments().thenReturn(instance);
		Session session = null;
		String sourceDir = "";
		String targetDir = "";
		Map<String, Long> fileTimeMap = new HashMap<String, Long>();
		//PowerMockito.doNothing().when(instance);
		// FtpSftpUtil.downloadFiles(session, sourceDir, targetDir,
		// fileTimeMap);
		// Void methods
		//PowerMockito.doNothing().when(instance).downloadFiles(session, sourceDir, targetDir, fileTimeMap);
	}

	public static void mockExtractUtil(ExtractUtil instance) throws Exception {
		instance = PowerMockito.mock(ExtractUtil.class);
		PowerMockito.whenNew(ExtractUtil.class).withNoArguments().thenReturn(instance);

		// PowerMockito.doNothing().when(instance);
		PowerMockito.mockStatic(ExtractUtil.class);
		// PowerMockito.when(ExtractUtil.getDetail("")).thenReturn("");
		// PowerMockito.when(instance.getDetail("")).thenReturn(new String());
	}

	public static void mockConfiguration(Configuration instance) throws Exception {
		instance = PowerMockito.mock(Configuration.class);
		PowerMockito.whenNew(Configuration.class).withNoArguments().thenReturn(instance);
		PowerMockito.when(instance.getLog4jFile()).thenReturn(new String());
	}
}
