package com.ctb.mockito.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ctb.bean.BeanTest;
import com.ctb.bean.Node;
import com.ctb.bean.OrgNodeCategory;
import com.ctb.bean.UserFileRow;
import com.ctb.control.OrganizationManagementControl;
import com.ctb.control.UserManagementControl;
import com.ctb.dao.UploadFileDaoImpl;
import com.ctb.dao.UserFileDaoImpl;
import com.ctb.mockito.MockFactory;
import com.ctb.utils.Constants;
import com.ctb.utils.ExtractUtil;
import com.ctb.utils.SQLUtil;
import com.ctb.utils.TestUtil;
import com.ctb.utils.UploadUserFile;
import com.ctb.utils.cache.OrgMDRDBCacheImpl;
import com.ctb.utils.cache.UserDBCacheImpl;
import com.ctb.utils.cache.UserNewRecordCacheImpl;
import com.ctb.utils.cache.UserUpdateRecordCacheImpl;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UploadUserFile.class })
public class UploadUserFileMockitoTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	private final String VALID_FAX = "123-456-7890";
	private final String INVALID_FAX = "123 456 7890";
	private final String VALID_NAME_STRING = "aaa";
	private final String INVALID_NAME_STRING = "~~~";

	UploadUserFile uploadUserFile;

	// com.ctb.utils.cache
	private UserDBCacheImpl dbCacheImpl;
	private OrgMDRDBCacheImpl orgMDRImpl;
	private UserUpdateRecordCacheImpl userUpdateCacheImpl;
	private UserNewRecordCacheImpl userNewCacheImpl;

	// com.ctb.dao
	private UserFileDaoImpl userFileDao;
	private UploadFileDaoImpl uploadFileDao;

	// com.ctb.control
	private OrganizationManagementControl organizationManagement;
	private UserManagementControl userManagement;

	// com.ctb.util
	private SQLUtil sqlUtil;

	// private ExtractUtil extractUtil;
	// private Configuration configuration;

	@Before
	public void setUp() throws Exception {
		mockCacheLayer();
		mockDaoLayer();
		mockControlLayer();
		mockUtilLayer();
		instantiate();
	}

	private void instantiate() {
		Integer customerId = 0;
		File inFile = new File(dirLoc + "engrade_custid_16091.csv");
		Integer uploadFileId = 0;
		OrgNodeCategory[] orgNodeCategory = new OrgNodeCategory[0];
		UserFileRow[] userFileRowHeader = new UserFileRow[0];
		int noOfUserColumn = 0;
		uploadUserFile = new UploadUserFile(customerId, inFile, uploadFileId, orgNodeCategory, userFileRowHeader, noOfUserColumn);
	}

	private void mockCacheLayer() throws Exception {
		dbCacheImpl = PowerMockito.mock(UserDBCacheImpl.class);
		PowerMockito.whenNew(UserDBCacheImpl.class).withNoArguments().thenReturn(dbCacheImpl);

		orgMDRImpl = PowerMockito.mock(OrgMDRDBCacheImpl.class);
		PowerMockito.whenNew(OrgMDRDBCacheImpl.class).withNoArguments().thenReturn(orgMDRImpl);

		userUpdateCacheImpl = PowerMockito.mock(UserUpdateRecordCacheImpl.class);
		PowerMockito.whenNew(UserUpdateRecordCacheImpl.class).withNoArguments().thenReturn(userUpdateCacheImpl);

		userNewCacheImpl = PowerMockito.mock(UserNewRecordCacheImpl.class);
		PowerMockito.whenNew(UserNewRecordCacheImpl.class).withNoArguments().thenReturn(userNewCacheImpl);
	}

	private void mockDaoLayer() throws Exception {

		MockFactory.mockUserFileDaoImpl(userFileDao, orgMDRImpl, dbCacheImpl, userNewCacheImpl, userUpdateCacheImpl);

		uploadFileDao = PowerMockito.mock(UploadFileDaoImpl.class);
		PowerMockito.whenNew(UploadFileDaoImpl.class).withNoArguments().thenReturn(uploadFileDao);
	}

	private void mockControlLayer() throws Exception {
		organizationManagement = PowerMockito.mock(OrganizationManagementControl.class);
		PowerMockito.whenNew(OrganizationManagementControl.class).withNoArguments().thenReturn(organizationManagement);

		userManagement = PowerMockito.mock(UserManagementControl.class);
		PowerMockito.whenNew(UserManagementControl.class).withNoArguments().thenReturn(userManagement);
	}

	private void mockUtilLayer() throws Exception {
		MockFactory.mockSQLUtil(sqlUtil);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.ArrayIndexOutOfBoundsException.class)
	public void testStartProcessing() throws Exception {
		uploadUserFile.startProcessing();
	}

	@Test
	public void testTokenize() {
		String parameter = "a,b,c";
		String delimiter = ",";
		String[] tokens = UploadUserFile.tokenize(parameter, delimiter);
		assertNotNull(tokens);
	}

	@Test
	public void testSetServerFilePath() {
		uploadUserFile.setServerFilePath("");
	}

	@Test
	public void testGetServerFilePath() {
		String s = uploadUserFile.getServerFilePath();
		assertNull(s);
	}

	@Test
	public void testSetUserFileRowHeader() {
		uploadUserFile.setUserFileRowHeader(new UserFileRow[0]);
	}

	@Test
	public void testGetUserFileRowHeader() {
		UserFileRow[] rows = uploadUserFile.getUserFileRowHeader();
		assertNotNull(rows);
	}

	@Test
	public void testSetUsername() {
		uploadUserFile.setUsername("");
	}

	@Test
	public void testSetUploadDt() {
		uploadUserFile.setUploadDt(new Date());
	}

	@Test
	public void testSetNoOfHeaderRows() {
		uploadUserFile.setNoOfHeaderRows(0);
	}

	@Test
	public void testGetFailedRecordCount() {
		int i = uploadUserFile.getFailedRecordCount();
		assertNotNull(i);
	}

	@Test
	public void testSetFailedRecordCount() {
		uploadUserFile.setFailedRecordCount(0);
	}

	@Test
	public void testGetUploadRecordCount() {
		int i = uploadUserFile.getUploadRecordCount();
		assertNotNull(i);
	}

	@Test
	public void testSetUploadRecordCount() {
		uploadUserFile.setUploadRecordCount(0);
	}

	/**
	 * Private Method
	 * 
	 * @throws Exception
	 */
	@Test
	public void testIsValidMDR() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isValidMDR", int.class, boolean.class, String.class, Integer[].class, Integer.class, Map.class,
				Map.class, Map.class, List.class, String.class, String.class, String.class, OrgMDRDBCacheImpl.class);
		method.setAccessible(true);

		int cellPos = 0;
		boolean isMatchUploadOrgIds = false;
		String orgCode = "";
		Integer[] parentOrgId = new Integer[] { 0 };
		Integer categoryId = 0;
		Map<Integer, ArrayList<String>> requiredMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> invalidCharMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> logicalErrorMap = new HashMap<Integer, ArrayList<String>>();
		List<String> newMDRList = new ArrayList<String>();
		String strCellMdr = "";
		String orgName = "";
		String strCellHeaderMdr = "";
		OrgMDRDBCacheImpl orgMDRImpl = new OrgMDRDBCacheImpl();
		boolean status = (Boolean) method.invoke(uploadUserFile, cellPos, isMatchUploadOrgIds, orgCode, parentOrgId, categoryId, requiredMap, invalidCharMap,
				logicalErrorMap, newMDRList, strCellMdr, orgName, strCellHeaderMdr, orgMDRImpl);
		assertNotNull(status);
	}

	@Test
	public void testIsOrganizationExists() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isOrganizationExists", boolean.class, String.class, Integer[].class, Integer.class,
				String.class, String.class);
		method.setAccessible(true);

		boolean isMatchUploadOrgIds = false;
		String orgCode = "";
		Integer[] parentOrgIdArray = new Integer[] { 0 };
		Integer categoryId = 0;
		String strCellMdr = "";
		String orgName = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, isMatchUploadOrgIds, orgCode, parentOrgIdArray, categoryId, strCellMdr, orgName);
		assertNotNull(status);
	}

	@Test
	public void testValidMdrNo() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validMdrNo", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);
	}

	@Test
	public void testValidMdrNoLength() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validMdrNoLength", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);
	}

	@Test
	public void testIsUniqueMdr() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isUniqueMdr", String.class, List.class, OrgMDRDBCacheImpl.class);
		method.setAccessible(true);

		String str = "";
		List<String> list = new ArrayList<String>();
		OrgMDRDBCacheImpl orgMDRImpl = new OrgMDRDBCacheImpl();
		boolean status = (Boolean) method.invoke(uploadUserFile, str, list, orgMDRImpl);
		assertNotNull(status);
	}

	@Test
	public void testValidMdrNoNumeric() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validMdrNoNumeric", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);
	}

	@Test(expected = com.ctb.exception.FileNotUploadedException.class)
	public void testCreateOrganizationAndUser() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("createOrganizationAndUser", Map.class, Map.class, Map.class, Map.class, Map.class, Map.class,
				Map.class, boolean.class, Node[].class, OrgMDRDBCacheImpl.class);
		method.setAccessible(true);

		Map<Integer, ArrayList<String>> requiredMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> maxLengthMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> invalidCharMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> logicalErrorMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> hierarchyErrorMap = new HashMap<Integer, ArrayList<String>>();
		Map<String, String> userDataMap = new HashMap<String, String>();
		Map<Integer, String> blankRowMap = new HashMap<Integer, String>();
		boolean isMatchUploadOrgIds = false;
		Node[] loginUserNodes = new Node[] { BeanTest.getNode() };
		// OrgMDRDBCacheImpl orgMDRImpl;

		method.invoke(uploadUserFile, requiredMap, maxLengthMap, invalidCharMap, logicalErrorMap, hierarchyErrorMap, userDataMap, blankRowMap,
				isMatchUploadOrgIds, loginUserNodes, orgMDRImpl);
	}

	@Test
	public void testInit() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("init");
		method.setAccessible(true);
		method.invoke(uploadUserFile);
	}

	@Test
	public void testGetCategoryId() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("getCategoryId", String.class, Node[].class);
		method.setAccessible(true);

		Node[] nodes = new Node[] {};
		String str = "";
		Integer i = (Integer) method.invoke(uploadUserFile, str, nodes);
		assertNull(i);
	}

	@Test
	public void tesGetLoginUserOrgDetail() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("getLoginUserOrgDetail", Node[].class, String.class);
		method.setAccessible(true);

		Node[] loginUserNodes = new Node[] { BeanTest.getNode() };
		String organizationName = "";
		Node node = (Node) method.invoke(uploadUserFile, loginUserNodes, organizationName);
		assertNotNull(node);

		organizationName = "Junit";
		node = (Node) method.invoke(uploadUserFile, loginUserNodes, organizationName);
		assertNotNull(node);
	}

	@Test
	public void tesIsOrganizationExist() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isOrganizationExist", String.class, Integer.class, Integer.class, boolean.class);
		method.setAccessible(true);

		String searchString = "";
		Integer parentId = 0;
		Integer categoryId = 0;
		boolean isMatchUploadOrgIds = false;
		boolean status = (Boolean) method.invoke(uploadUserFile, searchString, parentId, categoryId, isMatchUploadOrgIds);
		assertEquals(false, status);
	}

	@Test
	public void tesGetOrgNodeDetail() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("getOrgNodeDetail", String.class, Integer.class, Integer.class, boolean.class);
		method.setAccessible(true);

		String orgName = "";
		Integer parentId = 0;
		Integer categoryId = 0;
		boolean isMatchUploadOrgIds = false;
		Node node = (Node) method.invoke(uploadUserFile, orgName, parentId, categoryId, isMatchUploadOrgIds);
		assertNull(node);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void tesCreateUpdateUser() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("createUpdateUser", Map.class, Node[].class);
		method.setAccessible(true);

		Map<String, String> userDataMap = new HashMap<String, String>();
		Node[] userNode = new Node[] { BeanTest.getNode() };
		method.invoke(uploadUserFile, userDataMap, userNode);
	}

	@Test
	public void testIsAddressPresent() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isAddressPresent", UserFileRow.class);
		method.setAccessible(true);

		UserFileRow user = BeanTest.getUserFileRow();
		boolean status = (Boolean) method.invoke(uploadUserFile, user);
		assertEquals(false, status);
	}

	@Test
	public void testIsUserExists() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isUserExists", UserFileRow.class);
		method.setAccessible(true);

		UserFileRow user = BeanTest.getUserFileRow();
		UserFileRow row = (UserFileRow) method.invoke(uploadUserFile, user);
		assertNull(row);
	}

	@Test
	public void testIsOrganizationPresent() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isOrganizationPresent", Integer.class, Node[].class);
		method.setAccessible(true);

		Integer orgNodeId = 0;
		Node[] orgNodes = new Node[] {};
		boolean status = (Boolean) method.invoke(uploadUserFile, orgNodeId, orgNodes);
		assertNotNull(status);
	}

	@Test
	public void testErrorExcelCreation() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		Method method = UploadUserFile.class.getDeclaredMethod("errorExcelCreation", Map.class, Map.class, Map.class, Map.class, Map.class);
		method.setAccessible(true);

		Map<Integer, ArrayList<String>> requiredMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> maxLengthMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> invalidCharMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> logicalErrorMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> hierarchyErrorMap = new HashMap<Integer, ArrayList<String>>();
		method.invoke(uploadUserFile, requiredMap, maxLengthMap, invalidCharMap, logicalErrorMap, hierarchyErrorMap);
	}

	@Test
	public void testHasOrganization() throws Exception {
		Field privateUserFileRowHeaderArray = UploadUserFile.class.getDeclaredField("userFileRowHeader");
		privateUserFileRowHeaderArray.setAccessible(true);
		Method method = UploadUserFile.class.getDeclaredMethod("hasOrganization", int.class, String[].class);
		method.setAccessible(true);

		int currentPosition = 0;
		String[] row = new String[] {};
		UserFileRow userFileRow = BeanTest.getUserFileRow();
		userFileRow.setOrganizationNodes(new Node[] { BeanTest.getNode() });
		UserFileRow[] userFileRowHeader = new UserFileRow[] { userFileRow };
		privateUserFileRowHeaderArray.set(uploadUserFile, userFileRowHeader);
		boolean status = (Boolean) method.invoke(uploadUserFile, currentPosition, row);
		assertNotNull(status);
	}

	@Test
	public void testGetLoginUserOrgPosition() throws Exception {
		Field privateUserFileRowHeaderArray = UploadUserFile.class.getDeclaredField("userFileRowHeader");
		privateUserFileRowHeaderArray.setAccessible(true);
		Method method = UploadUserFile.class.getDeclaredMethod("getLoginUserOrgPosition", String[].class, String[].class, Node[].class);
		method.setAccessible(true);

		String[] row = new String[] { "" };
		String[] rowHeader = new String[] { "" };
		Node[] loginUserNode = new Node[] {};
		UserFileRow userFileRow = BeanTest.getUserFileRow();
		userFileRow.setOrganizationNodes(new Node[] { BeanTest.getNode() });
		UserFileRow[] userFileRowHeader = new UserFileRow[] { userFileRow };
		privateUserFileRowHeaderArray.set(uploadUserFile, userFileRowHeader);
		int status = (Integer) method.invoke(uploadUserFile, row, rowHeader, loginUserNode);
		assertNotNull(status);
	}

	@Test
	public void testGetEachRowUserDetail() throws Exception {
		Field privateUserFileRowHeaderArray = UploadUserFile.class.getDeclaredField("userFileRowHeader");
		privateUserFileRowHeaderArray.setAccessible(true);
		Method method = UploadUserFile.class.getDeclaredMethod("getEachRowUserDetail", int.class, String[].class, String[].class, Map.class, Map.class,
				Map.class, Map.class, boolean.class);
		method.setAccessible(true);

		int rowPosition = 0;
		String[] row = new String[] {};
		String[] rowHeader = new String[] {};
		Map<Integer, ArrayList<String>> requiredMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> maxLengthMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> invalidCharMap = new HashMap<Integer, ArrayList<String>>();
		Map<Integer, ArrayList<String>> logicalErrorMap = new HashMap<Integer, ArrayList<String>>();
		boolean isMatchUploadOrgIds = false;
		UserFileRow userFileRow = BeanTest.getUserFileRow();
		userFileRow.setOrganizationNodes(new Node[] { BeanTest.getNode() });
		UserFileRow[] userFileRowHeader = new UserFileRow[] { userFileRow };
		privateUserFileRowHeaderArray.set(uploadUserFile, userFileRowHeader);
		method.invoke(uploadUserFile, rowPosition, row, rowHeader, requiredMap, maxLengthMap, invalidCharMap, logicalErrorMap, isMatchUploadOrgIds);

		// rowPosition = 0;
		// row = new String[] {};
		// rowHeader = new String[] {};
		// requiredMap = new HashMap<Integer, ArrayList<String>>();
		// maxLengthMap = new HashMap<Integer, ArrayList<String>>();
		// invalidCharMap = new HashMap<Integer, ArrayList<String>>();
		// logicalErrorMap = new HashMap<Integer, ArrayList<String>>();
		// isMatchUploadOrgIds = false;
		// method.invoke(uploadUserFile, rowPosition, row, rowHeader,
		// requiredMap, maxLengthMap, invalidCharMap, logicalErrorMap,
		// isMatchUploadOrgIds);
	}

	@Test
	public void testIsLogicalError() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isLogicalError", int.class, String[].class, String[].class, List.class, boolean.class);
		method.setAccessible(true);

		int userHeaderStartPosition = 0;
		String[] row = new String[] {};
		String[] rowHeader = new String[] {};
		List<String> list = new ArrayList<String>();
		boolean isMatchUploadOrgIds = false;
		boolean status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list, isMatchUploadOrgIds);
		System.out.println(status);
		assertFalse(status);

		userHeaderStartPosition = 0;
		row = new String[] { "" };
		rowHeader = new String[] { "" };
		list = new ArrayList<String>();
		isMatchUploadOrgIds = false;
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list, isMatchUploadOrgIds);
		System.out.println(status);
		assertFalse(status);

		userHeaderStartPosition = 0;
		row = new String[] { "a" };
		rowHeader = new String[] { Constants.REQUIREDFIELD_TIME_ZONE };
		list = new ArrayList<String>();
		isMatchUploadOrgIds = false;
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list, isMatchUploadOrgIds);
		System.out.println(status);
		assertTrue(status);

		userHeaderStartPosition = 0;
		row = new String[] { "a" };
		rowHeader = new String[] { Constants.REQUIREDFIELD_ROLE };
		list = new ArrayList<String>();
		isMatchUploadOrgIds = false;
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list, isMatchUploadOrgIds);
		System.out.println(status);
		assertTrue(status);

		userHeaderStartPosition = 0;
		row = new String[] { "a" };
		rowHeader = new String[] { Constants.STATE_NAME };
		list = new ArrayList<String>();
		isMatchUploadOrgIds = false;
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list, isMatchUploadOrgIds);
		System.out.println(status);
		assertTrue(status);
	}

	@Test
	public void testIsRoleNameSame() throws Exception {
		Field privateMap = UploadUserFile.class.getDeclaredField("roleMap");
		privateMap.setAccessible(true);
		Method method = UploadUserFile.class.getDeclaredMethod("isRoleNameSame", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertFalse(status);

		str = "hello";
		Map<String, String> roleMap = new HashMap<String, String>();
		roleMap.put("Hello", "");
		privateMap.set(uploadUserFile, roleMap);
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertTrue(status);
	}

	@Test
	public void testIsTimeZoneSame() throws Exception {
		Field privateMap = UploadUserFile.class.getDeclaredField("timeZoneMap");
		privateMap.setAccessible(true);

		Method method = UploadUserFile.class.getDeclaredMethod("isTimeZoneSame", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertFalse(status);

		str = "hello";
		Map<String, String> timeZoneMap = new HashMap<String, String>();
		timeZoneMap.put("Hello", "");
		privateMap.set(uploadUserFile, timeZoneMap);
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertTrue(status);
	}

	@Test
	public void testInitCap() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("initCap", String.class);
		method.setAccessible(true);

		String str = null;
		String result = (String) method.invoke(uploadUserFile, str);
		assertNull(result);

		str = "";
		result = (String) method.invoke(uploadUserFile, str);
		assertNull(result);

		str = "hello";
		result = (String) method.invoke(uploadUserFile, str);
		assertEquals("Hello", result);

		str = "hello beautiful world";
		result = (String) method.invoke(uploadUserFile, str);
		assertEquals("Hello Beautiful World", result);

		str = "hello  beautiful world";
		result = (String) method.invoke(uploadUserFile, str);
		assertEquals("Hello Beautiful World", result);
	}

	@Test
	public void testInitStringCap() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("initStringCap", String.class);
		method.setAccessible(true);

		String str = "";
		String result = (String) method.invoke(uploadUserFile, str);
		assertNotNull(result);

		str = "hello";
		result = (String) method.invoke(uploadUserFile, str);
		assertEquals("Hello", result);
	}

	@Test
	public void testIsStateSame() throws Exception {
		Field privateMap = UploadUserFile.class.getDeclaredField("stateMap");
		privateMap.setAccessible(true);
		Method method = UploadUserFile.class.getDeclaredMethod("isStateSame", String.class);
		method.setAccessible(true);

		String str = "";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertFalse(status);

		str = "hello";
		Map<String, String> stateMap = new HashMap<String, String>();
		stateMap.put("Hello", "");
		privateMap.set(uploadUserFile, stateMap);
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertTrue(status);
	}

	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void testIsLoginUserOrganization() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isLoginUserOrganization", String.class, Node[].class, boolean.class);
		method.setAccessible(true);

		String orgName = "";
		Node[] loginUserNode = new Node[] {};
		boolean isMatchUploadOrgIds = false;
		boolean status = (Boolean) method.invoke(uploadUserFile, orgName, loginUserNode, isMatchUploadOrgIds);
		assertNotNull(status);

		orgName = "";
		loginUserNode = new Node[] { BeanTest.getNode() };
		isMatchUploadOrgIds = false;
		status = (Boolean) method.invoke(uploadUserFile, orgName, loginUserNode, isMatchUploadOrgIds);
		assertNotNull(status);

		orgName = "";
		loginUserNode = new Node[] { BeanTest.getNode() };
		isMatchUploadOrgIds = true;
		status = (Boolean) method.invoke(uploadUserFile, orgName, loginUserNode, isMatchUploadOrgIds);
		assertNotNull(status);
	}

	@Test
	public void testIsRequired() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isRequired", int.class, String[].class, String[].class, List.class);
		method.setAccessible(true);

		int userHeaderStartPosition = 0;
		String[] row = new String[] { "", "", "", "" };
		String[] rowHeader = new String[] { "A", "B", "C", "D" };
		List<String> list = new ArrayList<String>();
		boolean status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertEquals(false, status);

		row = new String[] { "", "", "", "", "", "" };
		rowHeader = new String[] { Constants.REQUIREDFIELD_FIRST_NAME, Constants.REQUIREDFIELD_LAST_NAME, Constants.REQUIREDFIELD_ROLE,
				Constants.REQUIREDFIELD_TIME_ZONE, Constants.EXT_SCHOOL_ID, "Hello World" };
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertEquals(true, status);

		row = new String[] { "a", "b", "c", "d", "e", "f" };
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertEquals(true, status);
	}

	@Test
	public void testIsInvalidChar() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isInvalidChar", int.class, String[].class, String[].class, List.class);
		method.setAccessible(true);

		int userHeaderStartPosition = 0;
		String[] row = new String[] {};
		String[] rowHeader = new String[] {};
		List<String> list = new ArrayList<String>();
		boolean status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);

		row = new String[] { VALID_NAME_STRING, VALID_NAME_STRING, VALID_NAME_STRING, VALID_NAME_STRING, "e", VALID_NAME_STRING, VALID_NAME_STRING, "h", "i",
				"j", "k", VALID_FAX, "" };
		rowHeader = new String[] { Constants.REQUIREDFIELD_FIRST_NAME, Constants.MIDDLE_NAME, Constants.REQUIREDFIELD_LAST_NAME, Constants.EXT_SCHOOL_ID,
				Constants.EMAIL, Constants.ADDRESS_LINE_1, Constants.ADDRESS_LINE_2, Constants.CITY, Constants.ZIP, Constants.PRIMARY_PHONE,
				Constants.SECONDARY_PHONE, Constants.FAX, "Hello World" };
		list = new ArrayList<String>();
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);

		row = new String[] { INVALID_NAME_STRING, INVALID_NAME_STRING, INVALID_NAME_STRING, INVALID_NAME_STRING, "e", INVALID_NAME_STRING, INVALID_NAME_STRING,
				"~", "i", "j", "k", "l", "" };
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);
	}

	@Test
	public void testGetCellValue() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("getCellValue", String.class);
		method.setAccessible(true);

		String str = "aaa ";
		String result = (String) method.invoke(uploadUserFile, str);
		assertEquals(VALID_NAME_STRING, result);

		str = null;
		result = (String) method.invoke(uploadUserFile, str);
		assertEquals("", result);
	}

	@Test
	public void testIsMaxlengthExceed() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxlengthExceed", int.class, String[].class, String[].class, List.class);
		method.setAccessible(true);

		int userHeaderStartPosition = 0;
		String[] row = new String[] { "a", "b", "c", "" };
		String[] rowHeader = new String[] { "A", "B", "C", "D" };
		List<String> list = new ArrayList<String>();
		boolean status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);

		// userHeaderStartPosition = 0;
		row = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "" };
		rowHeader = new String[] { Constants.REQUIREDFIELD_FIRST_NAME, Constants.MIDDLE_NAME, Constants.REQUIREDFIELD_LAST_NAME, Constants.EMAIL,
				Constants.EXT_SCHOOL_ID, Constants.REQUIREDFIELD_TIME_ZONE, Constants.ADDRESS_LINE_1, Constants.ADDRESS_LINE_2, Constants.CITY, Constants.ZIP,
				Constants.PRIMARY_PHONE, Constants.SECONDARY_PHONE, Constants.FAX, "Hello World" };
		list = new ArrayList<String>();
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);

		// userHeaderStartPosition = 0;
		row = new String[] {
				"123456789012345678901234567890123",
				"123456789012345678901234567890123",
				"123456789012345678901234567890123",
				"123456789012345678901234567890123123456789012345678901234567890123",
				"123456789012345678901234567890123",
				"123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123123456789012345678901234567890123",
				"123456789012345678901234567890123123456789012345678901234567890123", "123456789012345678901234567890123123456789012345678901234567890123",
				"123456789012345678901234567890123123456789012345678901234567890123", "123456789012345678901234567890123", "123456789012345678901234567890123",
				"123456789012345678901234567890123", "123456789012345678901234567890123", "" };
		// rowHeader = new String[] { Constants.REQUIREDFIELD_FIRST_NAME,
		// Constants.MIDDLE_NAME, "C", "D", "C", "D", "C", "D", "C", "D", "C",
		// "D", "C", "D" };
		list = new ArrayList<String>();
		status = (Boolean) method.invoke(uploadUserFile, userHeaderStartPosition, row, rowHeader, list);
		assertNotNull(status);

	}

	@Test
	public void testIsMaxLength15() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxLength15", String.class);
		method.setAccessible(true);

		String str = "123";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);
		// 16
		str = "1234567890123456";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testIsMaxLength32() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxLength32", String.class);
		method.setAccessible(true);

		String str = "123";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);
		// 33
		str = "123456789012345678901234567890123";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testIsMaxLength64() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxLength64", String.class);
		method.setAccessible(true);

		String str = "123";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);
		// 70
		str = "1234567890123456789012345678901234567890123456789012345678901234567890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testIsMaxLength255() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxLength255", String.class);
		method.setAccessible(true);

		String str = "123";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);
		// 260
		str = "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testIsMaxLength50() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isMaxLength50", String.class);
		method.setAccessible(true);

		String str = "123";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = "123456789012345678901234567890123456789012345678901";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testValidAddressString() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validAddressString", String.class);
		method.setAccessible(true);

		String str = VALID_NAME_STRING;
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = INVALID_NAME_STRING;
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testValidAddressCharacter() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validAddressCharacter", char.class);
		method.setAccessible(true);

		boolean status = (Boolean) method.invoke(uploadUserFile, 'A');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, 'a');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '0');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '.');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, ',');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '~');
		assertEquals(false, status);

		status = (Boolean) method.invoke(uploadUserFile, '#');
		assertEquals(true, status);
	}

	@Test
	public void testValidNameString() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validNameString", String.class);
		method.setAccessible(true);

		String str = VALID_NAME_STRING;
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = INVALID_NAME_STRING;
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testValidUserIdString() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validUserIdString", String.class);
		method.setAccessible(true);

		String str = VALID_NAME_STRING;
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = INVALID_NAME_STRING;
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testValidNameCharacter() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validNameCharacter", char.class);
		method.setAccessible(true);

		boolean status = (Boolean) method.invoke(uploadUserFile, 'A');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, 'a');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '0');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '.');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, ',');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '~');
		assertEquals(false, status);
	}

	@Test
	public void testValidUserIDField() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validUserIDField", char.class);
		method.setAccessible(true);

		boolean status = (Boolean) method.invoke(uploadUserFile, 'A');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, 'a');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '0');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '.');
		assertEquals(false, status);

		status = (Boolean) method.invoke(uploadUserFile, ',');
		assertEquals(false, status);

		status = (Boolean) method.invoke(uploadUserFile, '~');
		assertEquals(false, status);
	}

	@Test
	public void testValidString() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validString", String.class);
		method.setAccessible(true);

		String str = VALID_NAME_STRING;
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = INVALID_NAME_STRING;
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);
	}

	@Test
	public void testValidOrgNameCharacter() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validOrgNameCharacter", char.class);
		method.setAccessible(true);

		boolean status = (Boolean) method.invoke(uploadUserFile, 'A');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, 'a');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '0');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '.');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, ',');
		assertEquals(true, status);

		status = (Boolean) method.invoke(uploadUserFile, '~');
		assertEquals(false, status);
	}

	@Test
	public void testValidEmail() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("validEmail", String.class);
		method.setAccessible(true);

		String str = VALID_NAME_STRING;
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(false, status);

		str = "aaa@aaa.com";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);

		str = "";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertEquals(true, status);
	}

	@Test
	public void testIsValidPhone() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isValidPhone", String.class);
		method.setAccessible(true);

		String str = "1";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-7890-1234";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "12-456-7890-1234";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-45-7890-1234";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-789-1234";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-7890-12345";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-7890-1234-5678";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

	}

	@Test
	public void testIsValidFax() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isValidFax", String.class);
		method.setAccessible(true);

		String str = "123 456 7890";
		boolean status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = VALID_FAX;
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "aaa-456-7890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-aaa-7890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-aaaa";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "12-456-7890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-45-7890";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "123-456-789";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);

		str = "1-2-3-4";
		status = (Boolean) method.invoke(uploadUserFile, str);
		assertNotNull(status);
	}

	@Test
	public void testGetPhoneFax() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("getPhoneFax", String.class);
		method.setAccessible(true);

		String str = "aaa ()-eExt.:,bbb ()-eExt.:,ccc ()-eExt.:,ddd ()-eExt.:,eee";
		String result = (String) method.invoke(uploadUserFile, str);
		assertEquals("(aaa) bbb-ccc x ddd", result);

		str = "aaa ()-eExt.:,bbb ()-eExt.:,ccc ()-eExt.:,ddd ()-eExt.:,eee ()-eExt.:,fff";
		result = (String) method.invoke(uploadUserFile, str);
		assertNotNull(result);
	}

	@Test
	public void testIsValidNumber() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isValidNumber", String.class);
		method.setAccessible(true);

		String number = "1";
		boolean status = (Boolean) method.invoke(uploadUserFile, number);
		assertEquals(true, status);

		number = "+";
		status = (Boolean) method.invoke(uploadUserFile, number);
		assertEquals(false, status);

		number = "";
		status = (Boolean) method.invoke(uploadUserFile, number);
		assertEquals(true, status);
	}

	@Test
	public void testIsValidZipFormat() throws Exception {
		Method method = UploadUserFile.class.getDeclaredMethod("isValidZipFormat", String.class);
		method.setAccessible(true);

		String zip = "12345-2-3-4-5";
		boolean status = (Boolean) method.invoke(uploadUserFile, zip);
		assertEquals(true, status);

		zip = "12345-123456-3-4-5";
		status = (Boolean) method.invoke(uploadUserFile, zip);
		assertEquals(false, status);

		zip = "1234-123456-3-4-5";
		status = (Boolean) method.invoke(uploadUserFile, zip);
		assertEquals(false, status);

		zip = "abc";
		status = (Boolean) method.invoke(uploadUserFile, zip);
		assertEquals(false, status);
	}

	// End of Private Method Tests

}
