package com.ctb.utils;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ConfigurationTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	@Before
	public void setUp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConfiguration() {
		Configuration cfg = new Configuration();
		assertNotNull(cfg.getErrorPath());
		assertNotNull(cfg.getEmailSender());
		assertNotNull(cfg.getEmailRecipient());
		assertNotNull(cfg.getEmailCC());
		assertNotNull(cfg.getEmailBCC());
		assertNotNull(cfg.getEmailSubjectFtpIssue());
		assertNotNull(cfg.getEmailBodyFtpIsuue());
		assertNotNull(cfg.getEmailSubjectDownloadFileIssue());
		assertNotNull(cfg.getEmailBodyDownloadFileIssue());
		assertNotNull(cfg.getEmailSubjectNoFileIssue());
		assertNotNull(cfg.getEmailBodyNoFileIssue());
		assertNotNull(cfg.getEmailSubjectMoreFilesIssue());
		assertNotNull(cfg.getEmailBodyMoreFilesIssue());
		assertNotNull(cfg.getEmailSubjectFileEmptyIssue());
		assertNotNull(cfg.getEmailBodyFileEmptyIssue());
		assertNotNull(cfg.getEmailSubjectFileHeaderValidationIssue());
		assertNotNull(cfg.getEmailBodyFileHeaderValidationIssue());
		assertNotNull(cfg.getEmailSubjectImportSuccess());
		assertNotNull(cfg.getEmailBodyImportSuccess());
		assertNotNull(cfg.getEmailSubjectArchiveFTPIssue());
		assertNotNull(cfg.getEmailBodyArchiveFTPIssue());
		assertNotNull(cfg.getEmailSubjectErrorFileFTPIssue());
		assertNotNull(cfg.getEmailBodyErrorFileFTPIssue());
		assertNotNull(cfg.getEmailAlias());
		assertNotNull(cfg.getFinalErrorPath());
	}

}
