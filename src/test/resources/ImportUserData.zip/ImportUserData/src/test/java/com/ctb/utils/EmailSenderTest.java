package com.ctb.utils;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EmailSenderTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	@Before
	public void setUp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSendMail() {
		EmailSender emailSender = new EmailSender();
		String asSmtpServer = "";
		String asSender = "amitabha.roy@tcs.com";
		String asRecipient = "amitabha.roy@tcs.com";
		String asCcRecipient = "amitabha.roy@tcs.com";
		String asBccRecipient = "amitabha.roy@tcs.com";
		String asSubject = "Junit";
		String asBody = "Junit";
		List arAttachments = new ArrayList();
		arAttachments.add("attach");
		String str = emailSender.sendMail(asSmtpServer, asSender, asRecipient, asCcRecipient, asBccRecipient, asSubject, asBody, arAttachments);
		assertNotNull(str);

		asSender = null;
		asRecipient = null;
		asCcRecipient = null;
		asBccRecipient = null;
		asSubject = null;
		asBody = null;
		arAttachments = null;
		str = emailSender.sendMail(asSmtpServer, asSender, asRecipient, asCcRecipient, asBccRecipient, asSubject, asBody, arAttachments);
		assertNotNull(str);

		asSender = "";
		asRecipient = "";
		asCcRecipient = "";
		asBccRecipient = "";
		asSubject = "";
		asBody = "";
		arAttachments = new ArrayList();
		str = emailSender.sendMail(asSmtpServer, asSender, asRecipient, asCcRecipient, asBccRecipient, asSubject, asBody, arAttachments);
		assertNotNull(str);
	}

}
