package com.ctb.utils;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Enumeration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
@PrepareForTest({ ExtractUtil.class })
public class ExtractUtilTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	ExtractUtil util;

	@Before
	public void setUp() throws Exception {
		util = new ExtractUtil();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testLoadPropetiesFile() {
		String fileName = "QA";
		ExtractUtil.loadPropetiesFile(fileName);
	}

	@Test
	public void testLoadExternalPropetiesFile() {
		String baseName = "QA";
		String externalPropertiesFilePAth = dirLoc;
		ExtractUtil.loadExternalPropetiesFile(baseName, externalPropertiesFilePAth);
	}

	/*@Test
	public void testGetDetail() {
		String key = "test.key";
		String str = ExtractUtil.getDetail(key);
		assertNotNull(str);
	}*/

	@Test
	public void testGetKeys() {
		String fileName = "QA";
		util.loadPropetiesFile(fileName);
		Enumeration<String> e = util.getKeys();
		assertNotNull(e);
	}

	@Test
	public void testHandleGetObjectString() {
		String key = "";
		Object obj = util.handleGetObject(key);
		assertNull(obj);
	}

}
