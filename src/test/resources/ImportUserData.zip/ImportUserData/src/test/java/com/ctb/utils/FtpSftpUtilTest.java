package com.ctb.utils;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.jcraft.jsch.Session;

public class FtpSftpUtilTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	FtpSftpUtil util;
	Session session = null;

	@Before
	public void setUp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		util = new FtpSftpUtil();
	}

	@After
	public void tearDown() throws Exception {
	}

	private Session getSession() {
		try {
			session = FtpSftpUtil.getSFTPSession();
			if (session == null)
				System.out.println("NULL");
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		return session;
	}

	@Test
	public void testCloseSFTPClient() throws Exception {
		Session session = getSession();
		FtpSftpUtil.closeSFTPClient(session);
		assertNotNull("Return type is void");
	}

	@Test(expected = java.lang.Exception.class)
	public void testSendfilesSFTP() throws Exception {
		String destinationPath = "";
		String sourceFile = "";
		String errorFileName = "";
		String errorMovedFileName = "";
		util.sendfilesSFTP(destinationPath, sourceFile, errorFileName, errorMovedFileName);
		assertNotNull("Return type is void");
	}

	@Test(expected = java.lang.Exception.class)
	public void testDownloadFiles() throws Exception {
		Session session = getSession();
		String sourceDir = "";
		String targetDir = "";
		Map<String, Long> fileTimeMap = new HashMap<String, Long>();
		FtpSftpUtil.downloadFiles(session, sourceDir, targetDir, fileTimeMap);
		assertNotNull("Return type is void");
	}

	@Test(expected = java.lang.Exception.class)
	public void testArchiveProcessedFiles() throws Exception {
		Session session = getSession();
		String sourceDir = "";
		String targetDir = "";
		String fileName = "";
		FtpSftpUtil.archiveProcessedFiles(session, sourceDir, targetDir, fileName);
		assertNotNull("Return type is void");
	}

}
