package com.ctb.utils;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HeaderOrderTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetUserHeaderOrderList() {
		List<String> list = new HeaderOrder().getUserHeaderOrderList();
		assertEquals(15, list.size());
	}

}
