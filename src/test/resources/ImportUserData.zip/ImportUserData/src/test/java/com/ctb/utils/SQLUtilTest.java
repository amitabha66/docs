package com.ctb.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SQLUtilTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");
	SQLUtil util;

	@Before
	public void setUp() throws Exception {
		ExtractUtil.loadExternalPropetiesFile("QA", dirLoc);
		util = new SQLUtil();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCloseDbObjects() throws SQLException {
		Connection conn = SQLUtil.getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT SYSDATE FROM DUAL");
		SQLUtil.closeDbObjects(conn, st, rs);
	}

}
