package com.ctb.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class TestUtil {
	private static TestUtil util = new TestUtil();

	public static String getProperty(String key) {
		String value = null;
		try {
			value = util.readPropertyFromFile(key);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	private String readPropertyFromFile(String key) throws IOException {
		Properties p = new Properties();
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("config.properties");
		p.load(inputStream);
		String value = p.getProperty(key);
		return value;
	}
}

