package com.ctb.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ctb.bean.DataFileAudit;
import com.ctb.bean.OrgNodeCategory;
import com.ctb.bean.UploadMoveData;
import com.ctb.bean.UserFileRow;
import com.ctb.dao.UploadFileDaoImpl;
import com.ctb.mockito.MockFactory;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ UploadFormUtils.class })
public class UploadFormUtilsTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	private UploadFormUtils utils;

	private UploadFileDaoImpl uploadFileDao;

	@Before
	public void setUp() throws Exception {
		utils = new UploadFormUtils();
		MockFactory.mockUploadFileDao(uploadFileDao);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testVerifyFileExtension() {
		String fileName = "abc.txt";
		boolean checkVal = false;
		assertEquals(checkVal, UploadFormUtils.verifyFileExtension(fileName));
	}

	@Test
	public void testSaveFileToDBTemp() throws Exception {
		Integer i = utils.saveFileToDBTemp(new File(dirLoc + "engrade_custid_16091.csv"));
		assertNotNull(i);
	}

	@Test
	public void testCheckCustomerConfigurationEntries() throws Exception {
		Integer customerId = 0;
		String configuration = "";
		boolean status = utils.checkCustomerConfigurationEntries(customerId, configuration);
		assertNotNull(status);
	}

	@Test
	public void testGetOrgNodeCategories() throws Exception {
		Integer customerId = 0;
		OrgNodeCategory[] orgNodeCategoryArray = utils.getOrgNodeCategories(customerId);
		assertNotNull(orgNodeCategoryArray);
	}

	@Test(expected = java.lang.ArrayIndexOutOfBoundsException.class)
	public void testGetUploadFileCheck() throws Exception {
		File file = new File(dirLoc + "engrade_custid_16091.csv");
		int noOfUserColumn = 0;
		Integer customerId = 0;
		OrgNodeCategory[] orgNodeCategory = new OrgNodeCategory[0];
		String s = utils.getUploadFileCheck(file, noOfUserColumn, customerId, orgNodeCategory);
		assertNotNull(s);
	}

	@Test
	public void testCreateTemplateHeader() {
		Integer customerId = 0;
		OrgNodeCategory[] orgNodeCategory = new OrgNodeCategory[0];
		UserFileRow[] object = new UserFileRow[1];
		utils.createTemplateHeader(customerId, orgNodeCategory, object);
	}

	@Test
	public void testCreateDataFileAudit() {
		DataFileAudit dataFileAudit = null;
		utils.createDataFileAudit(dataFileAudit);
	}

	@Test
	public void testGetUploadMoveData() {
		UploadMoveData uploadMoveData = utils.getUploadMoveData();
		assertNotNull(uploadMoveData);
	}

}