package com.ctb.utils;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.UploadMoveData;

public class UploadThreadTest {
	
	private final String dirLoc = TestUtil.getProperty("dirLoc");

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRun() {
		Integer customerId = 0;
		File inFile = new File(dirLoc + "test.txt");
		Integer uploadFileId = 0;
		UploadMoveData uploadMoveData = BeanTest.getUploadMoveData();
		UploadThread thread = new UploadThread(customerId, inFile, uploadFileId, uploadMoveData);
		thread.run();
	}

}
