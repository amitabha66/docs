package com.ctb.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.UserFileRow;

public class UserUtilsTest {
	
	UserUtils utils;

	@Before
	public void setUp() throws Exception {
		utils = new UserUtils();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConvertArraytoString() {
		Object[] obj = new Object[] { "cc", "aa", "bb" };
		String str = UserUtils.convertArraytoString(obj);
		assertEquals("'cc','aa','bb'", str);
	}

	@Test
	public void testGenerateBasicUsername() {
		UserFileRow user = BeanTest.getUserFileRow();
		String suffix = "";
		String str = UserUtils.generateBasicUsername(user, suffix);
		assertEquals("_", str);
	}

	@Test
	public void testGenerateEscapeUsername() {
		UserFileRow user = BeanTest.getUserFileRow();
		String str = UserUtils.generateEscapeUsername(user);
		assertEquals("_", str);
	}

	@Test
	public void testGenerateUniqueUserName() {
		Set<String> newSet = new HashSet<String>();
		UserFileRow user = BeanTest.getUserFileRow();
		newSet.add(user.getUserName());
		String str = UserUtils.generateUniqueUserName(newSet, user);
		System.out.println(str);
		assertEquals("-1", str);
		
		user.setUserName(null);
		str = UserUtils.generateUniqueUserName(newSet, user);
		System.out.println(str);
		assertEquals("-2", str);
	}

	@Test
	public void testUpperCaseFirstLetter() {
		String str = "abcd";
		String s = UserUtils.upperCaseFirstLetter(str);
		assertEquals("Abcd", s);
		
		str = "";
		s = UserUtils.upperCaseFirstLetter(str);
		assertEquals("", s);
	}

	@Test
	public void testGenerateRandomPassword() throws Exception {
		int passwordLength = 5;
		String str = UserUtils.generateRandomPassword(passwordLength);
		assertNotNull(str);
	}

	@Test
	public void testEncodePassword() throws Exception {
		String password = "password";
		String str = UserUtils.encodePassword(password);
		assertNotNull(str);
	}
	
	// Private Methods
	
	@Test
	public void testConvertForUserName() throws Exception {
		Method method = UserUtils.class.getDeclaredMethod("convertForUserName", String.class);
		method.setAccessible(true);

		String input = null;
		String output = (String) method.invoke(utils, input);
		assertEquals("", output);
		
		input = "";
		output = (String) method.invoke(utils, input);
		System.out.println(output);
		assertEquals("", output);
		
		input = "hello";
		output = (String) method.invoke(utils, input);
		assertEquals(input, output);
		
		input = "hel .lo";
		output = (String) method.invoke(utils, input);
		System.out.println(output);
		assertEquals("hel_lo", output);
	}
	
	@Test
	public void testVerifyContainsCharFrom() throws Exception {
		Method method = UserUtils.class.getDeclaredMethod("verifyContainsCharFrom", String.class, String.class);
		method.setAccessible(true);

		String input1 = "";
		String input2 = "";
		boolean output = (Boolean) method.invoke(utils, input1, input2);
		assertEquals(false, output);
	}

}
