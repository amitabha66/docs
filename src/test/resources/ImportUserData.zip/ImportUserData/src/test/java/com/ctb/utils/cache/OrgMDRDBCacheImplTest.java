package com.ctb.utils.cache;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OrgMDRDBCacheImplTest {

	OrgMDRDBCacheImpl cache;

	@Before
	public void setUp() throws Exception {
		cache = new OrgMDRDBCacheImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetCacheSize() {
		long l = cache.getCacheSize();
		assertNotNull(l);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testAddOrgFileRow() {
		String key = "";
		String orgNodeMDRNumber = "";
		cache.addOrgFileRow(key, orgNodeMDRNumber);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetOrgMDRNumber() {
		String key = "";
		String s = cache.getOrgMDRNumber(key);
		assertNull(s);
		
		key = "test";
		String orgNodeMDRNumber = null;
		cache.addOrgFileRow(key, orgNodeMDRNumber);
		s = cache.getOrgMDRNumber(key);
		assertNull(s);
		
		key = "test";
		orgNodeMDRNumber = "";
		cache.addOrgFileRow(key, orgNodeMDRNumber);
		s = cache.getOrgMDRNumber(key);
		assertNull(s);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testClearCacheContents() {
		cache.clearCacheContents();
	}

	@Test
	public void testRemoveCache() {
		OrgMDRDBCacheImpl.removeCache();
	}

}
