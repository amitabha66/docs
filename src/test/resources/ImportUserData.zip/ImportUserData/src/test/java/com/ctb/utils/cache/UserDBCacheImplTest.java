package com.ctb.utils.cache;

import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.bean.UserFileRow;

public class UserDBCacheImplTest {
	
	UserDBCacheImpl cache;

	@Before
	public void setUp() throws Exception {
		cache = new UserDBCacheImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetCacheSize() {
		long l = cache.getCacheSize();
		assertNotNull(l);
	}

	@Test
	public void testAddUserFileRow() {
		String key = "test";
		UserFileRow user = null;
		cache.addUserFileRow(key, user);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetUserFileRow() {
		String key = "test";
		UserFileRow user = cache.getUserFileRow(key);
		assertNotNull(user);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testClearCacheContents() {
		cache.clearCacheContents();
	}

	@Test
	public void testRemoveCache() {
		cache.removeCache();
	}

}
