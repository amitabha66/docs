package com.ctb.utils.cache;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ctb.bean.UserFileRow;

public class UserNewRecordCacheImplTest {

	UserNewRecordCacheImpl cache;

	@Before
	public void setUp() throws Exception {
		cache = new UserNewRecordCacheImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetCacheSize() {
		long l = cache.getCacheSize();
		assertNotNull(l);
	}

	@Test
	public void testAddNewUser() {
		String key = "";
		UserFileRow user = null;
		cache.addNewUser(key, user);
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testClearCacheContents() {
		cache.clearCacheContents();
	}

	@Test(expected = java.lang.NullPointerException.class) // TODO
	public void testGetKeys() {
		List<String> list = cache.getKeys();
		assertNotNull(list);
	}

	@Test
	public void testGetNewUser() {
		String key = "";
		UserFileRow user = cache.getNewUser(key);
		assertNull(user);
	}

	@Test
	public void testRemoveCache() {
		cache.removeCache();
	}

}
