package com.ctb.utils.cache;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ctb.bean.BeanTest;
import com.ctb.bean.UserFileRow;

public class UserUpdateRecordCacheImplTest {

	UserUpdateRecordCacheImpl cache;

	@Before
	public void setUp() throws Exception {
		cache = new UserUpdateRecordCacheImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test(expected = java.lang.NullPointerException.class)
	// TODO
	public void testGetCacheSize() {
		long l = cache.getCacheSize();
		assertNotNull(l);
	}

	@Test
	public void testAddUpdatedUser() {
		String key = "";
		UserFileRow user = null;
		cache.addUpdatedUser(key, user);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testGetUpdatedUser() {
		String key = "";
		UserFileRow user = cache.getUpdatedUser(key);
		assertNull(user);

		key = "hello";
		cache.addUpdatedUser(key, BeanTest.getUserFileRow());
		user = cache.getUpdatedUser(key);
		assertNotNull(user);
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testClearCacheContents() {
		cache.clearCacheContents();
	}

	@Test(expected = java.lang.NullPointerException.class)
	public void testGetKeys() {
		String key = "hello";
		cache.addUpdatedUser(key, BeanTest.getUserFileRow());
		List<String> list = cache.getKeys();
		assertNotNull(list);
	}

	@Test
	public void testRemoveCache() {
		cache.removeCache();
	}

}
