		<!-- Small boxes (Stat box) -->
		<?php include "DashboardSmallBoxes.php"; ?>
		<!-- Main row -->
		<div class="row"><!-- Left col -->
			<div class="col-md-8">
				<!-- TABLE: LATEST TRANSACTIONS -->
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Transactions of Last One Week</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<div class="box-body">

							<table id="DashboardTransactionTable" class="table">
							<thead>
								<tr>
									<th>Transaction ID</th>
									<th>Product Name</th>
									<th>Customer's Name</th>
									<th>Transaction Date</th>
								</tr>
							</thead>
							<tbody>
								<?php for ($i = 0; $i < 10; $i++) { ?>
								<tr>
									<td><a href="#"><?php echo"T$i" ?></a></td>
									<td>Product 1</td>
									<td>Sachin Tendulkar</td>
									<td>05/27/2015</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>

					</div><!-- /.box-body -->
					<!--div class="box-footer clearfix">
						<a href="../transactions/Transactions.php" class="btn btn-success btn-flat pull-left">Place New Transaction</a>
						<a href="../transactions/Transactions.php" class="btn btn-primary btn-flat pull-right">View All Transactions</a>
					</div--><!-- /.box-footer -->
				</div><!-- /.box -->
			</div><!-- /.col -->
			<div class="col-md-4">
				<!-- PRODUCT LIST -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Recently Added Products</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<div class="box-body">
						<ul class="products-list product-list-in-box">
						<?php for ($i = 0; $i < 3; $i++) { ?>
							<li class="item">
								<div class="product-img">
									<img src="../../dist/img/default-50x50.gif" alt="Product Image" />
								</div>
								<div class="product-info">
									<a href="javascript::;" class="product-title">Product <?php echo $i; ?> <span class="label label-warning pull-right">$1800</span></a>
									<span class="product-description"> Samsung 32" 1080p 60Hz LED Smart HDTV. </span>
								</div>
							</li><!-- /.item -->
						<?php } ?>
						</ul>
					</div><!-- /.box-body -->
					<div class="box-footer text-center">
						<a href="javascript::;" class="uppercase">View All Products</a>
					</div><!-- /.box-footer -->
				</div><!-- /.box -->
				<!-- USERS LIST -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Recently Added Users</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<div class="box-body">
						<ul class="products-list product-list-in-box">
						<?php for ($i = 0; $i < 2; $i++) { ?>
							<li class="item">
								<div class="product-img">
									<img src="../../dist/img/default-50x50.gif" alt="Product Image" />
								</div>
								<div class="product-info">
									<a href="javascript::;" class="product-title">User <?php echo $i; ?> <span class="label label-success pull-right">Admin</span></a>
									<span class="product-description"> Samsung 32" 1080p 60Hz LED Smart HDTV. </span>
								</div>
							</li><!-- /.item -->
						<?php } ?>
						</ul>
					</div><!-- /.box-body -->
					<div class="box-footer text-center">
						<a href="javascript::;" class="uppercase">View All Users</a>
					</div><!-- /.box-footer -->
				</div><!-- /.box -->
			</div><!-- /.col -->
		</div><!-- /.row -->