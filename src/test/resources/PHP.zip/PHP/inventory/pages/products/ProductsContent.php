		<div class="row"><!-- two col input form -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title"><i class='fa fa-plus'></i> Add New Product</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<form role="form" class="form-horizontal" action="#">
							<div class="col-md-6">
								<div class="form-group col-xs-12">
									<label class="control-label" for="ProductName" >Product Name</label>
									<input type="text" class="form-control" id="ProductName" name="ProductName" placeholder="Product Name ...">
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Manufacturer" >Manufacturer</label>
									<input type="text" class="form-control" id="Manufacturer" name="Manufacturer" placeholder="Manufacturer ...">
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Notes" >Notes</label>
									<textarea class="form-control" rows="4" id="Notes" name="Notes"></textarea>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="ProductCategory">Product Category</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-thumb-tack"></i></span>
										<select class="form-control" id="ProductCategory" name="ProductCategory">
										<?php for ($i = 0; $i < 15; $i++) { ?>
											<option>Category <?php echo $i; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label class="control-label" for="StartUnit">Starting Unit</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-thumb-tack"></i></span>
										<input type="text" class="form-control" id="StartUnit" name="StartUnit" placeholder="Starting Unit ...">
									</div>
								</div>
								<div class="form-group">
									<label class="control-label" for="CostPerUnit">Cost Per Unit</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-rupee"></i></span>
										<input type="text" class="form-control" id="CostPerUnit" name="CostPerUnit" placeholder="Price Per Unit ...">
										<span class="input-group-addon">.00</span>
									</div>
								</div>
								<div class="form-group">
									<label class="control-label" for="ProfitMargin">Profit Margin %</label>
									<div class="input-group">
										<span class="input-group-addon">@</span>
										<input type="text" class="form-control" id="ProfitMargin" name="ProfitMargin" placeholder="Profit Margin % ...">
										<span class="input-group-addon">%</span>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group col-xs-7">
									<label class="control-label" style="width: 100%; text-align: left;" for="ProductImage" >Product Image</label>
									<div class="fileinput fileinput-new" data-provides="fileinput">
										<div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 220px; height: 223px;"></div>
										<div style="text-align: center;">
											<span class="btn btn-default btn-file"><span class="fileinput-new"><i class="fa fa-file-picture-o"></i> Select image</span><span class="fileinput-exists"><i class='fa fa-exchange'></i> Change</span><input type="file" name="..."></span>
											<a href="#" class="btn btn-default fileinput-exists" data-dismiss="fileinput"><i class="fa fa-trash-o"></i>Remove</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-12 text-center">
								<button class="btn btn-success"><i class='fa fa-save'></i> Save</button>
								<button class="btn btn-primary"><i class='fa fa-eraser'></i> Reset</button>
							</div>
						</form>
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>
		<div class="row"><!-- one col -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title"><i class='fa fa-th'></i> List of All Products</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<table id="ProductTable" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Product ID</th>
									<th>Product Name</th>
									<th>Status</th>
									<th>Stock Count</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php for ($i = 0; $i < 15; $i++) { ?>
								<tr>
									<td><a href="#"><?php echo "P$i"; ?></a></td>
									<td>Call of Duty IV</td>
									<td><span class="label label-success">In Stock</span></td>
									<td>14</td>
									<td>
										<a class="btn btn-primary btn-sm" href="#"><i class='fa fa-folder-open-o'></i> <span>View</span></a>
										<a class="btn btn-warning btn-sm" href="#"><i class='fa fa-edit'></i> <span>Edit</span></a>
										<a class="btn btn-danger btn-sm" href="#"><i class='fa fa-trash-o'></i> <span>Delete</span></a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>