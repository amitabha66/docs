		<div class="row"><!-- two col input form -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title"><i class='fa fa-plus'></i> Add New User</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<form role="form" class="form-horizontal" action="#">
							<div class="col-md-4">
								<div class="form-group col-xs-12">
									<label class="control-label" style="width: 100%; text-align: left;" for="ProfilePicture">Profile Picture</label>
									<div class="fileinput fileinput-new" data-provides="fileinput">
										<div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 220px; height: 150px;"></div>
										<div style="text-align: center;">
											<span class="btn btn-default btn-file"><span class="fileinput-new"><i class="fa fa-file-picture-o"></i> Select image</span><span class="fileinput-exists"><i class='fa fa-exchange'></i> Change</span><input type="file" name="..."></span>
											<a href="#" class="btn btn-default fileinput-exists" data-dismiss="fileinput"><i class="fa fa-trash-o"></i>Remove</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group col-xs-12">
									<label class="control-label" for="Username">Username</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input type="text" class="form-control" id="Username" name="Username" placeholder="Username ...">
									</div>
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Roles">Roles</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-eye"></i></span>
										<select class="form-control" id="Roles" name="Roles">
										<?php for ($i = 0; $i < 15; $i++) { ?>
											<option>Role <?php echo $i; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Permissions">Permissions</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-thumbs-o-up"></i></span>
										<select class="form-control" id="Permissions" name="Permissions">
										<?php for ($i = 0; $i < 15; $i++) { ?>
											<option>Permission <?php echo $i; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group col-xs-12">
									<label class="control-label" for="FullName">Full Name</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-street-view"></i></span>
										<input type="text" class="form-control" id="FullName" name="FullName" placeholder="FullName ...">
									</div>
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Email">Email</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										<input type="text" class="form-control" id="Email" name="Email" placeholder="Email ...">
									</div>
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Mobile">Mobile</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-mobile-phone"></i></span>
										<input type="text" class="form-control" id="Mobile" name="Mobile" placeholder="Mobile ...">
									</div>
								</div>
							</div>
							
							<div class="col-md-12 text-center">
								<button class="btn btn-success"><i class='fa fa-save'></i> Save</button>
								<button class="btn btn-primary"><i class='fa fa-eraser'></i> Reset</button>
							</div>
						</form>
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>
		<div class="row"><!-- one col -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title"><i class='fa fa-th'></i> List of All Users</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<table id="UserTable" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>User ID</th>
									<th>Username</th>
									<th>Roles</th>
									<th>Permissions</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php for ($i = 0; $i < 15; $i++) { ?>
								<tr>
									<td><a href="#"><?php echo "U$i"; ?></a></td>
									<td>Call of Duty IV</td>
									<td><span class="label label-success">Admin</span></td>
									<td>14</td>
									<td>
										<a class="btn btn-primary btn-sm" href="#"><i class='fa fa-folder-open-o'></i> <span>View</span></a>
										<a class="btn btn-warning btn-sm" href="#"><i class='fa fa-edit'></i> <span>Edit</span></a>
										<a class="btn btn-danger btn-sm" href="#"><i class='fa fa-trash-o'></i> <span>Delete</span></a>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>