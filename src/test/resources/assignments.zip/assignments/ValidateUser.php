<?php
	session_start();

	$Answer = "";
	if (isset($_SESSION['Answer']) && $_SESSION['Answer'] != "") {
		$Answer = $_SESSION['Answer'];
	}

	$Answer1 = "";
	if (isset($_POST['inputAnswer1']) && $_POST['inputAnswer1'] != "") {
		$Answer1 = $_POST['inputAnswer1'];
	}
	
	echo "$Answer - <br />";
	echo "$Answer1 - <br />";
	
	if(strcmp($Answer, $Answer1) == 0) {
		echo "Valid<br />";
		header("Location: http://localhost/assignments/index.php");
	} else {
		echo "Invalid<br />";
		$_SESSION['loginError'] = "Answer for the security question does not match";
		header("Location: http://localhost/assignments/logout.php");
	}
?>
