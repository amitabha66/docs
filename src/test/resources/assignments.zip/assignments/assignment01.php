<?php include 'common/header.php';?>

<h1>Assignment 1</h1>
<p>Please try to do below simple task. Write a code to do below things:
	<ol>
		<li>print your name</li>
		<li>write a method to print  sum of two number using global variable</li>
		<li>write a method to print 1 to 5 using static method</li>
		<li>Print you server name using super global method.</li>
	</ol>
</p>
<p><a href="/assignments/assignment01_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
