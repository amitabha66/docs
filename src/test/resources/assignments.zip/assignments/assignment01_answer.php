<?php include 'common/header.php';?>
<?php

// 1. print your name 
$author = "Amitabha Roy<br />";

echo 'Hello ' . "$author";
echo "Hello $author";

echo "<br />";

// 2. write a method to print  sum of two number using global variable
$x = 5;
$y = 10;
$z;

function myTest() {
	$GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
}

myTest();
echo "$x + $y=" . $z; // outputs 15

$x1 = 6;
$y1 = 11;
$z1;

function mySecondTest() {
	global $x1, $y1, $z1;
	$z1 = $x1 + $y1;
}

echo "<br />";
mySecondTest();
echo "$x1 + $y1=" . $z1; // outputs 17

echo "<br />";

// 3. write a method to print 1 to 5 using static method 

function staticTest() {
	static $w = 0;
	$w++;
	echo $w;
}

echo "<br />";
staticTest();
staticTest();
staticTest();
staticTest();
staticTest();

echo "<br />";

// 4. Print you server name using super global method.

echo "<br>";
echo $_SERVER['SERVER_NAME'];


?>

<?php include 'common/footer.php';?>