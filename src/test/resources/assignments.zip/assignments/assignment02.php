<?php include 'common/header.php';?>

<h1>Assignment 2</h1>
<p>Create a php page with below functionality:
	<ol>
		<li>Create a html form with fruits select drop down menu and a submit button</li>
		<li>Show the fruits values using  PHP constant variables</li>
		<li>Submit this form in a other PHP file </li>
		<li>Show selected fruit value on other php page using php.</li>
	</ol>
</p>
<p><a href="/assignments/assignment02_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
