<?php include 'common/header.php';?>
<?php
	define("APPLE", "Apple", FALSE);
	define("MANGO", "Mango", FALSE);
	define("ORANGE", "Orange", FALSE);
?>

<form action="assignment02_submit.php">
	Fruit: 
	<select name="fruit">
		<option value="APPLE"><?php echo APPLE?></option>
		<option value="MANGO"><?php echo MANGO?></option>
		<option value="ORANGE"><?php echo ORANGE?></option>
	</select>
	<input type="submit" value="Submit" />
</form>

<?php include 'common/footer.php';?>