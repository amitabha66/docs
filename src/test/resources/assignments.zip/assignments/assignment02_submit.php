<?php include 'common/header.php';?>

<?php
$fruit = $_GET['fruit'];
$color;

if($fruit == "APPLE") {
	$color = "RED";
} else if($fruit == "MANGO") {
	$color = "Yellow";
} else if($fruit == "ORANGE") {
	$color = "Orange";
}
?>
<p style="background: <?php echo strtolower($color); ?>;">
<?php echo "$fruit is $color"; ?>
</p>
<?php include 'common/footer.php';?>