<?php include 'common/header.php';?>

<h1>Assignment 3</h1>
<p>Please check below assignment details:
	<ol>
		<li>Create a html form with different types of  fields(minimum 6 fields require)</li>
		<li>On submit of this page all submitted data will store/write in a csv file(this file create using php if already created then just append new data) in your local system.</li>
		<li>Create a page to read same CSV file data and show In a html table format.</li>
	</ol>
</p>
<p><a href="/assignments/assignment03_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
