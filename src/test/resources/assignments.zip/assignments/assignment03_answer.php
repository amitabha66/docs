<?php include 'common/header.php';?>
<h2>Employee Registration Form</h2>
<p>&nbsp;</p>
<form id="EmployeeRegistrationForm" action="assignment03_submit.php" method="post" class="form-horizontal">
	<div class="form-group form-inline required">
    	<label for="EmployeeId" class="control-label col-xs-2">Employee Id</label>
		<input type="text" class="form-control" id="EmployeeId" placeholder="Enter Employee Id" required>
    </div>
    <div class="form-group form-inline required">
    	<label for="FirstName" class="control-label col-xs-2">First Name</label>
		<input type="text" class="form-control" id="FirstName" placeholder="Enter First Name" required>
    </div>
    <div class="form-group form-inline">
    	<label for="LastName" class="control-label col-xs-2">Last Name</label>
		<input type="text" class="form-control" id="LastName" placeholder="Enter Last Name" required>
    </div>
    <div class="form-group">
		<div class="col-xs-offset-2">
			<button type="submit" class="btn btn-success">Register</button>
			<a href="/assignments/assignment03_view.php" class="btn btn-success">View All Employees &raquo;</a>
		</div>
	</div>
</form>
<?php include 'common/footer.php';?>