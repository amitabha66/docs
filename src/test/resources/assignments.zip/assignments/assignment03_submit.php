<?php include 'common/header.php';?>
<?php 
$EmployeeId = $_POST['EmployeeId'];
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$EmailId = $_POST['EmailId'];
$WON = $_POST['WON'];
$Project = $_POST['Project'];
?>
<?php
	$myfile = fopen("database.csv", "a") or die("Unable to Open file!");
		fwrite($myfile, $EmployeeId . ",");
		fwrite($myfile, $FirstName . ",");
		fwrite($myfile, $LastName . ",");
		fwrite($myfile, $EmailId . ",");
		fwrite($myfile, $WON . ",");
		fwrite($myfile, $Project . "\n");
	fclose($myfile);
?>

<h3>Registration Successfull.</h3>
<p>&nbsp;</p>
<div>
	<table class="table table-bordered">
		<tr>
			<td>Employee Id</td>
			<td><?php echo $EmployeeId; ?></td>
		</tr>
		<tr>
			<td>First Name</td>
			<td><?php echo $FirstName; ?></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><?php echo $LastName; ?></td>
		</tr>
		<tr>
			<td>Email Id</td>
			<td><?php echo $EmailId; ?></td>
		</tr>
		<tr>
			<td>WON</td>
			<td><?php echo $WON; ?></td>
		</tr>
		<tr>
			<td>Project</td>
			<td><?php echo $Project; ?></td>
		</tr>
	</table>
</div>
<p>&nbsp;</p>
<p><a href="/assignments/assignment03_view.php" class="btn btn-success">View All Employees &raquo;</a></p>
<?php include 'common/footer.php';?>