<?php include 'common/header.php';?>
<?php
	$myfile = fopen("database.csv", "r") or die("Unable to Read file!");
?>
<h2>List of All Registered Employees</h2>
<div>
	<table class="table table-bordered">
		<thead>
		<tr>
			<th>Employee Id</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Email Id</th>
			<th>WON</th>
			<th>Project</th>
		</tr>
		</thead>
		<?php while($lineData = fgetcsv($myfile, ",")) {?>
		<tbody>
		<tr>
			<td><?php echo $lineData[0]; ?></td>
			<td><?php echo $lineData[1]; ?></td>
			<td><?php echo $lineData[2]; ?></td>
			<td><?php echo $lineData[3]; ?></td>
			<td><?php echo $lineData[4]; ?></td>
			<td><?php echo $lineData[5]; ?></td>
		</tr>
		</tbody>
		<?php }?>
		<?php fclose($myfile);?>
	</table>
</div>
<?php include 'common/footer.php';?>