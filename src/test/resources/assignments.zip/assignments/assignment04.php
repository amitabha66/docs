<?php include 'common/header.php';?>

<h1>Assignment 4</h1>
<p>Please check below assignment details:</p>

<table class="table table-striped table-bordered">
	<tbody>
		<tr>
			<td><b>Assignment Tpoic</b></td>
			<td><b>Assignment</b></td>
		</tr>
		<tr>
			<td><b>PHP Cookies</b></td>
			<td>Create login form and set cookie on submit of this form. Make a link to destroy this cookie</td>
		</tr>
		<tr>
			<td><b>Sessions</b></td>
			<td>1. Create login form and set all submitted data in session on submit of this form. <br />2. After session store redirect this login page to another relogin page. <br />3. For relogin page on submit form action, check the session data. If session data and user entered data matched then show welcome message on  relogin page and hide relogin form.</td>
		</tr>
		<tr>
			<td><b>Date and Time</b></td>
			<td>create a form with input date field, a date format select drop down and two check box with value today's date and tommorow's date. On submit of this form show the all user entered date,today's date and tommorows date in user selected format </td>
		</tr>
		<tr>
			<td><b>Sending Emails</b></td>
			<td>mail server require to do this..</td>
		</tr>
		<tr>
			<td><b>PHP Error and Exception Handling</b></td>
			<td>Do all the above php code with proper error and exception handling</td>
		</tr>
		<tr>
			<td><br /></td>
			<td><br /></td>
		</tr>
		<tr>
			<td><b>Assignment</b></td>
			<td>1. Create a login page. <br />2. login credential data store in a external text file.<br />3. On login show welcome page with current date. <br />4. create a user management system(user add,update,delete) all data should store in cookie and csv file.<br />5. only valid admin user can do all the above operation (user managemnet operations)<br />Note: For this assignment try to include all the above topics</td>
		</tr>
	</tbody>
</table>

<p><a href="/assignments/assignment04_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
