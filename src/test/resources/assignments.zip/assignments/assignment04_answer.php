<?php include 'common/header.php';?>

<h2>PHP Cookies</h2>

<p>Check the Login - Logout feature displayed on right hand side of the top nav bar.</p>
<ol>
	<li>Login form created</li>
	<li>Cookie is set on submit of login form</li>
	<li>Cookie is deleted on clicking the logout link</li>
</ol>

<h2>Sessions</h2>

<p>Check the Login -> Confirm -> Welcome flow.</p>

<h2>Date and Time</h2>

<p><a href="/assignments/assignment04_date.php" class="btn btn-success">Goto Date Formatter &raquo;</a></p>

<?php include 'common/footer.php';?>