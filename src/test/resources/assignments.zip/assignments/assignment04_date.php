<?php include 'common/header.php';?>

<form class="form-horizontal" action="assignment04_dateformat.php" method="post">
	<div class="form-group">
		<label for="inputDate" class="control-label col-xs-3">Choose Date</label>
		<div class="col-xs-9"><input type="date" class="form-control" id="inputDate" name="inputDate" required /></div>
	</div>
	<div class="form-group">
		<label for="inputToday" class="control-label col-xs-3">Today</label>
		<div class="col-xs-9"><input type="checkbox" class="form-control input-normal" id="inputToday" name="inputToday" value="1" /></div>
	</div>
	<div class="form-group">
		<label for="inputTomorrow" class="control-label col-xs-3">Tomorrow</label>
		<div class="col-xs-9"><input type="checkbox" class="form-control input-normal" id="inputTomorrow" name="inputTomorrow" value="1" /></div>
	</div>
	<div class="form-group">
		<label for="inputDateFormat" class="control-label col-xs-3">Date Format</label>
		<div class="col-xs-9">
			<select class="selectpicker form-control" id="inputDateFormat" name="inputDateFormat" required>
				<option value="1">Y-m-d h:i:sa</option>
				<option value="2">Y-m-d</option>
				<option value="3">m-d-Y</option>
				<option value="4">d-m-Y</option>
			</select>
		</div>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-2 col-xs-10">
			<button type="submit" class="btn btn-success">Format</button>
		</div>
	</div>
</form>

<?php include 'common/footer.php';?>