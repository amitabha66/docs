<?php include 'common/header.php';?>

<h2>Date and Time</h2>

<?php 
	$inputDate = $_POST["inputDate"];
	$date=date_create($inputDate);

	$today = "";
	if(isset($_POST["inputToday"])) {
		$today = $_POST["inputToday"];
	}

	$tomorrow = "";
	if(isset($_POST["inputTomorrow"])) {
		$tomorrow = $_POST["inputTomorrow"];
	}

	//echo date("Y-m-d h:i:sa", $d) . "<br>";

	$dateFormat = $_POST["inputDateFormat"];
	$format = "";
	if($dateFormat == "1") {
		$format = "Y-m-d h:i:sa";
	} else if($dateFormat == "2") {
		$format = "Y-m-d";
	} else if($dateFormat == "3") {
		$format = "m-d-Y";
	} else if($dateFormat == "4") {
		$format = "d-m-Y";
	}
	

?>

<?php
/*
	$date_array = getdate();
	foreach ( $date_array as $key => $val ) {
		print "$key = $val<br />";
	}
	$formated_date  = "Today's date: ";
	$formated_date .= $date_array['mday'] . "/";
	$formated_date .= $date_array['mon'] . "/";
	$formated_date .= $date_array['year'];
	
	print $formated_date;
*/
?>

<div class="form-horizontal">
	<div class="form-group">
		<label for="inputDate" class="control-label col-xs-4">Date Choosen</label>
		<div class="col-xs-8"><?php echo date_format($date, $format); ?></div>
	</div>
	<?php if($today == "1") { ?>
	<div class="form-group">
		<label for="inputToday" class="control-label col-xs-4">Formatted Today's Date</label>
		<div class="col-xs-8"><?php echo date($format, strtotime("today")); ?></div>
	</div>
	<?php } ?>
	<?php if($tomorrow == "1") { ?>
	<div class="form-group">
		<label for="inputTomorrow" class="control-label col-xs-4">Formatted Tomorrow's Date</label>
		<div class="col-xs-8"><?php echo date($format, strtotime("tomorrow")); ?></div>
	</div>
	<?php } ?>
	<div class="form-group">
		<label for="inputQuestion" class="control-label col-xs-4">Date Format Choosen</label>
		<div class="col-xs-8"><?php echo $format; ?></div>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-4 col-xs-8">
			<a href="/assignments/assignment04_date.php" class="btn btn-success">Goto Date Input Form &raquo;</a>
		</div>
	</div>
</div>

<?php include 'common/footer.php';?>