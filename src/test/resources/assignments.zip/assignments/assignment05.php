<?php include 'common/header.php';?>

<h1>Assignment 5</h1>
<p>Please check below assignment details:</p>

<table class="table table-striped table-bordered">
	<tbody>
		<tr>
			<td><b>Assignment Tpoic</b></td>
			<td><b>Assignment Sub topic</b></td>
			<td><b>Assignment</b></td>
		</tr>
		<tr>
			<td><b>PHP and MySQL</b></td>
			<td>Connecting to MySQL database<br /></td>
			<td>create a php to connect a database and show error if connection failed</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Create MySQL Database Using PHP / Delete MySQL Database Using PHP <br /></td>
			<td>after connect a database create/ select a database and also a link to delete that database</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td><br />Insert Data To MySQL Database</td>
			<td>create a page to input user data and submit it and save to database</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Retrevieng Data From MySQL Database / Using Paging through PHP</td>
			<td>fetch all saved data from database table and show it in a html table with pagination</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>  Updating Data Into MySQL Database<br /></td>
			<td>create a page to show inserted data with a update link to update values in database</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td><br /><br /><br />Deleting Data From MySQL Database<br /></td>
			<td>create a page to show inserted data with a delete link to delete values from database</td>
		</tr>
		<tr>
			<td><b>Assignment</b></td>
			<td><br /></td>
			<td><b>1. Create  php page with user input form.<br />2. connect to a mysql db<br />3. create or select database name<br />2. On submit of user input form save/insert data in database <br />3. give one link to show all the submitted data from database<br />4. use pagination to show more data<br />5. give a update link to update that data<br />6. give  a delete link to delete a data</b></td>
		</tr>
	</tbody>
</table>

<p><a href="/assignments/assignment05_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
