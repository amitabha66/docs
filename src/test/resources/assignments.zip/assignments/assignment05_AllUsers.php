<?php include 'common/header.php';?>

<h1>All Users</h1>

<p><a href="assignment05_CreateUser.php" class="btn btn-success">Create</a></p>

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email Address</th>
			<th>Mobile Number</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php 
		include 'assignment05_DBUtil.php';
		$pdo = DBUtil::connect();
		$sql = 'SELECT * FROM PHP_USERS ORDER BY ID DESC';
		foreach ($pdo->query($sql) as $row) {
			echo '<tr>';
			echo '	<td>'. $row['NAME'] . '</td>';
			echo '	<td>'. $row['EMAIL'] . '</td>';
			echo '	<td>'. $row['MOBILE'] . '</td>';
			echo '	<td width=250>';
			echo '		<a class="btn btn-primary" href="assignment05_ReadUser.php?id='.$row['ID'].'">Read</a>';
			echo '			&nbsp;';
			echo '		<a class="btn btn-info" href="assignment05_UpdateUser.php?id='.$row['ID'].'">Update</a>';
			echo '			&nbsp;';
			echo '		<a class="btn btn-danger" href="assignment05_DeleteUser.php?id='.$row['ID'].'">Delete</a>';
			echo '	</td>';
			echo '</tr>';
		}
		DBUtil::disconnect();
	?>
	</tbody>
</table>

<?php include 'common/footer.php';?>