<?php include 'common/header.php';?>

<h1>Delete User</h1>

<?php

require 'assignment05_DBUtil.php';

$id = 0;

if ( !empty($_GET['id'])) {
	$id = $_REQUEST['id'];
}

if ( !empty($_POST)) {
	// keep track post values
	$id = $_POST['id'];

	// delete data
	$pdo = DBUtil::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "DELETE FROM PHP_USERS WHERE ID = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	DBUtil::disconnect();
	echo '<p class="text-success">User Deleted Successfully</p>';
} else {
	echo '<p class="text-error">User ID is empty</p>';
}
?>

<form class="form-horizontal" action="assignment05_DeleteUser.php" method="post">
	<input type="hidden" name="id" value="<?php echo $id;?>" />
	<p class="alert alert-error">Are you sure to delete ?</p>
	<div class="form-actions">
		<button type="submit" class="btn btn-warning">Yes</button>
		<a class="btn btn-default" href="assignment05_AllUsers.php">No</a>
		<a class="btn btn-success" href="assignment05_AllUsers.php">View All Users</a>
	</div>
</form>

<?php include 'common/footer.php';?>