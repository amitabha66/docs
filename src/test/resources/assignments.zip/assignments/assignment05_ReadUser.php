<?php include 'common/header.php';?>

<?php

require 'assignment05_DBUtil.php';

$id = null;
if ( !empty($_GET['id'])) {
	$id = $_REQUEST['id'];
}

if ( null==$id ) {
	echo '<p class="text-error">User ID is empty</p>';
} else {
	$pdo = DBUtil::connect();
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "SELECT * FROM PHP_USERS WHERE ID = ?";
	$q = $pdo->prepare($sql);
	$q->execute(array($id));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	DBUtil::disconnect();
}
?>

<h1>Read User</h1>

<div class="form-horizontal" action="assignment05_CreateUser.php" method="post">
	<div class="form-group form-inline <?php echo !empty($nameError)?'error':'';?>">
		<label class="control-label col-xs-3">Name</label>
		<label class="form-control"><?php echo $data['NAME'];?></label>
	</div>
	<div class="form-group form-inline <?php echo !empty($emailError)?'error':'';?>">
		<label class="control-label col-xs-3">Email Address</label>
		<label class="form-control"><?php echo $data['EMAIL'];?></label>
	</div>
	<div class="form-group form-inline <?php echo !empty($mobileError)?'error':'';?>">
		<label class="control-label col-xs-3">Mobile Number</label>
		<label class="form-control"><?php echo $data['MOBILE'];?></label>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-3">
			<a class="btn btn-success" href="assignment05_AllUsers.php">View All Users</a>
		</div>
	</div>
</div>

<?php include 'common/footer.php';?>