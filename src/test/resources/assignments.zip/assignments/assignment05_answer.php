<?php include 'common/header.php';?>

<h1>User Management</h1>

<p>Create table script:</p>
<pre>
CREATE TABLE `PHP_USERS` (
	`ID` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`NAME` VARCHAR( 100 ) NOT NULL,
	`EMAIL` VARCHAR( 100 ) NOT NULL,
	`MOBILE` VARCHAR( 100 ) NOT NULL
) ENGINE = INNODB;
</pre>

<p><a href="assignment05_AllUsers.php" class="btn btn-success">View All Users</a></p>

<?php include 'common/footer.php';?>