<?php include 'common/header.php';?>

<h1>Assignment 6</h1>
<p>Please check below assignment details:</p>
<table class="table table-striped table-bordered">
	<tbody>
		<tr>
			<td><b>Assignment Tpoic</b></td>
			<td><b>Assignment Sub topic</b></td>
			<td><b>Assignment</b></td>
		</tr>
		<tr>
			<td><b>PHP and XML</b></td>
			<td>Parsing an XML Document</td>
			<td>1. create a xml file with employee details<br />2. fetch all the employee in php file and show it in a html table</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Generating an XML Document:</td>
			<td>generate a xml with a form submitted data and append all the data inside the root node</td>
		</tr>
		<tr>
			<td><b>Object Oriented Programming in PHP</b></td>
			<td>Defining PHP Classes,Creating Objects in PHP,Calling Member Functions</td>
			<td>write a math class and write math operations method inside this class. Now create a object out side of this class and call member function to show some values</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Constructor/Destructor Functions</td>
			<td>wtite above class with Constructor and Destructor and call member function outside of this class</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Inheritance</td>
			<td>extend math class with sum class</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Function Overriding</td>
			<td>override a method from math class to sum class</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Public,private,protected Members</td>
			<td>use all public,private and protected keywords and try to access those from outside of class and thorow error or message accoridng to each of this.</td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Interfaces/Abstract Classes</td>
			<td>write a interface and abstarct class for math class </td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Constants,Static, Final Keyword</td>
			<td>use contsant, Static, Final Keyword before a method or variable and access those from outside of this class and show message or throw error message </td>
		</tr>
		<tr>
			<td><b><br /></b></td>
			<td>Calling parent constructors</td>
			<td>call math's class contstrct method from sum class</td>
		</tr>
		<tr>
			<td><b>Assignment</b></td>
			<td><br /></td>
			<td><b>1. create xml file with employee details <br />2. load this file in php and create a table in html.<br />3. create xml parser class which handle all the xml related operations</b></td>
		</tr>
	</tbody>
</table>
<p><a href="/assignments/assignment06_answer.php" class="btn btn-success">Check Answer &raquo;</a></p>

<?php include 'common/footer.php';?>
