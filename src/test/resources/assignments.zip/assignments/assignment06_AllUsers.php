<?php include 'common/header.php';?>

<h1>All Users</h1>

<p><a href="assignment06_CreateUser.php" class="btn btn-success">Create</a></p>

<table class="table table-striped table-bordered">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email Address</th>
			<th>Mobile Number</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php 
		$xml = simplexml_load_file("database.xml") or die("Error: Cannot Read XML");
		foreach($xml->children() as $users => $user) {
			if($user->delete != "Y") {
				echo '<tr>';
				echo '	<td>'. $user->name . '</td>';
				echo '	<td>'. $user->email . '</td>';
				echo '	<td>'. $user->mobile . '</td>';
				echo '	<td width=250>';
				echo '		<a class="btn btn-primary" href="assignment06_ReadUser.php?id='.$user->id.'">Read</a>';
				echo '			&nbsp;';
				echo '		<a class="btn btn-info" href="assignment06_UpdateUser.php?id='.$user->id.'">Update</a>';
				echo '			&nbsp;';
				echo '		<a class="btn btn-danger" href="assignment06_DeleteUser.php?id='.$user->id.'">Delete</a>';
				echo '	</td>';
				echo '</tr>';
			}
		}
	?>
	</tbody>
</table>

<?php include 'common/footer.php';?>