<?php include 'common/header.php';?>

<h1>Read User</h1>

<?php
$id = null;
if ( !empty($_GET['id'])) {
	$id = $_REQUEST['id'];
}

if ( null==$id ) {
	echo '<p class="text-error">User ID is empty</p>';
} else {
	// read	data
	$xml = simplexml_load_file("database.xml");
	$sxe = new SimpleXMLElement($xml->asXML());
	$rows = count($sxe);
	for($i = 0, $length = $rows; $i < $length; $i++){
		if($sxe->user[$i]->id == $id){
			$name = $sxe->user[$i]->name;
			$email = $sxe->user[$i]->email;
			$mobile = $sxe->user[$i]->mobile;
			$delete = $sxe->user[$i]->delete;
			break;
		}
	}
}
?>
<?php if ($delete != null && $delete != "Y") {?>


<div class="form-horizontal">
	<div class="form-group form-inline <?php echo !empty($nameError)?'error':'';?>">
		<label class="control-label col-xs-3">Name</label>
		<label class="form-control"><?php echo $name;?></label>
	</div>
	<div class="form-group form-inline <?php echo !empty($emailError)?'error':'';?>">
		<label class="control-label col-xs-3">Email Address</label>
		<label class="form-control"><?php echo $email;?></label>
	</div>
	<div class="form-group form-inline <?php echo !empty($mobileError)?'error':'';?>">
		<label class="control-label col-xs-3">Mobile Number</label>
		<label class="form-control"><?php echo $mobile;?></label>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-3">
			<a class="btn btn-success" href="assignment06_AllUsers.php">View All Users</a>
		</div>
	</div>
</div>
<?php } else {?>
<p class="text-error">User Not Found with ID = <?php echo $id;?></p>
<?php }?>

<?php include 'common/footer.php';?>