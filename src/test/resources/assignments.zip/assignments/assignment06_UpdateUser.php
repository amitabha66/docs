<?php include 'common/header.php';?>

<h1>Update User</h1>

<?php

require 'assignment05_DBUtil.php';

$id = null;
if ( !empty($_GET['id'])) {
	$id = $_REQUEST['id'];
}

if ( null==$id ) {
	echo '<p class="text-error">User ID is empty</p>';
}

if ( !empty($_POST)) {
	// keep track validation errors
	$nameError = null;
	$emailError = null;
	$mobileError = null;

	// keep track post values
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];

	// validate input
	$valid = true;
	if (empty($name)) {
		$nameError = 'Please enter Name';
		$valid = false;
	}

	if (empty($email)) {
		$emailError = 'Please enter Email Address';
		$valid = false;
	} else if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
		$emailError = 'Please enter a valid Email Address';
		$valid = false;
	}

	if (empty($mobile)) {
		$mobileError = 'Please enter Mobile Number';
		$valid = false;
	}

	// update data
	if ($valid) {
		$xml = simplexml_load_file("database.xml");
		$sxe = new SimpleXMLElement($xml->asXML());
		$rows = count($sxe);
		for($i = 0, $length = $rows; $i < $length; $i++){
			if($sxe->user[$i]->id == $id){
				$sxe->user[$i]->name = ($name);
				$sxe->user[$i]->email = ($email);
				$sxe->user[$i]->mobile = ($mobile);
				$sxe->user[$i]->delete = "N";
				break;
			}
		}
	    $sxe->asXML("database.xml");
		echo '<p class="text-success">User('.$name.', '.$email.', '.$mobile.') Updated Successfully</p>';
	}
} else {
	// read	data
	$xml = simplexml_load_file("database.xml");
	$sxe = new SimpleXMLElement($xml->asXML());
	$rows = count($sxe);
	for($i = 0, $length = $rows; $i < $length; $i++){
		if($sxe->user[$i]->id == $id){
			$name = $sxe->user[$i]->name;
			$email = $sxe->user[$i]->email;
			$mobile = $sxe->user[$i]->mobile;
			break;
		}
	}
}
?>

<form class="form-horizontal" action="assignment06_UpdateUser.php?id=<?php echo $id?>" method="post">
	<div class="form-group form-inline <?php echo !empty($nameError)?'error':'';?>">
		<label class="control-label col-xs-3">Name</label>
		<input class="form-control" name="name" type="text" placeholder="Name" value="<?php echo !empty($name)?$name:'';?>">
		<?php if (!empty($nameError)): ?>
			<span class="help-inline"><?php echo $nameError;?></span>
		<?php endif; ?>
	</div>
	<div class="form-group form-inline <?php echo !empty($emailError)?'error':'';?>">
		<label class="control-label col-xs-3">Email Address</label>
		<input class="form-control" name="email" type="text" placeholder="Email Address" value="<?php echo !empty($email)?$email:'';?>">
		<?php if (!empty($emailError)): ?>
			<span class="help-inline"><?php echo $emailError;?></span>
		<?php endif;?>
	</div>
	<div class="form-group form-inline <?php echo !empty($mobileError)?'error':'';?>">
		<label class="control-label col-xs-3">Mobile Number</label>
		<input class="form-control" name="mobile" type="text" placeholder="Mobile Number" value="<?php echo !empty($mobile)?$mobile:'';?>">
		<?php if (!empty($mobileError)): ?>
			<span class="help-inline"><?php echo $mobileError;?></span>
		<?php endif;?>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-3">
			<button type="submit" class="btn btn-info">Update</button>
			<a class="btn btn-success" href="assignment06_AllUsers.php">View All Users</a>
		</div>
	</div>
</form>

<?php include 'common/footer.php';?>