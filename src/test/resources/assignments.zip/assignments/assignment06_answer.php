<?php include 'common/header.php';?>

<h1>XML Assignment</h1>

<pre>
<?php

	$xml = new DOMDocument("1.0");
	$root = $xml->createElement("users");
	$xml->appendChild($root);
	
	$id   = $xml->createElement("id");
	$idText = $xml->createTextNode('1');
	$id->appendChild($idText);
	
	$name   = $xml->createElement("name");
	$nameText = $xml->createTextNode("Amitabha");
	$name->appendChild($nameText);
	
	$email   = $xml->createElement("email");
	$emailText = $xml->createTextNode("a@a.a");
	$email->appendChild($emailText);
	
	$mobile   = $xml->createElement("mobile");
	$mobileText = $xml->createTextNode("9876543210");
	$mobile->appendChild($mobileText);
	
	$delete   = $xml->createElement("delete");
	$deleteText = $xml->createTextNode("N");
	$delete->appendChild($deleteText);
	
	$user = $xml->createElement("user");
	$user->appendChild($id);
	$user->appendChild($name);
	$user->appendChild($email);
	$user->appendChild($mobile);
	$user->appendChild($delete);
	
	$root->appendChild($user);
	$xml->formatOutput = true;
	echo "<xmp>". $xml->saveXML() ."</xmp>";
	//Run the following code only once to create database.xml file
	$xml->save("database.xml") or die("Error");

?>
</pre>

<p><a href="assignment06_AllUsers.php" class="btn btn-success">View All Users</a></p>

<?php include 'common/footer.php';?>
