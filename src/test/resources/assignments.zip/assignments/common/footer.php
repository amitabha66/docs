			</div>
		</div>
	</div>
	<footer class="footer">
		<div class="container">
			<p class="text-muted">This is sticky footer. Empid - 796763. Name - Amitabha Roy</p>
		</div>
	</footer>

	<!-- Bootstrap core JavaScript
	    ================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="jquery/jquery-1.11.1.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script>
	$( document.body ).on( 'click', '.dropdown-menu li', function( event ) {
		 
		   var $target = $( event.currentTarget );
		 
		   $target.closest( '.btn-group' )
		      .find( '[data-bind="label"]' ).text( $target.text() )
		         .end()
		      .children( '.dropdown-toggle' ).dropdown( 'toggle' );
		 
		   return false;
		 
		});
	</script>
</body>
</html>