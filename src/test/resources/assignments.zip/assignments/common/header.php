<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="../../favicon.ico">
	
	<title>PHP Assignments</title>
	
	<!-- Bootstrap core CSS -->
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Custom styles for this template -->
	<link href="css/sticky-footer-navbar.css" rel="stylesheet">
	<style type="text/css">
	.form-group.required .control-label:after { 
	    color: #d00;
	    content: "*";
	    sposition: absolute;
	    margin-left: 8px;
	    top:7px;
	    font-family: 'Glyphicons Halflings';
		font-weight: normal;
		font-size: 14px;
	}
	.form-group .control-label:after { 
	    color: #d00;
	    content: " ";
	    sposition: absolute;
	    margin-left: 22px;
	    top:7px;
	    font-family: 'Glyphicons Halflings';
		font-weight: normal;
		font-size: 14px;
	}
	</style>
	
	<style type="text/css">
		.btn-input {
		   display: block;
		}
		 
		.btn-input .btn.form-control {
		    text-align: left;
		}
		 
		.btn-input .btn.form-control span:first-child {
		   left: 10px;
		   overflow: hidden;
		   position: absolute;
		   right: 25px;
		}
		 
		.btn-input .btn.form-control .caret {
		   margin-top: -1px;
		   position: absolute;
		   right: 10px;
		   top: 50%;
		}
		.checkbox {
			float: left;
		}
	</style>
	
</head>

<body>
	<!-- Fixed navbar -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="/assignments"><span class="glyphicon glyphicon-home"></span> PHP Assignments</a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<!-- li class="active"><a href="#">Home</a></li-->
					<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-star"></span> All Assignments <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="assignment01.php">Assignment 1</a></li>
							<li><a href="assignment02.php">Assignment 2</a></li>
							<li><a href="assignment03.php">Assignment 3</a></li>
							<li><a href="assignment04.php">Assignment 4</a></li>
							<li><a href="assignment05.php">Assignment 5</a></li>
							<li><a href="assignment06.php">Assignment 6</a></li>
						</ul>
					</li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php session_start(); ?>
					<?php if( isset($_SESSION['UserName']) && $_SESSION['UserName'] != ""){ ?>
			            <li><a href="logout.php">Logout - <?php echo $_SESSION['UserName']; ?></a></li>
			        <?php } else {?>
			        	<li><a href="logout.php">Login</a></li>
			        <?php }?>
		        </ul>
			</div><!--/.nav-collapse -->
		</div>
	</nav>
	<!-- Begin page content -->
	<div class="container" style="background: #EEFFFF;">
		<div class="row">
			<div class="col-sx-12 col-sm-6 col-md-3 col-lg-3" style="background: #EFEFEF;">
				<a href="assignment01.php" class="btn btn-primary btn-lg btn-block">Assignment 1</a><br />
				<a href="assignment02.php" class="btn btn-primary btn-lg btn-block">Assignment 2</a><br />
				<a href="assignment03.php" class="btn btn-primary btn-lg btn-block">Assignment 3</a><br />
				<a href="assignment04.php" class="btn btn-primary btn-lg btn-block">Assignment 4</a><br />
				<a href="assignment05.php" class="btn btn-primary btn-lg btn-block">Assignment 5</a><br />
				<a href="assignment06.php" class="btn btn-primary btn-lg btn-block">Assignment 6</a><br />
			</div>
			<div class="col-sx-0 col-sm-6 col-md-9 col-lg-9">