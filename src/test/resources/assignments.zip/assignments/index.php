<?php include 'common/header.php';?>
<h1>PHP Assignments</h1>
<p><?php
/*
 echo $_SERVER['PHP_SELF'];
 echo "<br>";
 echo $_SERVER['SERVER_NAME'];
 echo "<br>";
 echo $_SERVER['HTTP_HOST'];
 echo "<br>";
 echo $_SERVER['HTTP_REFERER'];
 echo "<br>";
 echo $_SERVER['HTTP_USER_AGENT'];
 echo "<br>";
 echo $_SERVER['SCRIPT_NAME'];
 */
?></p>


<?php
if( isset($_SESSION["UserName"]) && $_SESSION["UserName"] != ""){
	echo "Welcome !" . $_SESSION["UserName"] . "!<br />";
	echo date("Y-m-d h:i:sa", strtotime("today")) . "<br />";
} else {
	echo "User not detected";
}
?>

<?php include 'common/footer.php';?>
