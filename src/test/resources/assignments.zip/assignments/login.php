<?php include 'common/header.php';?>

<?php
	// setcookie( "UserName", "", time()- 60); // Delete Old Cookie
?>

<?php 
	if((isset($_SESSION['loginError'])) && ($_SESSION['loginError'] != "")) {
		echo $_SESSION['loginError'];
		$_SESSION['loginError'] = "";
	}

?>

<form class="form-horizontal" action="relogin.php" method="post">
	<div class="form-group">
		<label for="inputUserName" class="control-label col-xs-3">Username</label>
		<div class="col-xs-9"><input type="text" class="form-control" id="inputUserName" name="inputUserName" placeholder="Username"></div>
	</div>
	<div class="form-group">
		<label for="inputPassword" class="control-label col-xs-3">Password</label>
		<div class="col-xs-9"><input type="password" class="form-control" id="inputPassword" name="inputPassword" placeholder="Password"></div>
	</div>
	<div class="form-group">
		<label for="inputQuestion" class="control-label col-xs-3">Secret Question</label>
		<div class="col-xs-9">
			<select class="selectpicker form-control" id="inputQuestion" name="inputQuestion">
				<option value="1">What is your mother's maiden name?</option>
				<option value="2">What is your father's middle name?</option>
				<option value="3">What is your first mobile number?</option>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label for="inputAnswer" class="control-label col-xs-3">Answer</label>
		<div class="col-xs-9"><input type="password" class="form-control" id="inputAnswer" name="inputAnswer" placeholder="Answer"></div>
	</div>
	<div class="form-group">
		<div class="col-xs-offset-2 col-xs-10">
			<button type="submit" class="btn btn-primary">Login</button>
		</div>
	</div>
</form>

<?php include 'common/footer.php';?>