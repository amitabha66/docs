<?php 
	session_start();
	$_SESSION['UserName'] = "";
	header("Location: http://localhost/assignments/login.php");
?>