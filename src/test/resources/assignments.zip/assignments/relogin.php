<?php include 'common/header.php';?>
<?php
	$UserName = "";
	$UserPassword = "";
	$QuestionSequence = "";
	$Answer = "";
	if (isset($_POST['inputUserName'])) {
		$UserName = $_POST['inputUserName'];
		$UserPassword = $_POST['inputPassword'];
		$QuestionSequence = $_POST['inputQuestion'];
		$Answer = $_POST['inputAnswer'];
		$_SESSION['UserName'] = $UserName;
		$_SESSION['UserPassword'] = $UserPassword;
		$_SESSION['QuestionSequence'] = $QuestionSequence;
		$_SESSION['Answer'] = $Answer;
	} else {
		session_destroy ();
	}
?>

<?php
	/**
	 * Cookie must be before any echo statements.
	 */
	if( isset($_COOKIE["UserName"]) && $_COOKIE["UserName"] != "") {
		//setcookie( "UserName", "", time()- 60); // Delete Old Cookie
	}
	if(isset($UserName) && $UserName != "") {
		//setcookie( "UserName", $UserName);
	} else {
		//setcookie( "UserName", "", time()- 60); // Delete Old Cookie
	}
?>

<?php
	if(isset($UserName) && $UserName != "") {
?>
	<h2>Please confirm your identification:</h2>
	<form class="form-horizontal" action="ValidateUser.php" method="post">
		<div class="form-group">
			<label for="inputQuestion1" class="control-label col-xs-3">Secret Question</label>
			<div class="col-xs-9"><input type="text" class="form-control disabled" id="inputQuestion1" name="inputQuestion1" value="<?php 
				if(strcmp($QuestionSequence, "1") == 0) {
					echo "What is your mother's maiden name?";
				} else if(strcmp($QuestionSequence, "2") == 0) {
					echo "What is your father's middle name?";
				} else if(strcmp($QuestionSequence, "3") == 0) {
					echo "What is your first mobile number?";
				} else {
					echo "-".$QuestionSequence."-";
				}
			?>"></div>
		</div>
		<div class="form-group">
			<label for="inputAnswer1" class="control-label col-xs-3">Answer</label>
			<div class="col-xs-9"><input type="password" class="form-control" id="inputAnswer1" name="inputAnswer1" placeholder="Answer"></div>
		</div>
		<div class="form-group">
			<div class="col-xs-offset-2 col-xs-10">
				<button type="submit" class="btn btn-primary">Confirm</button>
			</div>
		</div>
	</form>
<?php
		echo "Username is (" . $UserName . ")<br />";
	} else {
		echo "Login not possible as Username is blank<br />";
		//header("Location: http://localhost/assignments/login.php");
	}
?>
<?php include 'common/footer.php';?>