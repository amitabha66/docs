package com.diego.auth;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;
import com.diego.service.UserService;

@Repository
public class CustomUserDetailsService implements UserDetailsService {
	
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(CustomUserDetailsService.class.getName());

    @Autowired
    private UserService userService;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
    	logger.log(DiegoLogger.INFO, "loadUserByUsername() = " + userName);
        User user = userService.getUserByUserName(userName);
        logger.log(DiegoLogger.INFO, "loadUserByUsername() = " + user);
        List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        for (Role role : user.getRoles()) {
            for (Permission permission : role.getPermissions()) {
                grantedAuthorities.add(new SimpleGrantedAuthority(permission.getPermissionName()));
            }
        }
        UserDetails userDetails = new CustomUserDetails(user, grantedAuthorities);
        return userDetails;
    }
}
