package com.diego.auth;

import java.io.BufferedReader;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.google.gson.Gson;

public class CustomUsernamePasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(CustomUsernamePasswordAuthenticationFilter.class.getName());
	
    private String jsonUsername;
    private String jsonPassword;

    @Override
    protected String obtainPassword(HttpServletRequest request) {
    	logger.log(DiegoLogger.DEBUG, "obtainPassword()");
        String password = null;
        BufferedReader reader = null;
        try {
        	if (request.getHeader("Content-Type").contains("application/json")) {
            	reader = request.getReader();
                Gson gson = new Gson();
                LoginRequest loginRequest = gson.fromJson(reader, LoginRequest.class);
                password = loginRequest.getPassword();
            }else{
                password = super.obtainPassword(request);
            }
		} catch (Exception e) {
			logger.log(DiegoLogger.ERROR, e.getMessage());
			logger.log(DiegoLogger.ERROR, "" + e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e2) {
					logger.log(DiegoLogger.ERROR, e2.getMessage());
				}
			}
		}
        return password;
    }

    @Override
    protected String obtainUsername(HttpServletRequest request){
    	logger.log(DiegoLogger.DEBUG, "obtainUsername()");
        String username = null;
        BufferedReader reader = null;
        try {
	        if (request.getHeader("Content-Type").contains("application/json")) {
	        	reader = request.getReader();
                Gson gson = new Gson();
                LoginRequest loginRequest = gson.fromJson(reader, LoginRequest.class);
	            username = loginRequest.getUsername();
	        }else{
	            username = super.obtainUsername(request);
	        }
        } catch (Exception e) {
        	e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e2) {
					logger.log(DiegoLogger.ERROR, e2.getMessage());
				}
			}
		}
        return username;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response){
    	logger.log(DiegoLogger.DEBUG, "attemptAuthentication()");
        if (request.getHeader("Content-Type").contains("application/json")) {
        	BufferedReader reader = null;
            try {
            	reader = request.getReader();
                Gson gson = new Gson();
                LoginRequest loginRequest = gson.fromJson(reader, LoginRequest.class);
                this.jsonUsername = loginRequest.getUsername();
                this.jsonPassword = loginRequest.getPassword();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
    			if (reader != null) {
    				try {
    					reader.close();
					} catch (Exception e2) {
						logger.log(DiegoLogger.ERROR, e2.getMessage());
					}
    			}
    		}
        }
        return super.attemptAuthentication(request, response);
    }
}
