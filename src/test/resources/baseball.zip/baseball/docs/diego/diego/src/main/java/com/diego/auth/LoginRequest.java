package com.diego.auth;

public class LoginRequest {
	private String j_username;
	private String j_password;

	public String getUsername() {
		return j_username;
	}

	public void setUsername(String j_username) {
		this.j_username = j_username;
	}

	public String getPassword() {
		return j_password;
	}

	public void setPassword(String j_password) {
		this.j_password = j_password;
	}

}
