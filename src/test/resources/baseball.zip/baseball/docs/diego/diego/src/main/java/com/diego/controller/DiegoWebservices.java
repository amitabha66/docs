package com.diego.controller;

import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.Role;
import com.diego.model.User;
import com.diego.service.UserService;

@RestController
@RequestMapping(value = "/rest")
public class DiegoWebservices {
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(DiegoWebservices.class.getName());

	@Autowired(required = true)
	private UserService userService;

	/**
	 * Returns all available roles for the current user in session.
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getAllRoles", method = RequestMethod.GET)
	public Set<Role> getAllRoles(HttpSession session) {
		logger.log(DiegoLogger.INFO, "getAllRoles()");
		User loggedInUser = (User) session.getAttribute("LOGGED_IN_USER");
		Set<Role> roleSet = userService.getAllRoles(loggedInUser);
		logger.log(DiegoLogger.INFO, "roleSet = " + roleSet);
		return roleSet;
	}
	
	/**
	 * Returns all available privileges for the current user in session.
	 * 
	 * @param session
	 * @return
	 */
//	@RequestMapping(value = "/getAllPrivileges", method = RequestMethod.GET)
//	public Set<String> getAllPrivileges(HttpSession session) {
//		logger.log(DiegoLogger.INFO, "getAllPrivileges()");
//		User loggedInUser = (User) session.getAttribute("LOGGED_IN_USER");
//		Set<String> privilegeSet = userService.getAllPrivileges(loggedInUser);
//		logger.log(DiegoLogger.INFO, "privilegeSet = " + privilegeSet);
//		return privilegeSet;
//	}

	/**
	 * Returns true if a particular privilege is present for the current user in
	 * session, otherwise returns false.
	 * 
	 * @param session
	 * @param privilege
	 * @return
	 */
//	@RequestMapping(value = "/hasPrivilege/{privilege}", method = RequestMethod.GET)
//	public boolean hasPrivilege(HttpSession session, @PathVariable String privilege) {
//		logger.log(DiegoLogger.INFO, "hasPrivilege()");
//		User loggedInUser = (User) session.getAttribute("LOGGED_IN_USER");
//		boolean privilegeFound = userService.hasPrivilege(loggedInUser, privilege);
//		logger.log(DiegoLogger.INFO, "privilegeFound = " + privilegeFound);
//		return privilegeFound;
//	}

	/**
	 * Returns true if all the privileges are present for the current user in
	 * session, otherwise returns false.
	 * 
	 * @param session
	 * @param privileges
	 * @return
	 */
//	@RequestMapping(value = "/hasAllPrivileges", method = RequestMethod.POST)
//	public boolean hasAllPrivileges(HttpSession session, @RequestBody List<String> privileges) {
//		logger.log(DiegoLogger.INFO, "hasAllPrivileges()");
//		User loggedInUser = (User) session.getAttribute("LOGGED_IN_USER");
//		boolean privilegeFound = userService.hasAllPrivileges(loggedInUser, privileges);
//		logger.log(DiegoLogger.INFO, "privilegeFound = " + privilegeFound);
//		return privilegeFound;
//	}
}
