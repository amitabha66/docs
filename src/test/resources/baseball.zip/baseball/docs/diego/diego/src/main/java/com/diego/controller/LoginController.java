package com.diego.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.diego.auth.CustomUserDetails;
import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.User;

@Controller
public class LoginController {

	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(LoginController.class.getName());

	@RequestMapping(value = "/")
	public ModelAndView defaultPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("/login.jsp");
		logger.log(DiegoLogger.INFO, "ViewName: " + mav.getViewName());
		return mav;
	}

	@RequestMapping(value = "/landing", method = RequestMethod.GET)
	public ModelAndView landing(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("/welcome.jsp");
		User user = (User) request.getSession().getAttribute("loggedInUser");
		//mav.addObject("welcomeMessage", "Hello " + );
		logger.log(DiegoLogger.INFO, "ViewName: " + mav.getViewName());
		return mav;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
		request.getSession().invalidate();
		try {
			request.logout();
		} catch (ServletException e) {
			logger.log(DiegoLogger.ERROR, "Logout ERROR: " + e.getMessage());
		}
		ModelAndView mav = new ModelAndView("/login.jsp");
		logger.log(DiegoLogger.INFO, "ViewName: " + mav.getViewName());
		mav.addObject("logoutMsg", "You are logged out!");
		return mav;
	}

	@RequestMapping(value = "/loginerr", method = RequestMethod.GET)
	public ModelAndView loginerr(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("/login.jsp");
		logger.log(DiegoLogger.INFO, "ViewName: " + mav.getViewName());
		mav.addObject("loginErr", "Invalid username or password!");
		return mav;
	}

}
