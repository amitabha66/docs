package com.diego.dao;

import com.diego.model.User;

public interface UserDao {

	User getUserByUserName(String userName);

}
