package com.diego.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;
import com.diego.model.UserTO;

@Repository
public class UserDaoImpl implements UserDao {
	
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(UserDaoImpl.class.getName());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate template) {
		this.jdbcTemplate = template;
	}

	class UserTOMapper implements RowMapper<UserTO> {
		public UserTO mapRow(ResultSet rs, int index) throws SQLException {
			UserTO to = new UserTO();
			to.setUserId(rs.getString(1));
			to.setUserName(rs.getString(2));
			to.setPassword(rs.getString(3));
			to.setStatus(rs.getString(4));
			to.setRoleId(rs.getString(5));
			to.setRoleName(rs.getString(6));
			to.setPermissionId(rs.getString(7));
			to.setPermissionName(rs.getString(8));
			return to;
		}
	}

	class RoleMapper implements RowMapper<Role> {
		public Role mapRow(ResultSet rs, int index) throws SQLException {
			Role role = new Role();
			role.setRoleId(Long.valueOf(rs.getString(1)));
			role.setRoleName(rs.getString(2));
			return role;
		}
	}

	class PermissionMapper implements RowMapper<Permission> {
		public Permission mapRow(ResultSet rs, int index) throws SQLException {
			Permission permission = new Permission();
			permission.setPermissionId(Long.valueOf(rs.getString(1)));
			permission.setPermissionName(rs.getString(2));
			return permission;
		}
	}

	public User getMockUserByUserName(String userName) {
		User user = new User();
		user.setUserName("diego");
		user.setPassword("diego");

		Set<Role> roles = new HashSet<Role>();
		Role role = new Role();
		role.setRoleName("DIEGO_ROLE");

		Set<Permission> permissions = new HashSet<Permission>();
		Permission permission = new Permission();
		permission.setPermissionName("DIEGO_PERMISSION");
		permissions.add(permission);
		role.setPermissions(permissions);

		roles.add(role);

		user.setRoles(roles);
		return user;
	}

	public User getUserByUserName(String userName) {
		String query = "SELECT U.USER_ID, U.USERNAME, U.PASSWORD, U.STATUS, R.ROLE_ID, R.ROLE_NAME, P.PERMISSION_ID, P.PERMISSION_NAME";
		query = query + " FROM USERS U, USER_ROLE UR, ROLES R, ROLE_PERMISSION RP, PERMISSIONS P";
		query = query + " WHERE U.USERNAME = '" + userName + "'";
		query = query + " AND U.USER_ID = UR.USER_ID";
		query = query + " AND UR.ROLE_ID = R.ROLE_ID";
		query = query + " AND R.ROLE_ID = RP.ROLE_ID";
		query = query + " AND RP.PERMISSION_ID = P.PERMISSION_ID";
		List<UserTO> userTOList = jdbcTemplate.query(query, new UserTOMapper());
		return mapToUser(userTOList);
	}

	private User mapToUser(List<UserTO> userTOList) {
		User user = new User();
		Set<Role> roles = new HashSet<Role>();
		for (UserTO to : userTOList) {
			Long userId = Long.valueOf(to.getUserId());
			user.setUserId(userId);
			user.setUserName(to.getUserName());
			user.setPassword(to.getPassword());
			user.setStatus(to.getStatus());
			Role role = new Role();
			Long roleId = Long.valueOf(to.getRoleId());
			role.setRoleId(roleId);
			role.setRoleName(to.getRoleName());
			roles.add(role);
		}
		user.setRoles(roles);
		for(Role role : roles){
			String roleId = role.getRoleId().toString();
			for (UserTO to : userTOList) {
				Permission permission = new Permission();
				permission.setPermissionId(Long.valueOf(to.getPermissionId()));
				permission.setPermissionName(to.getPermissionName());
				String roleIdString = to.getRoleId();
				if(roleId.equals(roleIdString)){
					role.getPermissions().add(permission);
				}
			}
		}
		logger.log(DiegoLogger.INFO, user.toString());
		return user;
	}

}
