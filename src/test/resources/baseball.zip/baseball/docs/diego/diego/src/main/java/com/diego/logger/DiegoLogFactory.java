package com.diego.logger;

public class DiegoLogFactory {

	public static DiegoLogger getLoggerInstance(final String className) {
		DiegoLogger logger = new DiegoLog4j2LoggerImpl(className);
		return logger;
	}

	public static DiegoLogger getLoggerInstance(final String className, final String contractName) {
		DiegoLogger logger = new DiegoLog4j2LoggerImpl(className);
		return logger;
	}
	
	public static void printLogs() {
		printLog4j2Logs();
	}
	
	public static void printLog4j2Logs() {
		final DiegoLogger logger = new DiegoLog4j2LoggerImpl(DiegoLogFactory.class.getName());
		logger.log(DiegoLogger.INFO,  "--------- Log4j2 INFO  Log ---------");
		logger.log(DiegoLogger.DEBUG, "--------- Log4j2 DEBUG Log ---------");
		logger.log(DiegoLogger.WARN,  "--------- Log4j2 WARN  Log ---------");
		logger.log(DiegoLogger.ERROR, "--------- Log4j2 ERROR Log ---------");
	}
}