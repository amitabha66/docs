package com.diego.service;

import java.util.Set;

import com.diego.model.Role;
import com.diego.model.User;

public interface UserService {

	User getUserByUserName(String userName);

	Set<Role> getAllRoles(User loggedInUser);

}