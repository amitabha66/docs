package com.diego.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diego.dao.UserDao;
import com.diego.model.Role;
import com.diego.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userDao;

	@Override
	public User getUserByUserName(String userName) {
		return userDao.getUserByUserName(userName);
	}

	@Override
	public Set<Role> getAllRoles(User loggedInUser) {
		return loggedInUser.getRoles();
	}

}
