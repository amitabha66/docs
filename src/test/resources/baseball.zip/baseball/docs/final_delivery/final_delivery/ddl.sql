DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `PERMISSION_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PERMISSION_NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`PERMISSION_ID`)
) ;
INSERT INTO `permissions` (`PERMISSION_ID`,`PERMISSION_NAME`) VALUES 
 (1,'ACCESS_RESOURCES'),
 (2,'ACCESS_WEBSERVICES');

DROP TABLE IF EXISTS `role_permission`;
CREATE TABLE `role_permission` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ROLE_ID` int(10) unsigned NOT NULL,
  `PERMISSION_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `role_permission` (`ID`,`ROLE_ID`,`PERMISSION_ID`) VALUES 
 (1,1,1),
 (2,2,1),
 (3,2,2);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `ROLE_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ROLE_NAME` varchar(45) NOT NULL,
  PRIMARY KEY (`ROLE_ID`)
) ;
INSERT INTO `roles` (`ROLE_ID`,`ROLE_NAME`) VALUES 
 (1,'ROLE_USER'),
 (2,'ROLE_ADMIN');

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `USER_ID` int(10) unsigned NOT NULL,
  `ROLE_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ;
INSERT INTO `user_role` (`ID`,`USER_ID`,`ROLE_ID`) VALUES 
 (1,1,1),
 (2,2,2);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `USER_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(45) NOT NULL,
  `PASSWORD` varchar(45) NOT NULL,
  `STATUS` varchar(45) NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ;
INSERT INTO `users` (`USER_ID`,`USERNAME`,`PASSWORD`,`STATUS`) VALUES 
 (1,'roy4j','roy4j','AC'),
 (2,'diego','diego','AC');
 