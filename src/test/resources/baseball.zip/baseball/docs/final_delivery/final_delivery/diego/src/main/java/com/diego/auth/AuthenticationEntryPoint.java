package com.diego.auth;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;

public class AuthenticationEntryPoint implements org.springframework.security.web.AuthenticationEntryPoint {
	
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(AuthenticationEntryPoint.class.getName());

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException arg2) throws IOException, ServletException {
    	logger.log(DiegoLogger.INFO, "AuthenticationEntryPoint.commence()");
    	response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
    }
}
