package com.diego.dao;

import java.util.Set;

import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;

public interface UserDao {

	User getUserTreeByUserName(String userName);
	User setUserTree(User user);

	User getUserByUserName(String userName);
	User createUser(User newUser);
	User updateUser(User existingUser);
	User deleteUser(User existingUser);

	Set<Role> getAllRolesByUserName(String userName);
	Role createRole(Role newRole);
	Role updateRole(Role existingRole);
	Role deleteRole(Role existingRole);

	Set<Permission> getAllPermissionsByUserName(String userName);
	Permission createPermission(Permission newPermission);
	Permission updatePermission(Permission existingPermission);
	Permission deletePermission(Permission existingPermission);

}
