package com.diego.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;
import com.diego.model.UserTO;
import com.diego.model.mapper.PermissionMapper;
import com.diego.model.mapper.RoleMapper;
import com.diego.model.mapper.UserMapper;
import com.diego.model.mapper.UserTOMapper;

@Repository
public class UserDaoImpl implements UserDao {
	
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(UserDaoImpl.class.getName());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate template) {
		this.jdbcTemplate = template;
	}

	@Override
	public User getUserTreeByUserName(String userName) {
		String query = "SELECT U.USER_ID, U.USERNAME, U.PASSWORD, U.STATUS, R.ROLE_ID, R.ROLE_NAME, P.PERMISSION_ID, P.PERMISSION_NAME";
		query = query + " FROM USERS U, USER_ROLE UR, ROLES R, ROLE_PERMISSION RP, PERMISSIONS P";
		query = query + " WHERE U.USERNAME = '" + userName + "'";
		query = query + " AND U.USER_ID = UR.USER_ID";
		query = query + " AND UR.ROLE_ID = R.ROLE_ID";
		query = query + " AND R.ROLE_ID = RP.ROLE_ID";
		query = query + " AND RP.PERMISSION_ID = P.PERMISSION_ID";
		logger.log(DiegoLogger.INFO, query);
		List<UserTO> userTOList = jdbcTemplate.query(query, new UserTOMapper());
		return mapToUser(userTOList);
	}
	
	@Override
	public User setUserTree(User user) {
		boolean status = false;
		Long userId = user.getUserId();
		Set<Role> roles = user.getRoles();
		if (roles != null && !roles.isEmpty()) {
			for (Role role : roles) {
				Long roleId = role.getRoleId();
				status = insertIntoUserRole(userId, roleId);
				Set<Permission> permissions = role.getPermissions();
				if (permissions != null && !permissions.isEmpty()) {
					for (Permission permission : permissions) {
						Long permissionId = permission.getPermissionId();
						status = insertIntoRolePermission(roleId, permissionId);
					}
				} else {
					logger.log(DiegoLogger.ERROR, "NO Permission to insert");
					status = false;
				}
			}
		} else {
			logger.log(DiegoLogger.ERROR, "NO Role to insert");
			status = false;
		}
		if (status == true) {
			return getUserTreeByUserName(user.getUserName());
		} else {
			return user;
		}
	}

	private boolean insertIntoUserRole(Long userId, Long roleId) {
		String query = "INSERT INTO `USER_ROLE` (`USER_ID`, `ROLE_ID`) VALUES ("+userId+", "+roleId+")";
		int insertCount = jdbcTemplate.update(query);
		if(insertCount == 1) {
			logger.log(DiegoLogger.INFO, "USER_ROLE created successfully");
			return true;
		} else {
			logger.log(DiegoLogger.ERROR, "USER_ROLE was NOT created");
			return false;
		}
	}
	
	private boolean insertIntoRolePermission(Long roleId, Long permissionId) {
		String query = "INSERT INTO `ROLE_PERMISSION` (`ROLE_ID`, `PERMISSION_ID`) VALUES ("+roleId+", "+permissionId+")";
		int insertCount = jdbcTemplate.update(query);
		if(insertCount == 1) {
			logger.log(DiegoLogger.INFO, "ROLE_PERMISSION created successfully");
			return true;
		} else {
			logger.log(DiegoLogger.ERROR, "ROLE_PERMISSION was NOT created");
			return false;
		}
	}

	@Override
	public User getUserByUserName(String userName) {
		String query = "SELECT * FROM USERS WHERE USERNAME = '" + userName + "'";
		logger.log(DiegoLogger.INFO, query);
		List<User> userList = jdbcTemplate.query(query, new UserMapper());
		if (userList != null && !userList.isEmpty()) {
			logger.log(DiegoLogger.INFO, "User found: " + userName);
			return userList.get(0);
		} else {
			logger.log(DiegoLogger.INFO, "User NOT found: " + userName);
			return null;
		}
	}

	@Override
	public User createUser(User newUser) {
		String query = "INSERT INTO `USERS` (`USERNAME`,`PASSWORD`,`STATUS`) VALUES ('"
				+ newUser.getUserName()
				+ "','"
				+ newUser.getPassword()
				+ "','AC')";
		logger.log(DiegoLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if(insertCount == 1) {
			logger.log(DiegoLogger.INFO, "User created successfully");
			return getUserByUserName(newUser.getUserName());
		} else {
			newUser.setUserId(0L);
			logger.log(DiegoLogger.ERROR, "User was NOT created");
			return newUser;
		}
	}

	@Override
	public User updateUser(User existingUser) {
		String query = "UPDATE `USERS` SET USERNAME = '" + existingUser.getUserName()
			+ "', PASSWORD = '" + existingUser.getPassword()
			+ "', STATUS = '" + existingUser.getStatus()
			+ "' WHERE USER_ID = " + existingUser.getUserId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if(updateCount == 1) {
			logger.log(DiegoLogger.INFO, "User updated successfully: " + existingUser.getUserName());
			return getUserByUserName(existingUser.getUserName());
		} else {
			existingUser.setUserId(0L);
			logger.log(DiegoLogger.ERROR, "User was NOT updated: " + existingUser.getUserName());
			return existingUser;
		}
	}

	@Override
	public User deleteUser(User existingUser) {
		String query = "DELETE FROM `USERS` WHERE USER_ID = " + existingUser.getUserId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingUser.setUserId(-1L);
			logger.log(DiegoLogger.INFO, "User deleted successfully: " + existingUser.getUserName());
			return existingUser;
		} else {
			logger.log(DiegoLogger.ERROR, "User was NOT deleted: " + existingUser.getUserName());
			return existingUser;
		}
	}

	@Override
	public Set<Role> getAllRolesByUserName(String userName) {
		String query = "SELECT R.* FROM USERS U, ROLES R, USER_ROLE UR WHERE U.USER_ID = UR.USER_ID AND UR.ROLE_ID = R.ROLE_ID AND U.USERNAME = '"+userName+"'";
		logger.log(DiegoLogger.INFO, query);
		List<Role> roleList = jdbcTemplate.query(query, new RoleMapper());
		if (roleList != null && !roleList.isEmpty()) {
			logger.log(DiegoLogger.INFO, "Roles found: " + userName);
			return new HashSet<Role>(roleList);
		} else {
			logger.log(DiegoLogger.INFO, "Role NOT found: " + userName);
			return null;
		}
	}

	@Override
	public Role createRole(Role newRole) {
		String query = "INSERT INTO `ROLES` (`ROLE_NAME`) VALUES ('" + newRole.getRoleName() + "')";
		logger.log(DiegoLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(DiegoLogger.INFO, "Role created successfully: " + newRole.getRoleName());
			return getRoleByRoleName(newRole.getRoleName());
		} else {
			newRole.setRoleId(0L);
			logger.log(DiegoLogger.ERROR, "Role was NOT created: " + newRole.getRoleName());
			return newRole;
		}
	}

	private Role getRoleByRoleName(String roleName) {
		String query = "SELECT * FROM ROLES WHERE ROLE_NAME = '"+roleName+"'";
		List<Role> roleList = jdbcTemplate.query(query, new RoleMapper());
		if(roleList!=null && !roleList.isEmpty()){
			logger.log(DiegoLogger.INFO, "Role found: " + roleName);
			return roleList.get(0);
		} else {
			logger.log(DiegoLogger.INFO, "Role NOT found: " + roleName);
			return null;
		}
	}

	@Override
	public Role updateRole(Role existingRole) {
		String query = "UPDATE `ROLES` SET ROLE_NAME = '" + existingRole.getRoleName() + "' WHERE ROLE_ID = " + existingRole.getRoleId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			logger.log(DiegoLogger.INFO, "Role updated successfully: " + existingRole.getRoleName());
			return getRoleByRoleName(existingRole.getRoleName());
		} else {
			existingRole.setRoleId(0L);
			logger.log(DiegoLogger.ERROR, "Role was NOT updated: " + existingRole.getRoleName());
			return existingRole;
		}
	}

	@Override
	public Role deleteRole(Role existingRole) {
		String query = "DELETE FROM `ROLES` WHERE ROLE_ID = " + existingRole.getRoleId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingRole.setRoleId(-1L);
			logger.log(DiegoLogger.INFO, "Role deleted successfully: " + existingRole.getRoleName());
			return existingRole;
		} else {
			logger.log(DiegoLogger.ERROR, "Role was NOT deleted: " + existingRole.getRoleName());
			return existingRole;
		}
	}

	@Override
	public Set<Permission> getAllPermissionsByUserName(String userName) {
		String query = "SELECT P.*";
		query = query + " FROM USERS U, USER_ROLE UR, ROLES R, ROLE_PERMISSION RP, PERMISSIONS P";
		query = query + " WHERE U.USERNAME = '" + userName + "'";
		query = query + " AND U.USER_ID = UR.USER_ID";
		query = query + " AND UR.ROLE_ID = R.ROLE_ID";
		query = query + " AND R.ROLE_ID = RP.ROLE_ID";
		query = query + " AND RP.PERMISSION_ID = P.PERMISSION_ID";
		logger.log(DiegoLogger.INFO, query);
		List<Permission> permissionList = jdbcTemplate.query(query, new PermissionMapper());
		if (permissionList != null && !permissionList.isEmpty()) {
			logger.log(DiegoLogger.INFO, "Permissions found: " + userName);
			return new HashSet<Permission>(permissionList);
		} else {
			logger.log(DiegoLogger.INFO, "Role NOT found: " + userName);
			return null;
		}
	}

	@Override
	public Permission createPermission(Permission newPermission) {
		String query = "INSERT INTO `PERMISSIONS` (`PERMISSION_NAME`) VALUES ('" + newPermission.getPermissionName() + "')";
		logger.log(DiegoLogger.INFO, query);
		int insertCount = jdbcTemplate.update(query);
		if (insertCount == 1) {
			logger.log(DiegoLogger.INFO, "Permission created successfully: " + newPermission.getPermissionName());
			return getPermissionByPermissionName(newPermission.getPermissionName());
		} else {
			newPermission.setPermissionId(0L);
			logger.log(DiegoLogger.ERROR, "Permission was NOT created: " + newPermission.getPermissionName());
			return newPermission;
		}
	}
	
	private Permission getPermissionByPermissionName(String permissionName) {
		String query = "SELECT * FROM PERMISSIONS WHERE PERMISSION_NAME = '"+permissionName+"'";
		List<Permission> permissionList = jdbcTemplate.query(query, new PermissionMapper());
		if(permissionList!=null && !permissionList.isEmpty()){
			logger.log(DiegoLogger.INFO, "Permission found: " + permissionName);
			return permissionList.get(0);
		} else {
			logger.log(DiegoLogger.INFO, "Permission NOT found: " + permissionName);
			return null;
		}
	}

	@Override
	public Permission updatePermission(Permission existingPermission) {
		String query = "UPDATE `PERMISSIONS` SET PERMISSION_NAME = '" + existingPermission.getPermissionName() + "' WHERE PERMISSION_ID = " + existingPermission.getPermissionId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			logger.log(DiegoLogger.INFO, "Permission updated successfully: " + existingPermission.getPermissionName());
			return getPermissionByPermissionName(existingPermission.getPermissionName());
		} else {
			existingPermission.setPermissionId(0L);
			logger.log(DiegoLogger.ERROR, "Permission was NOT updated: " + existingPermission.getPermissionName());
			return existingPermission;
		}
	}

	@Override
	public Permission deletePermission(Permission existingPermission) {
		String query = "DELETE FROM `PERMISSIONS` WHERE PERMISSION_ID = " + existingPermission.getPermissionId();
		logger.log(DiegoLogger.INFO, query);
		int updateCount = jdbcTemplate.update(query);
		if (updateCount == 1) {
			existingPermission.setPermissionId(-1L);
			logger.log(DiegoLogger.INFO, "Permission deleted successfully: " + existingPermission.getPermissionName());
			return existingPermission;
		} else {
			logger.log(DiegoLogger.ERROR, "Permission was NOT deleted: " + existingPermission.getPermissionName());
			return existingPermission;
		}
	}
	
	private User mapToUser(List<UserTO> userTOList) {
		User user = new User();
		Set<Role> roles = new HashSet<Role>();
		for (UserTO to : userTOList) {
			Long userId = Long.valueOf(to.getUserId());
			user.setUserId(userId);
			user.setUserName(to.getUserName());
			user.setPassword(to.getPassword());
			user.setStatus(to.getStatus());
			Role role = new Role();
			Long roleId = Long.valueOf(to.getRoleId());
			role.setRoleId(roleId);
			role.setRoleName(to.getRoleName());
			roles.add(role);
		}
		user.setRoles(roles);
		for(Role role : roles){
			String roleId = role.getRoleId().toString();
			for (UserTO to : userTOList) {
				Permission permission = new Permission();
				permission.setPermissionId(Long.valueOf(to.getPermissionId()));
				permission.setPermissionName(to.getPermissionName());
				String roleIdString = to.getRoleId();
				if(roleId.equals(roleIdString)){
					role.getPermissions().add(permission);
				}
			}
		}
		logger.log(DiegoLogger.INFO, user.toString());
		return user;
	}

	/**
	 * This method is test purpose only.
	 * 
	 * @param userName
	 * @return
	 */
	public User getMockUserByUserName(String userName) {
		User user = new User();
		user.setUserName("diego");
		user.setPassword("diego");

		Set<Role> roles = new HashSet<Role>();
		Role role = new Role();
		role.setRoleName("DIEGO_ROLE");

		Set<Permission> permissions = new HashSet<Permission>();
		Permission permission = new Permission();
		permission.setPermissionName("DIEGO_PERMISSION");
		permissions.add(permission);
		role.setPermissions(permissions);

		roles.add(role);

		user.setRoles(roles);
		return user;
	}

}
