package com.diego.model.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.diego.model.UserTO;

public class UserTOMapper implements RowMapper<UserTO> {
	public UserTO mapRow(ResultSet rs, int index) throws SQLException {
		UserTO to = new UserTO();
		to.setUserId(rs.getString("USER_ID"));
		to.setUserName(rs.getString("USERNAME"));
		to.setPassword(rs.getString("PASSWORD"));
		to.setStatus(rs.getString("STATUS"));
		to.setRoleId(rs.getString("ROLE_ID"));
		to.setRoleName(rs.getString("ROLE_NAME"));
		to.setPermissionId(rs.getString("PERMISSION_ID"));
		to.setPermissionName(rs.getString("PERMISSION_NAME"));
		return to;
	}
}