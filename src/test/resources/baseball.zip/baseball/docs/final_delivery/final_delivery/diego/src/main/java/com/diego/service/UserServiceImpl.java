package com.diego.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.diego.dao.UserDao;
import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Override
	public User getUserTreeByUserName(String userName) {
		return userDao.getUserTreeByUserName(userName);
	}
	
	@Override
	public User setUserTree(User user) {
		return userDao.setUserTree(user);
	}
	
	@Override
	public User getUserByUserName(String userName) {
		return userDao.getUserByUserName(userName);
	}

	@Override
	public User createUser(User newUser) {
		return userDao.createUser(newUser);
	}

	@Override
	public User updateUser(User existingUser) {
		return userDao.updateUser(existingUser);
	}

	@Override
	public User deleteUser(User existingUser) {
		return userDao.deleteUser(existingUser);
	}

	@Override
	public Set<Role> getAllRolesByUserName(String userName) {
		return userDao.getAllRolesByUserName(userName);
	}

	@Override
	public Role createRole(Role newRole) {
		return userDao.createRole(newRole);
	}

	@Override
	public Role updateRole(Role existingRole) {
		return userDao.updateRole(existingRole);
	}

	@Override
	public Role deleteRole(Role existingRole) {
		return userDao.deleteRole(existingRole);
	}

	@Override
	public Set<Permission> getAllPermissionsByUserName(String userName) {
		return userDao.getAllPermissionsByUserName(userName);
	}

	@Override
	public Permission createPermission(Permission newPermission) {
		return userDao.createPermission(newPermission);
	}

	@Override
	public Permission updatePermission(Permission existingPermission) {
		return userDao.updatePermission(existingPermission);
	}

	@Override
	public Permission deletePermission(Permission existingPermission) {
		return userDao.deletePermission(existingPermission);
	}

}
