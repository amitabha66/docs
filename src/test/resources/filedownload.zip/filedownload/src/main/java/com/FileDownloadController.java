package com;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FileDownloadController {
	
	@RequestMapping(value = "/assessments", method = RequestMethod.POST)
	public ModelAndView assessments() {
		System.out.println("---------------assessments---------------");
		System.out.println("Thread assessments: " + Thread.currentThread().getName());
		ModelAndView mav = new ModelAndView("NewPage");
		mav.addObject("action", "NewPage - ");
		try {
			mav.addObject("message", "Navigation to NewPage Successfully");
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: NewPage");
		}
		return mav;
	}

	
	
	@RequestMapping(value = "/downloadData/{id}", method = RequestMethod.GET)
	public void downloadData(@PathVariable("id") String studentId, HttpServletResponse resp) {
		System.out.println("Start: SessionOperationController.downloadData()");
		downloadBulkReportCSV(studentId, resp);
		System.out.println("End: SessionOperationController.downloadData()");
	}
	
	
	protected void downloadBulkReportCSV(String exportRequestIdStr, HttpServletResponse resp) {
		System.out.println("--Start: SessionOperationController.downloadBulkReportCSV()");
		long startTime = System.currentTimeMillis();
		OutputStream stream = null;
		try {
		    Long exportRequestId = Long.parseLong(exportRequestIdStr);
		    System.out.println(exportRequestId);
		    
		    String fileName = "test.csv";
		    String bodypart = "attachment; filename=\"" + fileName + "\" ";
		    try {
	        		resp.setContentType("text/csv");
	        		byte[] unzipData = "Hello World\n".getBytes(); //LayoutUtil.unZippedBytes(data);
	        		//resp.setContentLength(unzipData.length);
	        		resp.setHeader("Content-Disposition", bodypart);
	        		resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
				resp.setHeader("Pragma", "no-cache");
	        		stream = resp.getOutputStream();
	        		System.out.println("Wrinting file content to response output stream...");
	        		ByteArrayInputStream inStream = new ByteArrayInputStream(unzipData);
	        	        byte[] buffer = new byte[4096];
	        	        int bytesRead = -1;
	        	        //Integer i = 0;
	        	        System.out.println("Thread download: " + Thread.currentThread().getName());
	        	        while ((bytesRead = inStream.read(buffer)) != -1) {
	        	            while(true) {
	        	        	stream.write(buffer, 0, bytesRead);
	        	        	resp.flushBuffer();
	        	        	/*i = i + 1;
	        	        	if(i%1048576 == 0) {
	        	        	    System.out.println("Thread.yield(): " + i);
	        	        	    Thread.yield();
	        	        	    Thread.sleep(1000);
	        	        	}*/
	        	            }
	        	        }
	        		inStream.close();
	        		System.out.println("File content successfully written to response output stream!!!");
		    } catch (Exception e) {
				System.out.println("Exception while wtite to stream: " + e.getMessage());
	        		resp.setStatus(HttpServletResponse.SC_OK);
	                        try {
	                            resp.flushBuffer();
	                        } catch (Exception e1) {
	                            System.out.println("Exception: " + e1.getMessage());
	                        }
	        		e.printStackTrace();
		    } finally {
			   if (stream != null) {
				try {
				    	stream.flush();
				} catch (IOException e) {
				    	System.out.println("Exception: " + e.getMessage());
					e.printStackTrace();
				}
				try {
					stream.close();
				} catch (IOException e) {
				    System.out.println("Exception: " + e.getMessage());
					e.printStackTrace();
				}
			    }
		    }
		} catch (Exception e) {
		    System.out.println("Exception while downloadBulkReportCSV for Bulk Report: " + e.getMessage());
		    resp.setStatus(HttpServletResponse.SC_OK);
		    e.printStackTrace();
		} finally {
		    long endTime = System.currentTimeMillis();
		    System.out.println("File Download Time taken: " + (endTime - startTime) + " milliseconds");
		    System.out.println("--End: SessionOperationController.downloadBulkReportCSV(): " + (System.currentTimeMillis() - startTime) + " milliseconds");
		}
	    }
	
}
