package com.diego.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.diego.logger.DiegoLogFactory;
import com.diego.logger.DiegoLogger;
import com.diego.model.Permission;
import com.diego.model.Role;
import com.diego.model.User;
import com.diego.service.UserService;

/**
 * This class contains the REST webservices to administer users, roles and permissions.
 * 
 */
@RestController
@RequestMapping(value = "/rest")
public class DiegoWebservices {
	private static final DiegoLogger logger = DiegoLogFactory.getLoggerInstance(DiegoWebservices.class.getName());

	/**
	 * User service performs all the business logic to administer users, roles and permissions.
	 */
	@Autowired(required = true)
	private UserService userService;

	/**
	 * Returns the user with roles and permissions.
	 * 
	 * @param userName
	 * @return
	 */
	@RequestMapping(value = "/getUserTree/{userName}", method = RequestMethod.GET)
	public User getUserTree(@PathVariable("userName") String userName) {
		logger.log(DiegoLogger.INFO, "getUserTree()");
		User user = userService.getUserTreeByUserName(userName);
		logger.log(DiegoLogger.INFO, "user = " + user);
		return user;
	}

	/**
	 * Assigns roles and permissions to a user.
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/setUserTree", method = RequestMethod.POST)
	public User setUserTree(@RequestBody User user) {
		logger.log(DiegoLogger.INFO, "setUserTree(): " + user);
		User updatedUser = userService.setUserTree(user);
		logger.log(DiegoLogger.INFO, "user = " + updatedUser);
		return updatedUser;
	}

	/**
	 * Returns a user without roles and permissions.
	 * 
	 * @param userName
	 * @return
	 */
	@RequestMapping(value = "/getUser/{userName}", method = RequestMethod.GET)
	public User getUser(@PathVariable("userName") String userName) {
		logger.log(DiegoLogger.INFO, "getUser()");
		User user = userService.getUserByUserName(userName);
		logger.log(DiegoLogger.INFO, "user = " + user);
		return user;
	}

	/**
	 * Creates a user without roles and permissions assigned to it.
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public User createUser(@RequestBody User user) {
		logger.log(DiegoLogger.INFO, "createUser()");
		User newUser = userService.createUser(user);
		logger.log(DiegoLogger.INFO, "user = " + newUser);
		return newUser;
	}

	/**
	 * Updates the user properties without roles and permissions.
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public User updateUser(@RequestBody User user) {
		logger.log(DiegoLogger.INFO, "updateUser()");
		User updatedUser = userService.updateUser(user);
		logger.log(DiegoLogger.INFO, "User = " + updatedUser);
		return updatedUser;
	}

	/**
	 * Deletes the user but not the roles and permissions.
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public User deleteUser(@RequestBody User user) {
		logger.log(DiegoLogger.INFO, "deleteUser()");
		User deletedUser = userService.deleteUser(user);
		logger.log(DiegoLogger.INFO, "User = " + deletedUser);
		return deletedUser;
	}

	/**
	 * Returns all the roles assigned to an user.
	 * 
	 * @param userName
	 * @return
	 */
	@RequestMapping(value = "/getRoles/{userName}", method = RequestMethod.GET)
	public Set<Role> getRoles(@PathVariable("userName") String userName) {
		logger.log(DiegoLogger.INFO, "getRoles()");
		Set<Role> roles = userService.getAllRolesByUserName(userName);
		logger.log(DiegoLogger.INFO, "roles = " + roles);
		return roles;
	}

	/**
	 * Creates a role.
	 * 
	 * @param role
	 * @return
	 */
	@RequestMapping(value = "/createRole", method = RequestMethod.POST)
	public Role createRole(@RequestBody Role role) {
		logger.log(DiegoLogger.INFO, "createRole()");
		Role newRole = userService.createRole(role);
		logger.log(DiegoLogger.INFO, "Role = " + newRole);
		return newRole;
	}

	/**
	 * Updates a role.
	 * 
	 * @param role
	 * @return
	 */
	@RequestMapping(value = "/updateRole", method = RequestMethod.POST)
	public Role updateRole(@RequestBody Role role) {
		logger.log(DiegoLogger.INFO, "updateRole()");
		Role updatedRole = userService.updateRole(role);
		logger.log(DiegoLogger.INFO, "Role = " + updatedRole);
		return updatedRole;
	}

	/**
	 * Deletes a role.
	 * 
	 * @param role
	 * @return
	 */
	@RequestMapping(value = "/deleteRole", method = RequestMethod.POST)
	public Role deleteRole(@RequestBody Role role) {
		logger.log(DiegoLogger.INFO, "deleteRole()");
		Role deletedRole = userService.deleteRole(role);
		logger.log(DiegoLogger.INFO, "Role = " + deletedRole);
		return deletedRole;
	}

	/**
	 * Returns all the permissions assigned to an user.
	 * 
	 * @param userName
	 * @return
	 */
	@RequestMapping(value = "/getPermissions/{userName}", method = RequestMethod.GET)
	public Set<Permission> getPermissions(@PathVariable("userName") String userName) {
		logger.log(DiegoLogger.INFO, "getPermissions()");
		Set<Permission> permissions = userService.getAllPermissionsByUserName(userName);
		logger.log(DiegoLogger.INFO, "user = " + permissions);
		return permissions;
	}

	/**
	 * Creates a permission.
	 * 
	 * @param permission
	 * @return
	 */
	@RequestMapping(value = "/createPermission", method = RequestMethod.POST)
	public Permission createPermission(@RequestBody Permission permission) {
		logger.log(DiegoLogger.INFO, "createPermission()");
		Permission newPermission = userService.createPermission(permission);
		logger.log(DiegoLogger.INFO, "Permission = " + newPermission);
		return newPermission;
	}

	/**
	 * Updates a permission.
	 * 
	 * @param permission
	 * @return
	 */
	@RequestMapping(value = "/updatePermission", method = RequestMethod.POST)
	public Permission updatePermission(@RequestBody Permission permission) {
		logger.log(DiegoLogger.INFO, "updatePermission()");
		Permission updatedPermission = userService.updatePermission(permission);
		logger.log(DiegoLogger.INFO, "Permission = " + updatedPermission);
		return updatedPermission;
	}

	/**
	 * Deletes a permission.
	 * 
	 * @param permission
	 * @return
	 */
	@RequestMapping(value = "/deletePermission", method = RequestMethod.POST)
	public Permission deletePermission(@RequestBody Permission permission) {
		logger.log(DiegoLogger.INFO, "deletePermission()");
		Permission deletedPermission = userService.deletePermission(permission);
		logger.log(DiegoLogger.INFO, "Permission = " + deletedPermission);
		return deletedPermission;
	}

}
