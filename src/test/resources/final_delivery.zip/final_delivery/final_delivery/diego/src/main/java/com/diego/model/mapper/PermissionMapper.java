package com.diego.model.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.diego.model.Permission;

public class PermissionMapper implements RowMapper<Permission> {
	public Permission mapRow(ResultSet rs, int index) throws SQLException {
		Permission permission = new Permission();
		permission.setPermissionId(Long.valueOf(rs.getString("PERMISSION_ID")));
		permission.setPermissionName(rs.getString("PERMISSION_NAME"));
		return permission;
	}
}