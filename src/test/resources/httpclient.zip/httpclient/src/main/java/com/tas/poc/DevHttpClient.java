package com.tas.poc;

import java.io.IOException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.util.EntityUtils;

// stackoverflow.com/questions/7256955/java-sslexception-hostname-in-certificate-didnt-match
// mvn exec:java -Dexec.mainClass="com.tas.poc.DevHttpClient"
@SuppressWarnings({ "deprecation", "resource", "unused" })
public class DevHttpClient {

	private static final String URL = "https://mosaic-engine-int-i02-1565769760.us-east-1.elb.amazonaws.com/mosaic-engine/restapi/scoreitem";

	public static void main(String args[]) throws ClientProtocolException, IOException {
		// Example send http request
		HttpGet httpGet = new HttpGet(URL);
		HttpResponse response = getDefaultHttpClient().execute(httpGet);
		String entity = EntityUtils.toString(response.getEntity());
		System.out.println(entity);
	}

	private static DefaultHttpClient getDefaultHttpClient() {
		// Do not do this in production!!!
		HostnameVerifier hostnameVerifier = org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;

		DefaultHttpClient client = new DefaultHttpClient();
		SchemeRegistry registry = new SchemeRegistry();
		SSLSocketFactory socketFactory = SSLSocketFactory.getSocketFactory();
		socketFactory.setHostnameVerifier((X509HostnameVerifier) hostnameVerifier);
		registry.register(new Scheme("https", socketFactory, 443));
		SingleClientConnManager mgr = new SingleClientConnManager(client.getParams(), registry);
		DefaultHttpClient httpClient = new DefaultHttpClient(mgr, client.getParams());

		// Set verifier
		HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);
		return httpClient;
	}

}