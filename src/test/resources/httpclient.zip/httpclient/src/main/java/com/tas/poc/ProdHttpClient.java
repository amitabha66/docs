package com.tas.poc;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

// mvn exec:java -Dexec.mainClass="com.tas.poc.ProdHttpClient"
public class ProdHttpClient {
	private static final String URL = "https://mosaic-engine-int.ec2-ctb.com/mosaic-engine/restapi/scoreitem";

	public static void main(String[] args) throws ClientProtocolException, IOException {
		HttpClient client = HttpClients.createDefault();
		HttpGet get = new HttpGet(URL);
		HttpResponse response = client.execute(get);
		String entity = EntityUtils.toString(response.getEntity());
		System.out.println(entity);
	}
}