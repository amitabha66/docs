-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2015 at 11:48 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
`CATEGORY_ID` int(11) unsigned NOT NULL,
  `CATEGORY_NAME` varchar(100) NOT NULL,
  `DELETE_FLAG` varchar(2) DEFAULT NULL,
  `CREATED_BY` varchar(100) DEFAULT NULL,
  `CREATED_DATE` timestamp NULL DEFAULT NULL,
  `UPDATED_BY` varchar(100) DEFAULT NULL,
  `UPDATED_DATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CATEGORY_ID`, `CATEGORY_NAME`, `DELETE_FLAG`, `CREATED_BY`, `CREATED_DATE`, `UPDATED_BY`, `UPDATED_DATE`) VALUES
(1, 'Pen', 'N', NULL, NULL, NULL, NULL),
(2, 'Paper', 'N', NULL, NULL, NULL, NULL),
(3, 'Computer Accessories', 'N', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`PRODUCT_ID` int(11) unsigned NOT NULL,
  `CATEGORY_ID` int(11) NOT NULL,
  `PRODUCT_NAME` varchar(100) NOT NULL,
  `MANUFACTURER` varchar(100) NOT NULL,
  `PRODUCT_COUNT` int(11) NOT NULL,
  `COST` bigint(20) NOT NULL,
  `PROFIT_MARGIN` int(2) DEFAULT NULL,
  `NOTES` varchar(512) DEFAULT NULL,
  `IMAGE` blob,
  `MIN_COUNT` int(11) NOT NULL,
  `DELETE_FLAG` varchar(2) DEFAULT NULL,
  `CREATED_BY` varchar(100) DEFAULT NULL,
  `CREATED_DATE` timestamp NULL DEFAULT NULL,
  `UPDATED_BY` varchar(100) DEFAULT NULL,
  `UPDATED_DATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`PRODUCT_ID`, `CATEGORY_ID`, `PRODUCT_NAME`, `MANUFACTURER`, `PRODUCT_COUNT`, `COST`, `PROFIT_MARGIN`, `NOTES`, `IMAGE`, `MIN_COUNT`, `DELETE_FLAG`, `CREATED_BY`, `CREATED_DATE`, `UPDATED_BY`, `UPDATED_DATE`) VALUES
(10, 1, 'Ball Pen', 'Link Company', 25, 5, 10, 'Added 1', NULL, 1, 'N', '', '2015-06-03 18:30:00', '', '2015-06-03 18:30:00'),
(11, 3, 'Mouse', 'HP', 10, 130, 10, '', NULL, 1, 'N', '', '2015-06-09 18:30:00', '', '2015-06-09 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
`TRANSACTION_ID` int(11) unsigned NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_COUNT` int(11) NOT NULL,
  `PRICE_PER_UNIT` bigint(20) NOT NULL,
  `PAYMENT_METHOD` varchar(6) NOT NULL,
  `CUSTOMER_NAME` varchar(100) NOT NULL,
  `CUSTOMER_ADDRESS` varchar(256) NOT NULL,
  `CUSTOMER_PHONE` varchar(15) NOT NULL,
  `TRANSACTION_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TRANSACTION_REMARKS` varchar(100) DEFAULT NULL,
  `TRANSACTION_AMOUNT` bigint(20) NOT NULL,
  `TRANSACTION_TYPE` varchar(6) NOT NULL,
  `DELETE_FLAG` varchar(2) DEFAULT NULL,
  `CREATED_BY` varchar(100) DEFAULT NULL,
  `CREATED_DATE` timestamp NULL DEFAULT NULL,
  `UPDATED_BY` varchar(100) DEFAULT NULL,
  `UPDATED_DATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`TRANSACTION_ID`, `PRODUCT_ID`, `PRODUCT_COUNT`, `PRICE_PER_UNIT`, `PAYMENT_METHOD`, `CUSTOMER_NAME`, `CUSTOMER_ADDRESS`, `CUSTOMER_PHONE`, `TRANSACTION_DATE`, `TRANSACTION_REMARKS`, `TRANSACTION_AMOUNT`, `TRANSACTION_TYPE`, `DELETE_FLAG`, `CREATED_BY`, `CREATED_DATE`, `UPDATED_BY`, `UPDATED_DATE`) VALUES
(1, 0, 20, 4, '1', 'a', 'b', '98', '2015-06-04 18:30:00', NULL, 80, '1', 'N', NULL, '2015-06-04 18:30:00', NULL, '2015-06-04 18:30:00'),
(2, 0, 11, 1, '1', 'a', 's', '2', '2015-06-09 18:30:00', '', 11, '1', 'N', '', '2015-06-09 18:30:00', '', '2015-06-09 18:30:00'),
(3, 0, 11, 1, '1', 'a', 's', '2', '2015-06-09 18:30:00', '', 11, '1', 'N', '', '2015-06-09 18:30:00', '', '2015-06-09 18:30:00'),
(4, 10, 25, 10, '1', 'Rajat Gain', 'Nimta', '2', '2015-06-10 18:30:00', '', 0, '1', 'N', '', '2015-06-09 18:30:00', '', '2015-06-10 18:30:00'),
(6, 11, 10, 150, '4', 'Amitabha Roy', 'Birati', '98', '2015-06-10 18:30:00', '', 0, '4', 'N', '', NULL, '', '2015-06-10 18:30:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
 ADD PRIMARY KEY (`CATEGORY_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`PRODUCT_ID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
 ADD PRIMARY KEY (`TRANSACTION_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
MODIFY `CATEGORY_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `PRODUCT_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
MODIFY `TRANSACTION_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
