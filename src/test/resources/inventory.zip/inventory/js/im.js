$(document).ready(function() {
	$('#ProductTable').dataTable( {
		"bPaginate" : true,
		"bLengthChange" : true,
		"bFilter" : true,
		"bSort" : true,
		"bInfo" : true,
		"bAutoWidth" : true
	});
	$('#TransactionTable').dataTable( {
		"bPaginate" : true,
		"bLengthChange" : true,
		"bFilter" : true,
		"bSort" : true,
		"bInfo" : true,
		"bAutoWidth" : true
	});
	$('#DashboardTransactionTable').dataTable( {
		"bPaginate" : true,
		"bLengthChange" : true,
		"bFilter" : true,
		"bSort" : true,
		"bInfo" : true,
		"bAutoWidth" : true
	});
	$('#UserTable').dataTable( {
		"bPaginate" : true,
		"bLengthChange" : true,
		"bFilter" : true,
		"bSort" : true,
		"bInfo" : true,
		"bAutoWidth" : true
	});
	
	$(".product-category-txn").change(function() {
		this.form.submit();
	});
	
	//$('#myModal').modal('show');
});