<?php
$default = true;
$dashboard = false;
if (strpos($_SERVER['REQUEST_URI'], 'dashboard') !== false) {
    $dashboard = true;
    $default = true;
}
$reports = false;
if (strpos($_SERVER['REQUEST_URI'], 'reports') !== false) {
    $reports = true;
    $default = false;
}
$products = false;
if (strpos($_SERVER['REQUEST_URI'], 'products') !== false) {
    $products = true;
    $default = false;
}
$transactions = false;
if (strpos($_SERVER['REQUEST_URI'], 'transactions') !== false) {
    $transactions = true;
    $default = false;
}
$suppliers = false;
if (strpos($_SERVER['REQUEST_URI'], 'suppliers') !== false) {
    $suppliers = true;
    $default = false;
}
$vendors = false;
if (strpos($_SERVER['REQUEST_URI'], 'vendors') !== false) {
    $vendors = true;
    $default = false;
}
$users = false;
if (strpos($_SERVER['REQUEST_URI'], 'users') !== false) {
    $users = true;
    $default = false;
}
?>
<!-- Sidebar Menu -->
<ul class="sidebar-menu">
	<li class="header">MAIN NAVIGATION</li>
	<li <?php if($default || $reports) echo 'class="active"'; ?>><a href="../dashboard/Dashboard.php"><i class='fa fa-dashboard'></i> <span>Dashboard</span></a></li>
	<!--li <?php if($default || $reports) echo 'class="active"'; ?>><a href="../reports/Reports.php"><i class='fa fa-bar-chart'></i> <span>Reports</span></a></li-->
	<li <?php if($products) echo 'class="active"'; ?>><a href="../products/Products.php"><i class='fa fa-shopping-cart'></i> <span>Products</span></a></li>
	<li <?php if($transactions) echo 'class="active"'; ?>><a href="../transactions/Transactions.php"><i class='fa fa-money'></i> <span>Transactions</span></a></li>
	<!--li <?php if($suppliers) echo 'class="active"'; ?>><a href="../suppliers/Suppliers.php"><i class='fa fa-taxi'></i> <span>Suppliers</span></a></li>
	<li <?php if($vendors) echo 'class="active"'; ?>><a href="../vendors/Vendors.php"><i class='fa fa-bus'></i> <span>Vendors</span></a></li-->
	<li <?php if($users) echo 'class="active"'; ?>><a href="../users/Users.php"><i class='fa fa-users'></i> <span>Users</span></a></li>
</ul>
<!-- /.sidebar-menu -->
