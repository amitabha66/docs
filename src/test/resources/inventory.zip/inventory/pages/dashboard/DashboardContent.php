		<!-- Small boxes (Stat box) -->
		<?php include "DashboardSmallBoxes.php"; ?>
		<!-- Main row -->
		<div class="row"><!-- Left col -->
			<div class="col-md-8">
				<!-- TABLE: LATEST TRANSACTIONS -->
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Transactions of Last One Week</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<div class="box-body">

							<table id="DashboardTransactionTable" class="table">
							<thead>
								<tr>
									<th>Transaction ID</th>
									<th>Product Name</th>
									<th>Customer's Name</th>
									<th>Transaction Date</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$pdo = DBUtil::connect();
									$sql = 'SELECT * FROM TRANSACTIONS T, PRODUCTS P WHERE T.PRODUCT_ID = P.PRODUCT_ID AND DATE(T.TRANSACTION_DATE) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
									$TRANSACTION_AMOUNT_1 = -1;
									foreach ($pdo->query($sql) as $row) {
								?>
								<tr>
									<td><a href="../transactions/Transactions.php?ViewTransactionId=<?php echo $row['TRANSACTION_ID'] ?>"><?php echo $row['TRANSACTION_ID'] ?></a></td>
									<td><?php echo $row['PRODUCT_NAME'] ?></td>
									<td><?php echo $row['CUSTOMER_NAME'] ?></td>
									<td><?php echo $row['TRANSACTION_DATE'] ?></td>
								</tr>
								<?php 
									}
									DBUtil::disconnect();
								?>
							</tbody>
						</table>

					</div><!-- /.box-body -->
					<!--div class="box-footer clearfix">
						<a href="../transactions/Transactions.php" class="btn btn-success btn-flat pull-left">Place New Transaction</a>
						<a href="../transactions/Transactions.php" class="btn btn-primary btn-flat pull-right">View All Transactions</a>
					</div--><!-- /.box-footer -->
				</div><!-- /.box -->
			</div><!-- /.col -->
			<div class="col-md-4">
				<!-- PRODUCT LIST -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Recently Added Products</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<?php 
						$pdo = DBUtil::connect();
						$sql = 'SELECT DISTINCT * FROM PRODUCTS ORDER BY CREATED_DATE DESC';
					?>
					<div class="box-body">
						<ul class="products-list product-list-in-box">
						<?php foreach ($pdo->query($sql) as $row) { ?>
							<li class="item">
								<div class="product-img">
									<img src="../../dist/img/default-50x50.gif" alt="Product Image" />
								</div>
								<div class="product-info">
									<a href="../products/Products.php?ViewProductId=<?php echo $row['PRODUCT_ID'] ?>" class="product-title"><?php echo $row['PRODUCT_NAME'] ?> <span class="label label-warning pull-right"><i class="fa fa-rupee"></i> <?php echo $row['COST'] ?></span></a>
									<span class="product-description"> <?php echo $row['NOTES'] ?> </span>
								</div>
							</li><!-- /.item -->
						<?php } ?>
						</ul>
					</div><!-- /.box-body -->
					<?php 
						DBUtil::disconnect();
					?>
					<div class="box-footer text-center">
						<a href="javascript::;" class="uppercase">View All Products</a>
					</div><!-- /.box-footer -->
				</div><!-- /.box -->
				<!-- USERS LIST -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Recently Added Users</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div>
					</div><!-- /.box-header -->
					<div class="box-body">
						<ul class="products-list product-list-in-box">
						<?php for ($i = 0; $i < 2; $i++) { ?>
							<li class="item">
								<div class="product-img">
									<img src="../../dist/img/default-50x50.gif" alt="Product Image" />
								</div>
								<div class="product-info">
									<a href="javascript::;" class="product-title">User <?php echo $i; ?> <span class="label label-success pull-right">Admin</span></a>
									<span class="product-description"> Samsung 32" 1080p 60Hz LED Smart HDTV. </span>
								</div>
							</li><!-- /.item -->
						<?php } ?>
						</ul>
					</div><!-- /.box-body -->
					<div class="box-footer text-center">
						<a href="javascript::;" class="uppercase">View All Users</a>
					</div><!-- /.box-footer -->
				</div><!-- /.box -->
			</div><!-- /.col -->
		</div><!-- /.row -->