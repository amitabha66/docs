		<?php include "../../utils/DBUtil.php"; ?>
		<div class="row">
			<div class="col-lg-3 col-xs-6">
				<?php
					$pdo = DBUtil::connect();
					$sql = 'SELECT COUNT(*) AS COUNT FROM TRANSACTIONS WHERE DATE(TRANSACTION_DATE) = CURDATE()';
					$TRANSACTION_COUNT = -1;
					foreach ($pdo->query($sql) as $row) {
						$TRANSACTION_COUNT = $row['COUNT'];
					}
					DBUtil::disconnect();
				?>
				<div class="small-box bg-aqua">
					<div class="inner">
						<h3><?php echo $TRANSACTION_COUNT==null ? 0 : $TRANSACTION_COUNT; ?></h3>
						<p>Today's Transactions</p>
					</div>
					<div class="icon"><i class="ion ion-bag"></i></div>
					<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-6">
				<?php
					$pdo = DBUtil::connect();
					$sql = 'SELECT DATE(TRANSACTION_DATE), SUM(TRANSACTION_AMOUNT) AS SUM FROM TRANSACTIONS WHERE DATE(TRANSACTION_DATE) = CURDATE()';
					$TRANSACTION_AMOUNT = -1.00;
					foreach ($pdo->query($sql) as $row) {
						$TRANSACTION_AMOUNT = $row['SUM'];
					}
					DBUtil::disconnect();
				?>
				<div class="small-box bg-yellow">
					<div class="inner">
						<h3><?php echo $TRANSACTION_AMOUNT==null ? 0.00 : $TRANSACTION_AMOUNT; ?></h3>
						<p>Today's Amount</p>
					</div>
					<div class="icon"><i class="fa fa-rupee"></i></div>
					<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-6">
				<?php
					$pdo = DBUtil::connect();
					$sql = 'SELECT SUM(TRANSACTION_AMOUNT) AS SUM FROM TRANSACTIONS WHERE DATE(TRANSACTION_DATE) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)';
					$TRANSACTION_AMOUNT_1 = -1;
					foreach ($pdo->query($sql) as $row) {
						$TRANSACTION_AMOUNT_1 = $row['SUM'];
					}
					if($TRANSACTION_AMOUNT==null) {
						$TRANSACTION_AMOUNT=0.00;
					}
					if($TRANSACTION_AMOUNT_1==null) {
						$TRANSACTION_AMOUNT_1=1.00;
					}
					DBUtil::disconnect();
					$growth = ($TRANSACTION_AMOUNT / $TRANSACTION_AMOUNT_1) * 100;
				?>
				<div class="small-box bg-green">
					<div class="inner">
						<h3><?php echo $growth; ?><sup style="font-size: 20px">%</sup></h3>
						<p>Sales Index</p>
					</div>
					<div class="icon"><i class="ion ion-stats-bars"></i></div>
						<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>
			<div class="col-lg-3 col-xs-6">
				<?php
					$pdo = DBUtil::connect();
					$sql = 'SELECT COUNT(*) AS COUNT FROM PRODUCTS WHERE PRODUCT_COUNT < MIN_COUNT';
					$PRODUCT_COUNT = -1;
					foreach ($pdo->query($sql) as $row) {
						$PRODUCT_COUNT = $row['COUNT'];
					}
					DBUtil::disconnect();
				?>
				<div class="small-box bg-red">
					<div class="inner">
						<h3><?php echo $PRODUCT_COUNT; ?></h3>
						<p>Low Inventory</p>
					</div>
					<div class="icon"><i class="fa fa-cart-arrow-down"></i></div>
					<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>
		</div>