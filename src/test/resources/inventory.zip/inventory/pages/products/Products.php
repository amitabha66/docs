<?php include "../common/Header.php"; ?>

<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>Products<small>Control panel</small></h1>
		<ol class="breadcrumb">
			<li><a href="../../index.php"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="active">Product</li>
		</ol>
	</section>
	<section class="content">
		<!-- Your Page Content Here -->
		<?php include "../products/ProductsContent.php"; ?>
	</section>
</div>
	
<?php include "../common/Footer.php"; ?>