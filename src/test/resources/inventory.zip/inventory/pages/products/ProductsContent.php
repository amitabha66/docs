		<?php include "../../utils/DBUtil.php"; ?>
		<?php 
		$msg = null;
		$Action = null;
		$isInserted = false;
		$isUpdated = false;
		$isDeleted = false;

		// keep track validation errors
		$PRODUCT_NAME_Error = null;
		$CATEGORY_ID_Error = null;
		$PRODUCT_COUNT_Error = null;
		$COST_Error = null;

		// keep track form inputs
		$PRODUCT_ID = "";
		$CATEGORY_ID = "";
		$PRODUCT_NAME = "";
		$MANUFACTURER = "";
		$PRODUCT_COUNT = "";
		$COST = "";
		$PROFIT_MARGIN = "";
		$NOTES = "";
		$IMAGE = null;
		$MIN_COUNT = 1;
		$DELETE_FLAG = "N";
		$CREATED_BY = "";
		$UPDATED_BY = "";

		if (!empty($_GET['ViewProductId'])) { // Read
			$Action = "READ";
			$PRODUCT_ID = $_REQUEST['ViewProductId'];
			// $msg = "View Product " . $PRODUCT_ID;
			if ( $PRODUCT_ID == null ) {
				$msg .= "Product Id is empty";
			} else {
				$pdo = DBUtil::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "SELECT * FROM PRODUCTS WHERE PRODUCT_ID = ?";
				$q = $pdo->prepare($sql);
				$q->execute(array($PRODUCT_ID));
				$data = $q->fetch(PDO::FETCH_ASSOC);
				$CATEGORY_ID = $data['CATEGORY_ID'];
				$PRODUCT_NAME = $data['PRODUCT_NAME'];
				$MANUFACTURER = $data['MANUFACTURER'];
				$PRODUCT_COUNT = $data['PRODUCT_COUNT'];
				$COST = $data['COST'];
				$PROFIT_MARGIN = $data['PROFIT_MARGIN'];
				$NOTES = $data['NOTES'];
				$IMAGE = $data['IMAGE'];
				$MIN_COUNT = $data['MIN_COUNT'];
				$DELETE_FLAG = $data['DELETE_FLAG'];
				$CREATED_BY = $data['CREATED_BY'];
				$UPDATED_BY = $data['UPDATED_BY'];
				DBUtil::disconnect();
				$msg = null; // There is no issue
			}
		} elseif (!empty($_GET['EditProductId'])) { // Update
			$Action = "UPDATE";
			$PRODUCT_ID = $_REQUEST['EditProductId'];
			// $msg .= "Edit Product " . $PRODUCT_ID;
			if ( $PRODUCT_ID == null ) {
				$msg .= "Product Id is empty";
			} else {
				$pdo = DBUtil::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "SELECT * FROM PRODUCTS WHERE PRODUCT_ID = ?";
				$q = $pdo->prepare($sql);
				$q->execute(array($PRODUCT_ID));
				$data = $q->fetch(PDO::FETCH_ASSOC);
				$CATEGORY_ID = $data['CATEGORY_ID'];
				$PRODUCT_NAME = $data['PRODUCT_NAME'];
				$MANUFACTURER = $data['MANUFACTURER'];
				$PRODUCT_COUNT = $data['PRODUCT_COUNT'];
				$COST = $data['COST'];
				$PROFIT_MARGIN = $data['PROFIT_MARGIN'];
				$NOTES = $data['NOTES'];
				$IMAGE = $data['IMAGE'];
				$MIN_COUNT = $data['MIN_COUNT'];
				$DELETE_FLAG = $data['DELETE_FLAG'];
				$CREATED_BY = $data['CREATED_BY'];
				$UPDATED_BY = $data['UPDATED_BY'];
				DBUtil::disconnect();
				$msg = null; // There is no issue
			}
		} elseif (!empty($_GET['DeleteProductId'])) { // Delete
			$Action = "DELETE";
			$PRODUCT_ID = $_REQUEST['DeleteProductId'];
			// $msg .= "Delete Product " . $PRODUCT_ID;
			if ( $PRODUCT_ID == null ) {
				$msg .= "Product Id is empty";
			} else {
				$pdo = DBUtil::connect();
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$sql = "SELECT * FROM PRODUCTS WHERE PRODUCT_ID = ?";
				$q = $pdo->prepare($sql);
				$q->execute(array($PRODUCT_ID));
				$data = $q->fetch(PDO::FETCH_ASSOC);
				$CATEGORY_ID = $data['CATEGORY_ID'];
				$PRODUCT_NAME = $data['PRODUCT_NAME'];
				$MANUFACTURER = $data['MANUFACTURER'];
				$PRODUCT_COUNT = $data['PRODUCT_COUNT'];
				$COST = $data['COST'];
				$PROFIT_MARGIN = $data['PROFIT_MARGIN'];
				$NOTES = $data['NOTES'];
				$IMAGE = $data['IMAGE'];
				$MIN_COUNT = $data['MIN_COUNT'];
				$DELETE_FLAG = $data['DELETE_FLAG'];
				$CREATED_BY = $data['CREATED_BY'];
				$UPDATED_BY = $data['UPDATED_BY'];
				DBUtil::disconnect();
				$msg = null; // There is no issue
			}
		} elseif ( !empty($_POST)) { // Create
			$Action = "CREATE";
			// keep track post values
			$FormAction = $_POST['FormAction'];
			$CATEGORY_ID = $_POST['ProductCategory'];
			$PRODUCT_NAME = $_POST['ProductName'];
			$MANUFACTURER = $_POST['Manufacturer'];
			$PRODUCT_COUNT = $_POST['StartUnit'];
			$COST = $_POST['CostPerUnit'];
			$PROFIT_MARGIN = $_POST['ProfitMargin'];
			$NOTES = $_POST['Notes'];

			$valid = true;
			if (empty($PRODUCT_NAME)) {
				$PRODUCT_NAME_Error = 'Please Enter Product Name';
				$valid = false;
			}
			if (empty($CATEGORY_ID)) {
				$CATEGORY_ID_Error = 'Please Enter Product Category';
				$valid = false;
			}
			if (empty($PRODUCT_COUNT)) {
				$PRODUCT_COUNT_Error = 'Please Enter Start Unit';
				$valid = false;
			}
			if (empty($COST)) {
				$COST_Error = 'Please Enter Cost Per Unit';
				$valid = false;
			}
			// Insert Product
			if ($valid) {
				if($FormAction == "CREATE") {
					$pdo = DBUtil::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "INSERT INTO PRODUCTS (CATEGORY_ID, PRODUCT_NAME, MANUFACTURER, PRODUCT_COUNT, COST, PROFIT_MARGIN, NOTES, IMAGE, MIN_COUNT, DELETE_FLAG, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, CURDATE());";
					$q = $pdo->prepare($sql);
					$q->execute(array($CATEGORY_ID, $PRODUCT_NAME, $MANUFACTURER, $PRODUCT_COUNT, $COST, $PROFIT_MARGIN, $NOTES, $IMAGE, $MIN_COUNT, $DELETE_FLAG, $CREATED_BY, $UPDATED_BY));
					DBUtil::disconnect();
					$isInserted = true;
					$msg = null; // There is no issue
				} else if($FormAction == "UPDATE") {
					$PRODUCT_ID = $_POST['UpdateProductId'];
					$pdo = DBUtil::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "UPDATE PRODUCTS SET CATEGORY_ID = ?, PRODUCT_NAME = ?, MANUFACTURER = ?, PRODUCT_COUNT = ?, COST = ?, PROFIT_MARGIN = ?, NOTES = ?, IMAGE = ?, MIN_COUNT = ?, DELETE_FLAG = ?, CREATED_BY = ?, UPDATED_BY = ? WHERE PRODUCT_ID = ?";
					$q = $pdo->prepare($sql);
					$q->execute(array($CATEGORY_ID, $PRODUCT_NAME, $MANUFACTURER, $PRODUCT_COUNT, $COST, $PROFIT_MARGIN, $NOTES, $IMAGE, $MIN_COUNT, $DELETE_FLAG, $CREATED_BY, $UPDATED_BY, $PRODUCT_ID));
					DBUtil::disconnect();
					$isUpdated = true;
					$msg = null; // There is no issue
				} else if($FormAction == "DELETE") {
					$PRODUCT_ID = $_POST['DeleteProductId'];
					// $msg .= "DELETE FROM PRODUCTS WHERE PRODUCT_ID = " . $PRODUCT_ID;
					$pdo = DBUtil::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = "DELETE FROM PRODUCTS WHERE PRODUCT_ID = ?";
					$q = $pdo->prepare($sql);
					$q->execute(array($PRODUCT_ID));
					DBUtil::disconnect();
					$isDeleted = true;
					// reset form inputs
					$PRODUCT_ID = "";
					$CATEGORY_ID = "";
					$PRODUCT_NAME = "";
					$MANUFACTURER = "";
					$PRODUCT_COUNT = "";
					$COST = "";
					$PROFIT_MARGIN = "";
					$NOTES = "";
					$IMAGE = null;
					$MIN_COUNT = 1;
					$DELETE_FLAG = "N";
					$CREATED_BY = "";
					$UPDATED_BY = "";
					$msg = null; // There is no issue
				}
			}
		} else { // Unknown Action
			$Action = "UNKNOWN";
			$msg .= "No POST data";
		}
		?>
		<div class="row"><!-- two col input form -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title">
						<?php if ($Action == null || $Action == "UNKNOWN" || $Action == "CREATE") { ?> 
						<i class='fa fa-plus'></i> Create New Product
						<?php } else if ($Action == "READ") {?>
						<i class='fa fa-folder-open'></i> Product Details <small><?php echo "Product id $PRODUCT_ID"?></small>
						<?php } else if ($Action == "UPDATE") {?>
						<i class='fa fa-edit'></i> Update Product <small><?php echo "Product id $PRODUCT_ID"?></small>
						<?php } else if ($Action == "DELETE") {?>
						<i class='fa fa-trash'></i> Delete Product <small><?php echo "Product id $PRODUCT_ID"?></small>
						<?php }?>
						</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<form role="form" class="form-horizontal" action="Products.php" method="post">
							<div class="col-md-6">
								<div class="form-group col-xs-12 <?php if($PRODUCT_NAME_Error == null) echo ""; else echo "has-error"; ?>">
									<label class="control-label" for="ProductName" >Product Name</label>
									<input type="text" class="form-control" id="ProductName" name="ProductName" value="<?php echo $PRODUCT_NAME;?>" placeholder="Product Name ...">
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Manufacturer" >Manufacturer</label>
									<input type="text" class="form-control" id="Manufacturer" name="Manufacturer" value="<?php echo $MANUFACTURER;?>" placeholder="Manufacturer ...">
								</div>
								<div class="form-group col-xs-12">
									<label class="control-label" for="Notes" >Notes</label>
									<textarea class="form-control" rows="4" id="Notes" name="Notes"><?php echo $NOTES;?></textarea>
								</div>
							</div>
							<div class="col-md-3">
								<?php 
									$pdo = DBUtil::connect();
									$sql = 'SELECT * FROM CATEGORY ORDER BY CATEGORY_NAME';
									$TRANSACTION_AMOUNT_1 = -1;
									
								?>
								<div class="form-group">
									<label class="control-label" for="ProductCategory">Product Category</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-thumb-tack"></i></span>
										<select class="form-control" id="ProductCategory" name="ProductCategory">
											<?php foreach ($pdo->query($sql) as $row) { ?>
											<option value="<?php echo $row['CATEGORY_ID'] ?>"><?php echo $row['CATEGORY_NAME'] ?></option>
											<?php } ?>
										</select>
									</div>
								</div>
								<?php 
									DBUtil::disconnect();
								 ?>
								<div class="form-group <?php if($PRODUCT_COUNT_Error == null) echo ""; else echo "has-error"; ?>">
									<label class="control-label" for="StartUnit">Starting Unit</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-thumb-tack"></i></span>
										<input type="text" class="form-control" id="StartUnit" name="StartUnit" value="<?php echo $PRODUCT_COUNT;?>" placeholder="Starting Unit ...">
									</div>
								</div>
								<div class="form-group <?php if($COST_Error == null) echo ""; else echo "has-error"; ?>">
									<label class="control-label" for="CostPerUnit">Cost Per Unit</label>
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-rupee"></i></span>
										<input type="text" class="form-control" id="CostPerUnit" name="CostPerUnit" value="<?php echo $COST;?>" placeholder="Price Per Unit ...">
										<span class="input-group-addon">.00</span>
									</div>
								</div>
								<div class="form-group">
									<label class="control-label" for="ProfitMargin">Profit Margin %</label>
									<div class="input-group">
										<span class="input-group-addon">@</span>
										<input type="text" class="form-control" id="ProfitMargin" name="ProfitMargin" value="<?php echo $PROFIT_MARGIN;?>" placeholder="Profit Margin % ...">
										<span class="input-group-addon">%</span>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group col-xs-7">
									<label class="control-label" style="width: 100%; text-align: left;" for="ProductImage" >Product Image</label>
									<div class="fileinput fileinput-new" data-provides="fileinput">
										<div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 220px; height: 223px;"></div>
										<div class="text-center">
											<span class="btn btn-default btn-file"><span class="fileinput-new"><i class="fa fa-file-picture-o"></i> Select image</span><span class="fileinput-exists"><i class='fa fa-exchange'></i> Change</span><input type="file" name="..."></span>
											<a href="#" class="btn btn-default fileinput-exists" data-dismiss="fileinput"><i class="fa fa-trash-o"></i>Remove</a>
										</div>
									</div>
								</div>
							</div>
							<?php if ($Action == null || $Action == "UNKNOWN" || $Action == "CREATE") { ?> 
							<div class="col-md-12 text-center">
								<div class="form-actions">
									<button class="btn btn-success" type="submit"><i class='fa fa-save'></i> Save</button>
									<button class="btn btn-primary" type="reset"><i class='fa fa-eraser'></i> Reset</button>
									<input type="hidden" name="FormAction" id="FormAction" value="CREATE" />
								</div>
							</div>
							<?php } else if ($Action == "READ") {?>
							<!-- READ: No Buttons -->
							<?php } else if ($Action == "UPDATE") {?>
							<div class="col-md-12 text-center">
								<div class="form-actions">
									<button class="btn btn-warning" type="submit"><i class='fa fa-edit'></i> Update</button>
									<input type="hidden" name="FormAction" id="FormAction" value="UPDATE" />
									<input type="hidden" name="UpdateProductId" id="UpdateProductId" value="<?php echo $PRODUCT_ID;?>" />
								</div>
							</div>
							<?php } else if ($Action == "DELETE") {?>
							<div class="col-md-12 text-center">
								<div class="form-actions">
									<label class="control-label">Are you sure to delete?</label>
									<button class="btn btn-danger" type="submit"><i class='fa fa-check'></i> Yes, Delete</button>
									<a class="btn btn-primary" href="Products.php"><i class='fa fa-close'></i> No, Cancel</a>
									<input type="hidden" name="FormAction" id="FormAction" value="DELETE" />
									<input type="hidden" name="DeleteProductId" id="DeleteProductId" value="<?php echo $PRODUCT_ID;?>" />
								</div>
							</div>
							<?php }?>
						</form>
						
						<div class="col-md-12" style="margin-top: 20px;">
							<?php if ($isInserted || $isUpdated || $isDeleted) { ?>
							<div class="alert alert-success alert-dismissable">
							   <button type="button" class="close" data-dismiss="alert" 
							      aria-hidden="true">
							      &times;
							   </button>
							   <h4><i class="fa fa-check-square-o"></i> Success</h4>
							   Product 
							   <?php if ($isInserted) { ?>
							   added
							   <?php } else if ($isUpdated) { ?>
							   updated
							   <?php } else if ($isDeleted) { ?>
							   deleted
							   <?php } ?>
							    successfully.
							</div>
							<?php } ?>
							<!-- div class="alert alert-info alert-dismissable">
							   <button type="button" class="close" data-dismiss="alert" 
							      aria-hidden="true">
							      &times;
							   </button>
							   Info! take this info.
							</div-->
							<?php if ($msg != null && $Action != null && $Action != "UNKNOWN") { ?>
							<div class="alert alert-warning alert-dismissable">
							   <button type="button" class="close" data-dismiss="alert" 
							      aria-hidden="true">
							      &times;
							   </button>
							   <h4><i class="fa fa-warning"></i> Warning</h4>
							   <?php echo $msg;?>
							</div>
							<?php } ?>
						</div>
						
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>
		<div class="row"><!-- one col -->
			<div class="col-md-12">
				<div class="box">
					<div class="box-header with-border">
						<h3 class="box-title"><i class='fa fa-th'></i> List of All Products</h3>
						<div class="box-tools pull-right">
							<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
							<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
						</div><!-- /.box-tools -->
					</div><!-- /.box-header -->
					<div class="box-body">
						<table id="ProductTable" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Product ID</th>
									<th>Product Name</th>
									<th>Status</th>
									<th>Stock Count</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$pdo = DBUtil::connect();
									$sql = 'SELECT * FROM PRODUCTS ORDER BY PRODUCT_ID DESC';
									$TRANSACTION_AMOUNT_1 = -1;
									foreach ($pdo->query($sql) as $row) {
								?>
								<tr>
									<td><a href="Products.php?ViewProductId=<?php echo $row['PRODUCT_ID'] ?>"><?php echo $row['PRODUCT_ID'] ?></a></td>
									<td><?php echo $row['PRODUCT_NAME'] ?></td>
									<td><span class="label label-success">In Stock</span></td>
									<td><?php echo $row['PRODUCT_COUNT'] ?></td>
									<td>
										<a class="btn btn-primary btn-sm" href="Products.php?ViewProductId=<?php echo $row['PRODUCT_ID'] ?>"><i class='fa fa-folder-open-o'></i> <span>View</span></a>
										<a class="btn btn-warning btn-sm" href="Products.php?EditProductId=<?php echo $row['PRODUCT_ID'] ?>"><i class='fa fa-edit'></i> <span>Edit</span></a>
										<a class="btn btn-danger btn-sm" href="Products.php?DeleteProductId=<?php echo $row['PRODUCT_ID'] ?>"><i class='fa fa-trash-o'></i> <span>Delete</span></a>
									</td>
								</tr>
								<?php 
									}
									DBUtil::disconnect();
								 ?>
							</tbody>
						</table>
					</div><!-- /.box-body -->
				</div>
			</div>
		</div>