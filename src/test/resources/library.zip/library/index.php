<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Basic Bootstrap Template</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-theme.min.css">
	<script src="jquery/jquery-1.11.1.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
    <nav id="myNavbar" class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">My Library</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="http://www.tutorialrepublic.com" target="_blank">Home</a></li>
                    <li><a href="http://www.tutorialrepublic.com/about-us.php" target="_blank">About</a></li>
                    <li><a href="http://www.tutorialrepublic.com/contact-us.php" target="_blank">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="jumbotron">
            <header >
            	<p>Library Management System</p>
            </header>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
            	<div class="bs-example">
				    <div class="panel-group" id="accordion">
				        <div class="panel panel-default">
				            <div class="panel-heading">
				                <h4 class="panel-title">
				                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">1. What is HTML?</a>
				                </h4>
				            </div>
				            <div id="collapseOne" class="panel-collapse collapse in">
				                <div class="panel-body">
				                    <div class="btn-group-vertical" style="width: 100%;">
								        <button type="button" class="btn btn-primary btn-md btn-block">Top</button>
								        <button type="button" class="btn btn-primary btn-md btn-block">Middle</button>
								        <button type="button" class="btn btn-primary btn-md btn-block">Bottom</button>
								    </div>
				                </div>
				            </div>
				        </div>
				        <div class="panel panel-default">
				            <div class="panel-heading">
				                <h4 class="panel-title">
				                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">2. What is Bootstrap?</a>
				                </h4>
				            </div>
				            <div id="collapseTwo" class="panel-collapse collapse">
				                <div class="panel-body">
				                    <p>Bootstrap is a powerful front-end framework for faster and easier web development. It is a collection of CSS and HTML conventions. <a href="http://www.tutorialrepublic.com/twitter-bootstrap-tutorial/" target="_blank">Learn more.</a></p>
				                </div>
				            </div>
				        </div>
				        <div class="panel panel-default">
				            <div class="panel-heading">
				                <h4 class="panel-title">
				                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">3. What is CSS?</a>
				                </h4>
				            </div>
				            <div id="collapseThree" class="panel-collapse collapse">
				                <div class="panel-body">
				                    <p>CSS stands for Cascading Style Sheet. CSS allows you to specify various style properties for a given HTML element such as colors, backgrounds, fonts etc. <a href="http://www.tutorialrepublic.com/css-tutorial/" target="_blank">Learn more.</a></p>
				                </div>
				            </div>
				        </div>
				    </div>
				</div>
            </div>
            <div class="col-sm-6 col-md-9 col-lg-9">
                <h2>Heading 2</h2>
                <p>Body content goes here.</p>
            </div>
        </div>
        <hr>
        <div class="jumbotron">
                <footer>
                    <p>&copy; Copyright 2013 Tutorial Republic</p>
                </footer>
        </div>
    </div>
</body>
</html> 