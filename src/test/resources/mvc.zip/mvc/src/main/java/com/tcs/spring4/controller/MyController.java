package com.tcs.spring4.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tcs.spring4.domain.Student;

@RestController
public class MyController {
	
	@RequestMapping("/")
	public ModelAndView welcome() {
		ModelAndView mav = new ModelAndView("welcome");
		mav.addObject("username", "Amitabha");
		return mav;
	}
	
	@RequestMapping(value = "/student", method = RequestMethod.GET)
	public ModelAndView student() {
		return new ModelAndView("student");
	}

	@RequestMapping(value = "/addStudent", method = RequestMethod.POST)
	public ModelAndView addStudent(@ModelAttribute Student student) {
		ModelAndView mav = new ModelAndView("result");
		mav.addObject("action", "Submitted");
		mav.addObject("name", student.getName());
		mav.addObject("age", student.getAge());
		mav.addObject("id", student.getId());
		return mav;
	}
	
	@RequestMapping(value = "/getStudent/{id}", method = RequestMethod.GET)
	public ModelAndView getStudent(@PathVariable String id) {
		ModelAndView mav = new ModelAndView("result");
		mav.addObject("name", "aaaaaa");
		mav.addObject("age", 44);
		mav.addObject("id", "666");
		return mav;
	}

}
