package com.tcs.spring4.service;

import org.springframework.stereotype.Service;

import com.tcs.spring4.domain.Student;

@Service
public interface StudentService {
	
	public Student getStudent(String id);
}
