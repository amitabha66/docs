package com.tcs.spring4.service;

import com.tcs.spring4.domain.Student;

public class StudentServiceImpl implements StudentService {

	public Student getStudent(String id) {
		return new Student(id, "Abcd", 25);
	}

}
