package com.auth;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.AbstractAuthenticationTargetUrlRequestHandler;

import com.domain.User;
import com.logger.MyLogFactory;
import com.logger.MyLogger;

public class AuthenticationSuccessHandler extends AbstractAuthenticationTargetUrlRequestHandler implements
		org.springframework.security.web.authentication.AuthenticationSuccessHandler {

	private static final MyLogger logger = MyLogFactory.getLoggerInstance(AuthenticationSuccessHandler.class.getName());
	private String defaultTargetUrl = "/landing";

	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException,
			ServletException {
		logger.log(MyLogger.DEBUG, "AuthenticationSuccessHandler.onAuthenticationSuccess()");
		User user = ((CustomUserDetails) authentication.getPrincipal()).getUser();
		request.getSession().setAttribute("LOGGED_IN_USER", user);
		logger.log(MyLogger.DEBUG, "Current user is attached to the session.");
		logger.log(MyLogger.DEBUG, "Roles: " + user.getRoles());
		logger.log(MyLogger.DEBUG, "User Successfully Logged in");
		setDefaultTargetUrl(defaultTargetUrl);
		setAlwaysUseDefaultTargetUrl(true);
		handle(request, response, authentication);
		postProcessRequest(request, user);
	}

	/**
	 * Removes temporary authentication-related data which may have been stored
	 * in the session during the authentication process.
	 * 
	 * @param request
	 * @param user
	 */
	protected final void postProcessRequest(HttpServletRequest request, User user) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			logger.log(MyLogger.WARN, "Current user is NOT attached to the session.");
			return;
		}
		session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
	}
}
