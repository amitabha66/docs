package com.auth;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;

import com.domain.Permission;
import com.domain.Role;
import com.domain.User;
import com.logger.MyLogFactory;
import com.logger.MyLogger;
import com.service.UserService;

@Repository
public class CustomUserDetailsService implements UserDetailsService {

	private static final MyLogger logger = MyLogFactory.getLoggerInstance(CustomUserDetailsService.class.getName());

	@Autowired
	private UserService userService;

	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		logger.log(MyLogger.INFO, "CustomUserDetailsService.loadUserByUsername() = " + userName);
		User user = userService.getUserTreeByUserName(userName);
		logger.log(MyLogger.INFO, "CustomUserDetailsService.loadUserByUsername() = " + user);
		List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
		for (Role role : user.getRoles()) {
			for (Permission permission : role.getPermissions()) {
				grantedAuthorities.add(new SimpleGrantedAuthority(permission.getPermissionName()));
			}
		}
		UserDetails userDetails = new CustomUserDetails(user, grantedAuthorities);
		return userDetails;
	}
}
