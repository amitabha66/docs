package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.dao.mapper.StudentMapper;
import com.domain.Student;

@Repository("studentJdbcDaoImpl")
public class StudentJdbcDaoImpl implements StudentDao {

	@Autowired
	JdbcTemplate template;

	public Student createStudent(Student student) {
		String query = "INSERT INTO STUDENTS VALUES(?, ?, ?)";
		int insertCount = template.update(query, student.getId(), student.getName(), student.getAge());
		return student;
	}

	public Student getStudent(String studentId) {
		String query = "SELECT * FROM STUDENTS WHERE STUDENT_ID = ?";
		Student student = template.queryForObject(query, new Object[] { studentId }, new StudentMapper());
		return student;
	}

	public List<Student> getAllStudents() {
		String query = "SELECT * FROM STUDENTS";
		List<Student> studentList = template.query(query, new StudentMapper());
		return studentList;
	}

	public Student updateStudent(Student student) {
		String query = "UPDATE STUDENTS SET NAME = ?, AGE = ? WHERE STUDENT_ID = ?";
		int insertCount = template.update(query, student.getName(), student.getAge(), student.getId());
		return student;
	}

	public boolean deleteStudent(String studentId) {
		String query = "DELETE FROM STUDENTS WHERE STUDENT_ID = ?";
		int deleteCount = template.update(query, studentId);
		return deleteCount > 0 ? true : false;
	}

}
