package com.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.domain.Role;

public class RoleMapper implements RowMapper<Role> {
	public Role mapRow(ResultSet rs, int index) throws SQLException {
		Role role = new Role();
		role.setRoleId(Long.valueOf(rs.getString("ROLE_ID")));
		role.setRoleName(rs.getString("ROLE_NAME"));
		return role;
	}
}