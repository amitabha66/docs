package com.logger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.logger.MyLogFactory;
import com.logger.MyLogger;

@Aspect
@Component
public class LoggerAspect {
    @Around("execution(public * com..*(..))")
    public Object log(ProceedingJoinPoint pjp) throws Throwable {
        final MyLogger logger = MyLogFactory.getLoggerInstance(pjp.getTarget().getClass().getName());
        final Object[] args = pjp.getArgs();
        final String methodName = pjp.getSignature().getName();
        logger.log(MyLogger.INFO, "Enter: " + methodName + "()");
        if (!isUtilMethod(methodName)) {
            logger.log(MyLogger.INFO, methodName + "(): " + args);
        }
        final Object result = pjp.proceed();
        if (!isUtilMethod(methodName)) {
            logger.log(MyLogger.INFO, methodName + "(): result = " + result);
        }
        logger.log(MyLogger.INFO, "Exit: " + methodName + "()");
        return result;
    }
    
    private boolean isUtilMethod(String name) {
        return name.startsWith("get") || name.startsWith("set") || name.equals("toString") || name.equals("equals") || name.equals("hashCode");
    }
}