package com.service;

import java.util.List;

import com.domain.Student;

public interface StudentService {

	public Student createStudent(Student student);

	public Student getStudent(String studentId);

	public List<Student> getAllStudents();

	public Student updateStudent(Student student);

	public boolean deleteStudent(String studentId);
}
