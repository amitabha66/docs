package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.StudentDao;
import com.domain.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	@Qualifier("studentHibernateDaoImpl")
	StudentDao studentDao;

	@CacheEvict(value = "studentCache", allEntries = true)
	public Student createStudent(Student student) {
		return studentDao.createStudent(student);
	}

	@Cacheable(value = "studentCache", key = "T(com.utils.CacheKeyUtils).generateKey( #p0, 'getStudent' )")
	public Student getStudent(String studentId) {
		return studentDao.getStudent(studentId);
	}

	@Cacheable(value = "studentCache", key = "T(com.utils.CacheKeyUtils).generateKey( 'getAllStudents' )")
	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}

	@CacheEvict(value = "studentCache", allEntries = true)
	public Student updateStudent(Student student) {
		return studentDao.updateStudent(student);
	}

	@CacheEvict(value = "studentCache", allEntries = true)
	public boolean deleteStudent(String studentId) {
		return studentDao.deleteStudent(studentId);
	}

}
