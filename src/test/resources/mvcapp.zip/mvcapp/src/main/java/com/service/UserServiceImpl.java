package com.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.domain.Permission;
import com.domain.Role;
import com.domain.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	public User getUserTreeByUserName(String userName) {
		return userDao.getUserTreeByUserName(userName);
	}

	public User setUserTree(User user) {
		return userDao.setUserTree(user);
	}

	public User getUserByUserName(String userName) {
		return userDao.getUserByUserName(userName);
	}

	public User createUser(User newUser) {
		return userDao.createUser(newUser);
	}

	public User updateUser(User existingUser) {
		return userDao.updateUser(existingUser);
	}

	public User deleteUser(User existingUser) {
		return userDao.deleteUser(existingUser);
	}

	public Set<Role> getAllRolesByUserName(String userName) {
		return userDao.getAllRolesByUserName(userName);
	}

	public Role createRole(Role newRole) {
		return userDao.createRole(newRole);
	}

	public Role updateRole(Role existingRole) {
		return userDao.updateRole(existingRole);
	}

	public Role deleteRole(Role existingRole) {
		return userDao.deleteRole(existingRole);
	}

	public Set<Permission> getAllPermissionsByUserName(String userName) {
		return userDao.getAllPermissionsByUserName(userName);
	}

	public Permission createPermission(Permission newPermission) {
		return userDao.createPermission(newPermission);
	}

	public Permission updatePermission(Permission existingPermission) {
		return userDao.updatePermission(existingPermission);
	}

	public Permission deletePermission(Permission existingPermission) {
		return userDao.deletePermission(existingPermission);
	}

}
