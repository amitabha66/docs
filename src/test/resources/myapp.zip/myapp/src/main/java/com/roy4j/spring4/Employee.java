package com.roy4j.spring4;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private Long empId;
	private String empName;
	
	@Autowired
	private Address address;

	public Employee() {
	}

	public Employee(Long empId, String empName, Address address) {
		this.empId = empId;
		this.empName = empName;
		this.address = address;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", address=" + address + "]";
	}
}