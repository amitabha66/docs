package com;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloController {

	@RequestMapping(value = "/msg", method = RequestMethod.GET)
	public Employee helloWorld() {
		Employee e = new Employee();
		e.setEmpId("123");
		e.setEmpName("Best Employee");
		Address a = new Address();
		a.setCity("London");
		e.setAddress(a);
		return e;
	}
}