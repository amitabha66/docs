// Validating Empty Field
function check_empty() {
	if (document.getElementById('VerseType').value == ""
			|| document.getElementById('VerseNumber').value == ""
			|| document.getElementById('VerseSequence').value == ""
			|| document.getElementById('VerseText').value == "") {
		alert("Fill All Fields !");
	} else {
		document.getElementById('VerseInputForm').submit();
	}
}

function check_empty_breakups() {
	document.getElementById('WordInputForm').submit();
}

function check_empty_translation() {
	document.getElementById('TranslationInputForm').submit();
}

//Function To Display Popup
function div_show(verseId, langId, title) {
	document.getElementById('VerseInputDiv').style.display = "block";
	document.getElementById('VerseId').value = verseId;
	document.getElementById('VerseInputDivHeader').innerHTML = title;
	$.ajax({
		type : "GET",
		url : "Ajax.jsp",
		data : "action=V&VerseId="+verseId+"&LangId"+langId,
		cache : false,
		dataType: 'json',
		success : function(data) {
			$("#VerseType").val(data.VERSE_TYPE);
			$("#VerseNumber").val(data.VERSE_NUMBER);
			$("#VerseSequence").val(data.VERSE_SEQUENCE);
			var verseText = "";
			if(data.VERSE_TEXT && data.VERSE_TEXT != null) {
				verseText = data.VERSE_TEXT.replace("<br />", "\n");
			}
			if(verseText == "null") {
				$("#VerseText").val("");
			} else {
				$("#VerseText").val(verseText);
			}
			if(data.TRANSLATED_TEXT == "null") {
				$("#VerseTranslation").val("");
			} else {
				$("#VerseTranslation").val(data.TRANSLATED_TEXT);
			}
		},
		error : function(data){
			alert("Error: " + JSON.stringify(data));
		}
	});
}

function div_show_breakups(verseId, title, text) {
	document.getElementById('CreateWordDiv').style.display = "block";
	document.getElementById('VerseId1').value = verseId;
	document.getElementById('CreateWordDivHeader').innerHTML = "Breakup: " + title;
	document.getElementById('VerseBreakupText').innerHTML = text;
	$.ajax({
		type : "GET",
		url : "Ajax.jsp",
		data : "action=B&verseId="+verseId,
		cache : false,
		dataType: 'json',
		success : function(data) {
			var count = data.count;
			var html = "";
			$.each(data.words, function(i) {
				html = html + "<tr>";
				html = html + '<td style="width: 80px; padding-left: 60px;"><input id="WordSequence" name="WordSequence" type="hidden" value="'+data.words[i].WORD_SEQUENCE+'">'+data.words[i].WORD_SEQUENCE+'</td>';
				html = html + '<td><input id="WordText" name="WordText" type="text" value="'+data.words[i].TEXT+'"></td>';
				html = html + "</tr>";
			});
			for(var i=1; i<=10; i++) {
				html = html + '<tr>';
				html = html + '<td style="width: 80px; padding-left: 60px;"><input id="WordSequence" name="WordSequence" placeholder="WordSequence" type="hidden" value="'+(count+i)+'">'+(count+i)+'</td>';
				html = html + '<td><input id="WordText" name="WordText" placeholder="WordText" type="text"></td>';
				html = html + '</tr>';
			}
			document.getElementById('EditBreakups').innerHTML = html;
		},
		error : function(data){
			alert("Error: " + JSON.stringify(data));
		}
	});
}

function div_show_translation(wordId, bookId, langId) {
	document.getElementById('CreateTranslationDiv').style.display = "block";
	$.ajax({
		type : "GET",
		url : "Ajax.jsp",
		data : "action=T&wordId="+wordId+"&bookId="+bookId+"&langId="+langId,
		cache : false,
		dataType: 'json',
		success : function(data) {
			$("#CreateTranslationDivHeader").html(data.LANGUAGE_NAME + ": " + data.TEXT);
			$("#WordId").val(data.WORD_ID);
			//alert(data.WORD_ID);
			if(data.TRANSLITERATION == "null") {
				//alert("--null--");
			} else {
				$("#Transliteration").val(data.TRANSLITERATION);
				//$("#Transliteration").attr("disabled", "disabled");
			}
			$("#TranslationLanguage").val(langId);
		},
		error : function(data){
			alert("Error: " + JSON.stringify(data));
		}
	});
}

//Function to Hide Popup
function div_hide() {
	document.getElementById('VerseInputDiv').style.display = "none";
	document.getElementById('VerseId').value = "";
	document.getElementById('VerseInputDivHeader').innerHTML = "";
}

function div_hide_word() {
	document.getElementById('CreateWordDiv').style.display = "none";
	document.getElementById('VerseId1').value = "";
	document.getElementById('CreateWordDivHeader').innerHTML = "";
	document.getElementById('VerseBreakupText').innerHTML = "";
}

function div_hide_translation() {
	document.getElementById('CreateTranslationDiv').style.display = "none";
	document.getElementById('CreateTranslationDivHeader').innerHTML = "";
	document.getElementById('WordId').value = "";
	document.getElementById('Transliteration').value = "";
	document.getElementById('TranslationLanguage').value = "";
}