INSERT INTO `LANGUAGES` (`LANGUAGE_ID`, `COUNTRY_CODE`, `COUNTRY_NAME`, `LANGUAGE_CODE`, `LANGUAGE_NAME`) VALUES
(1, 'IN', 'India', 'SA', 'Sanskrit'),
(2, 'IN', 'India', 'BN', 'Bengali');

INSERT INTO `AUTHORS` (`AUTHOR_ID`, `AUTHOR_NAME`, `AUTHOR_SHORT_NAME`) VALUES
(1, 'Unknown', 'Unknown'),
(2, 'Gaurpadacharya', 'Gaurpada');

INSERT INTO `BOOKS` (`BOOK_ID`, `TITLE`, `SHORT_NAME`, `LANGUAGE_ID`) VALUES
(1, 'Mandukya Karika', 'MK', 1);

INSERT INTO `BOOKS_AUTHORS` (`BOOK_ID`, `AUTHOR_ID`) VALUES
(1, 2);

INSERT INTO `CHAPTERS` (`CHAPTER_ID`, `CHAPTER_SEQUENCE`, `CHAPTER_NUMBER`, `CHAPTER_TITLE`, `BOOK_ID`) VALUES
(1, 1, 'I', 'Chapter 1', 1),
(2, 2, 'II', 'Chapter 2', 1),
(3, 3, 'III', 'Chapter 3', 1),
(4, 4, 'IV', 'Chapter 4', 1);

