package com.roy4j.onlinelibrary.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.roy4j.onlinelibrary.domain.Author;
import com.roy4j.onlinelibrary.domain.Book;
import com.roy4j.onlinelibrary.domain.Language;
import com.roy4j.onlinelibrary.service.BookService;

@Controller
public class BookController {

	@Autowired
	BookService bookService;

	@RequestMapping("/CreateBookForm")
	public ModelAndView createBookForm() {
		ModelAndView mav = new ModelAndView("CreateBookForm");
		try {
			List<Language> languages = bookService.getAllLanguages();
			mav.addObject("languageList", languages);
			List<Author> authors = bookService.getAllAuthors();
			mav.addObject("authorList", authors);
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error in CreateBookForm");
			e.printStackTrace();
		}
		return mav;
	}
	
	@RequestMapping("/CreateContentForm")
	public ModelAndView createContentForm() {
		ModelAndView mav = new ModelAndView("CreateContentForm");
		try {
			List<Book> books = bookService.getAllBooks();
			mav.addObject("bookList", books);
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error in CreateContentForm");
			e.printStackTrace();
		}
		return mav;
	}
	
	@RequestMapping("/createBookForTest")
	public ModelAndView createBookForTest() {
		ModelAndView mav = new ModelAndView("Book");
		try {
			Book book = getTestBook();
			book = bookService.createBook(book);
			mav.addObject("book", book);
			mav.addObject("message", " : Success : " + book.getBookTitle()
					+ ".");
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Book Not Found");
			e.printStackTrace();
		}
		return mav;
	}

	@RequestMapping("/getBookById/{id}")
	public ModelAndView getBookById(@PathVariable("id") String bookId) {
		ModelAndView mav = new ModelAndView("Book");
		try {
			Book book = bookService.getBookById(bookId);
			mav.addObject("book", book);
			if (book == null) {
				mav.addObject("message", " : Book Not Found");
			} else {
				mav.addObject("message", " : Success");
			}
		} catch (Exception e) {
			mav.addObject("errorMessage", "Error: Book Not Found");
			e.printStackTrace();
		}
		return mav;
	}

	private Book getTestBook() {
		Book book = new Book();
		book.setBookTitle("Mandukya Upanishad");
		return book;
	}
}
