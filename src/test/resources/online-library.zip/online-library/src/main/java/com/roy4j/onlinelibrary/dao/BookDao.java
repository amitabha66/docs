package com.roy4j.onlinelibrary.dao;

import java.util.List;

import com.roy4j.onlinelibrary.domain.Author;
import com.roy4j.onlinelibrary.domain.Book;
import com.roy4j.onlinelibrary.domain.Language;

public interface BookDao {
	
	Book createBook(Book book);

	Book getBookById(String bookId);

	Book updateBook(Book book);

	boolean deleteBookById(String bookId);

	List<Language> getAllLanguages();

	List<Author> getAllAuthors();

	List<Book> getAllBooks();

}
