package com.roy4j.onlinelibrary.dao;

import java.util.List;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.roy4j.onlinelibrary.domain.Author;
import com.roy4j.onlinelibrary.domain.Book;
import com.roy4j.onlinelibrary.domain.Language;

@Repository
public class BookDaoImpl implements BookDao {

	@Autowired
	HibernateTemplate template;

	public Book createBook(Book book) {
		System.out.println("---------" + book);
		template.save(book);
		return book;
	}

	public Book getBookById(String bookId) {
		Book book = template.get(Book.class, Long.parseLong(bookId));
		return book;
	}

	public Book updateBook(Book book) {
		template.update(book);
		return book;
	}

	public boolean deleteBookById(String bookId) {
		template.delete(getBookById(bookId));
		return true;
	}

	public List<Language> getAllLanguages() {
		List<Language> languages = (List<Language>) template.find("from Language");
		System.out.println("languages: " + languages);
		return languages;
	}

	@Override
	public List<Author> getAllAuthors() {
		List<Author> authors = (List<Author>) template.find("from Author");
		System.out.println("authors: " + authors);
		return authors;
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> books = (List<Book>) template.find("from Book");
		System.out.println("books: " + books);
		return books;
	}

}
