package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "AUTHORS")
public class Author implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AUTHOR_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long authorId;

	@Column(name = "AUTHOR_NAME")
	private String authorName; // Unicode

	@Column(name = "AUTHOR_SHORT_NAME")
	private String authorShortName; // Unicode

	@ManyToMany(mappedBy="authors")
	private List<Book> books;

	public Long getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Long authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getAuthorShortName() {
		return authorShortName;
	}

	public void setAuthorShortName(String authorShortName) {
		this.authorShortName = authorShortName;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

}
