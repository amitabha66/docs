package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKS")
public class Book implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "BOOK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long bookId;

	@ManyToMany
	@JoinTable(name = "BOOKS_LANGUAGES", joinColumns = @JoinColumn(name = "BOOK_ID", referencedColumnName = "BOOK_ID"), inverseJoinColumns = @JoinColumn(name = "LANGUAGE_ID", referencedColumnName = "LANGUAGE_ID"))
	private List<Language> languages;

	@Column(name = "BOOK_TITLE")
	private String bookTitle; // Unicode

	@Column(name = "BOOK_SHORT_NAME")
	private String bookShortName; // Unicode

	@ManyToMany
	@JoinTable(name = "BOOKS_AUTHORS", joinColumns = @JoinColumn(name = "BOOK_ID", referencedColumnName = "BOOK_ID"), inverseJoinColumns = @JoinColumn(name = "AUTHOR_ID", referencedColumnName = "AUTHOR_ID"))
	private List<Author> authors;

	@OneToOne(optional = true)
	@JoinColumn(name = "CONTENT_ID")
	private Content contentId;

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public List<Language> getLanguages() {
		return languages;
	}

	public void setLanguages(List<Language> languages) {
		this.languages = languages;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookShortName() {
		return bookShortName;
	}

	public void setBookShortName(String bookShortName) {
		this.bookShortName = bookShortName;
	}

	public List<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}

	public Content getContentId() {
		return contentId;
	}

	public void setContentId(Content contentId) {
		this.contentId = contentId;
	}

}
