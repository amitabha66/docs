package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CHAPTERS")
public class Chapter implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "CONTENT_ID", nullable = false)
	private Content contentId;

	@Id
	@Column(name = "CHAPTER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long chapterId;

	@Column(name = "CHAPTER_NUMBER")
	private String chapterNumber; // Unicode

	@Column(name = "CHAPTER_SEQUENCE")
	private Integer chapterSequence;

	@Column(name = "CHAPTER_TITLE")
	private String chapterTitle; // Unicode

	@Column(name = "NUMBER_OF_SHLOKS")
	private Integer numberOfShloks;

	@ManyToMany
	@JoinTable(name = "CHAPTERS_SHLOKS", joinColumns = @JoinColumn(name = "CHAPTER_ID", referencedColumnName = "CHAPTER_ID"), inverseJoinColumns = @JoinColumn(name = "SHLOK_ID", referencedColumnName = "SHLOK_ID"))
	private List<Shlok> shloks;

	public Content getContentId() {
		return contentId;
	}

	public void setContentId(Content contentId) {
		this.contentId = contentId;
	}

	public Long getChapterId() {
		return chapterId;
	}

	public void setChapterId(Long chapterId) {
		this.chapterId = chapterId;
	}

	public String getChapterNumber() {
		return chapterNumber;
	}

	public void setChapterNumber(String chapterNumber) {
		this.chapterNumber = chapterNumber;
	}

	public Integer getChapterSequence() {
		return chapterSequence;
	}

	public void setChapterSequence(Integer chapterSequence) {
		this.chapterSequence = chapterSequence;
	}

	public String getChapterTitle() {
		return chapterTitle;
	}

	public void setChapterTitle(String chapterTitle) {
		this.chapterTitle = chapterTitle;
	}

	public Integer getNumberOfShloks() {
		return numberOfShloks;
	}

	public void setNumberOfShloks(Integer numberOfShloks) {
		this.numberOfShloks = numberOfShloks;
	}

	public List<Shlok> getShloks() {
		return shloks;
	}

	public void setShloks(List<Shlok> shloks) {
		this.shloks = shloks;
	}

}
