package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CONTENTS")
public class Content implements Serializable {

	private static final long serialVersionUID = 1L;

	@OneToOne(mappedBy = "contentId")
	private Book bookId;

	@Id
	@Column(name = "CONTENT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long contentId;

	@Column(name = "SUCHIPATRA")
	private String suchipatra; // Unicode

	@Column(name = "BHUMIKA")
	private String bhumika; // Unicode

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "contentId")
	private List<Chapter> chapters;

	public Book getBookId() {
		return bookId;
	}

	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}

	public Long getContentId() {
		return contentId;
	}

	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}

	public String getSuchipatra() {
		return suchipatra;
	}

	public void setSuchipatra(String suchipatra) {
		this.suchipatra = suchipatra;
	}

	public String getBhumika() {
		return bhumika;
	}

	public void setBhumika(String bhumika) {
		this.bhumika = bhumika;
	}

	public List<Chapter> getChapters() {
		return chapters;
	}

	public void setChapters(List<Chapter> chapters) {
		this.chapters = chapters;
	}

}
