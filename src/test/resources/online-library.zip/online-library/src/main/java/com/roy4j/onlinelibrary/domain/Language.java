package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "LANGUAGES")
public class Language implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "LANGUAGE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long languageId;

	@Column(name = "LANGUAGE_NAME")
	private String languageName;

	@Column(name = "LANGUAGE_CODE")
	private String languageCode;

	@Column(name = "COUNTRY_NAME")
	private String countryName;

	@Column(name = "COUNTRY_CODE")
	private String countryCode;

	@ManyToMany(mappedBy = "languages")
	private List<Book> books;

	@OneToOne(optional = true, mappedBy = "languageId")
	private Translation translationId;

	public Long getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Long languageId) {
		this.languageId = languageId;
	}

	public String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

}
