package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "SHLOKS")
public class Shlok implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SHLOK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long shlokId;

	@Column(name = "NUMBER_OF_LINES")
	private Integer numberOfPadas;

	@ManyToMany
	@JoinTable(name = "SHLOKS_PADAS", joinColumns = @JoinColumn(name = "SHLOK_ID", referencedColumnName = "SHLOK_ID"), inverseJoinColumns = @JoinColumn(name = "PADA_ID", referencedColumnName = "PADA_ID"))
	private List<Pada> padas;

	@Column(name = "SHLOK_NUMBER")
	private String shlokNumber; // Unicode

	@ManyToMany(mappedBy = "shloks")
	private List<Chapter> chapters;

	public Long getShlokId() {
		return shlokId;
	}

	public void setShlokId(Long shlokId) {
		this.shlokId = shlokId;
	}

	public Integer getNumberOfPadas() {
		return numberOfPadas;
	}

	public void setNumberOfPadas(Integer numberOfPadas) {
		this.numberOfPadas = numberOfPadas;
	}

	public List<Pada> getPadas() {
		return padas;
	}

	public void setPadas(List<Pada> padas) {
		this.padas = padas;
	}

	public String getShlokNumber() {
		return shlokNumber;
	}

	public void setShlokNumber(String shlokNumber) {
		this.shlokNumber = shlokNumber;
	}

	public List<Chapter> getChapters() {
		return chapters;
	}

	public void setChapters(List<Chapter> chapters) {
		this.chapters = chapters;
	}

}
