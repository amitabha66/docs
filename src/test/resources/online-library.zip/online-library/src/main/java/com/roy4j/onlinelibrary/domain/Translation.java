package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSLATIONS")
public class Translation implements Serializable {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "WORD_ID", nullable = false)
	private Word wordId;

	@Id
	@Column(name = "TRANSLATION_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long translationId;

	@OneToOne(optional = false)
	@JoinColumn(name = "LANGUAGE_ID", unique = true, nullable = true, updatable = false)
	private Language languageId;

	@Column(name = "TRANSLITERATION")
	private String transliteration; // Unicode

	@Column(name = "TRANSLATION")
	private String translation; // Unicode

	public Word getWordId() {
		return wordId;
	}

	public void setWordId(Word wordId) {
		this.wordId = wordId;
	}

	public Long getTranslationId() {
		return translationId;
	}

	public void setTranslationId(Long translationId) {
		this.translationId = translationId;
	}

	public Language getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Language languageId) {
		this.languageId = languageId;
	}

	public String getTransliteration() {
		return transliteration;
	}

	public void setTransliteration(String transliteration) {
		this.transliteration = transliteration;
	}

	public String getTranslation() {
		return translation;
	}

	public void setTranslation(String translation) {
		this.translation = translation;
	}

}
