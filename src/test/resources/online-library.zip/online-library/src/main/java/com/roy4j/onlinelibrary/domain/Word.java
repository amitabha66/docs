package com.roy4j.onlinelibrary.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "WORDS")
public class Word implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "WORD_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long wordId;

	@ManyToOne(optional = false)
	@JoinColumn(name = "LANGUAGE_ID", nullable = false, updatable = false)
	private Language languageId;

	@Column(name = "WORD")
	private String word; // Unicode

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "wordId")
	private List<Translation> translations;

	@ManyToMany(mappedBy="words")
	private List<Pada> padas;

	public Long getWordId() {
		return wordId;
	}

	public void setWordId(Long wordId) {
		this.wordId = wordId;
	}

	public Language getLanguageId() {
		return languageId;
	}

	public void setLanguageId(Language languageId) {
		this.languageId = languageId;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public List<Translation> getTranslations() {
		return translations;
	}

	public void setTranslations(List<Translation> translations) {
		this.translations = translations;
	}

	public List<Pada> getPadas() {
		return padas;
	}

	public void setPadas(List<Pada> padas) {
		this.padas = padas;
	}

}
