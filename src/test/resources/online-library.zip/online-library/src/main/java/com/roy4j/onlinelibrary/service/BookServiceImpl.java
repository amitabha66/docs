package com.roy4j.onlinelibrary.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roy4j.onlinelibrary.dao.BookDao;
import com.roy4j.onlinelibrary.domain.Author;
import com.roy4j.onlinelibrary.domain.Book;
import com.roy4j.onlinelibrary.domain.Language;

@Service
@Transactional
public class BookServiceImpl implements BookService {

	@Autowired
	BookDao bookDao;

	@Override
	public Book createBook(Book book) {
		return bookDao.createBook(book);
	}

	@Override
	public Book getBookById(String bookId) {
		return bookDao.getBookById(bookId);
	}

	@Override
	public Book updateBook(Book book) {
		return bookDao.updateBook(book);
	}

	@Override
	public boolean deleteBookById(String bookId) {
		return bookDao.deleteBookById(bookId);
	}

	@Override
	public List<Language> getAllLanguages() {
		return bookDao.getAllLanguages();
	}

	@Override
	public List<Author> getAllAuthors() {
		return bookDao.getAllAuthors();
	}

	@Override
	public List<Book> getAllBooks() {
		return bookDao.getAllBooks();
	}

}
