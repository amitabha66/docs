package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.StudentDao;
import com.domain.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	@Qualifier("studentHibernateDaoImpl")
	StudentDao studentDao;

	public Student createStudent(Student student) {
		return studentDao.createStudent(student);
	}

	public Student getStudent(String studentId) {
		return studentDao.getStudent(studentId);
	}

	public List<Student> getAllStudents() {
		return studentDao.getAllStudents();
	}

	public Student updateStudent(Student student) {
		return studentDao.updateStudent(student);
	}

	public boolean deleteStudent(String studentId) {
		return studentDao.deleteStudent(studentId);
	}

}
